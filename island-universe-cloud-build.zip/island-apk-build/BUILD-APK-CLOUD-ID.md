# Membuat APK melalui GitHub Actions

Workflow `.github/workflows/build-apk.yml` disiapkan untuk membangun APK debug secara otomatis di cloud.

1. Unggah seluruh isi folder proyek ini ke repository GitHub baru (repository harus berisi folder `android/` dan `.github/` di root).
2. Buka tab **Actions** di repository dan pilih **Build Android APK**.
3. Tekan **Run workflow** jika build belum berjalan otomatis.
4. Setelah selesai, buka hasil run dan unduh artifact **island-universe-debug-apk**.
5. Ekstrak ZIP artifact dan instal `app-debug.apk` di Android.

Catatan: APK belum dibuat di arsip ini. Workflow membutuhkan build cloud GitHub dan belum menjamin build berhasil sampai workflow dijalankan.

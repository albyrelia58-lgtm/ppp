import { i as __toESM } from "../_runtime.mjs";
import { K as require_react, b as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-CDLTI0SX.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function Home() {
	const [App, setApp] = (0, import_react.useState)(null);
	(0, import_react.useEffect)(() => {
		import("./throne-app-BtmHdejk.mjs").then((mod) => setApp(() => mod.ThroneApp));
	}, []);
	if (!App) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "boot",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "boot-kicker",
			children: "SINGGASANA"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "boot-tag",
			children: "Dunia sedang tumbuh"
		})]
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(App, {});
}
//#endregion
export { Home as component };

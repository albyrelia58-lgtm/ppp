import { i as __toESM } from "../_runtime.mjs";
import { K as require_react, b as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { A as Flower2, B as Bomb, C as Pause, D as Landmark, E as Minus, F as Crown, H as Axe, I as CloudRain, L as CloudLightning, M as Fence, N as Eraser, O as House, P as Droplets, R as Cat, S as PawPrint, T as Mountain, V as Bird, _ as Settings, a as Users, b as Plus, c as TreePine, d as Store, f as Sprout, g as Ship, h as Shield, i as Volume2, j as Flame, k as HeartPulse, l as Swords, m as Skull, n as Wheat, p as Snowflake, r as Waves, s as Trees, t as Wind, u as SunMedium, v as Save, w as MousePointer2, x as Play, y as Rabbit, z as Castle } from "../_libs/lucide-react.mjs";
import { A as PointsMaterial, C as MeshBasicMaterial, D as PlaneGeometry, E as OrthographicCamera, F as Scene, I as ShaderMaterial, L as SphereGeometry, M as Raycaster, N as RingGeometry, O as PointLight, P as SRGBColorSpace, R as Vector2, S as Mesh, T as Object3D, _ as InstancedMesh, a as BufferGeometry, b as Matrix3, c as ConeGeometry, d as DynamicDrawUsage, f as Euler, g as IcosahedronGeometry, h as HemisphereLight, i as BufferAttribute, j as Quaternion, k as Points, l as CylinderGeometry, m as Fog, n as AmbientLight, o as CapsuleGeometry, p as Float32BufferAttribute, r as BoxGeometry, s as Color, t as WebGLRenderer, u as DirectionalLight, v as Line, w as MeshStandardMaterial, x as Matrix4, y as LineBasicMaterial, z as Vector3 } from "../_libs/three.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/throne-app-BtmHdejk.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var GAPS = {
	ui_tap: .03,
	sword: .06,
	bite: .08,
	hurt: .05,
	chop: .07,
	mine: .07,
	hammer: .09,
	foot: .09,
	foot_heavy: .11,
	foot_hoof: .1,
	foot_paw: .09,
	chicken: .25,
	splash: .12,
	lava: .4,
	tower: .08,
	eat: .12
};
function v(osc, f, dur, gain, slide = 1, filter = 1800, filterType = "lowpass", delay = 0) {
	return {
		osc,
		f,
		dur,
		gain,
		slide,
		filter,
		filterType,
		delay
	};
}
var RECIPES = {
	ui_tap: [v("sine", 720, .05, .04, 1.35, 2400)],
	ui_open: [v("triangle", 390, .09, .045, 1.5, 1600), v("sine", 620, .11, .03, 1.2, 1800, "lowpass", .04)],
	ui_close: [v("triangle", 520, .08, .04, .7, 1400)],
	ui_error: [v("square", 180, .14, .04, .75, 700), v("square", 140, .16, .03, .8, 500, "lowpass", .06)],
	ui_save: [v("sine", 660, .08, .04, 1.25), v("sine", 990, .12, .035, 1, 2e3, "lowpass", .07)],
	select: [v("sine", 540, .06, .035, 1.15, 2e3)],
	place_human: [v("triangle", 420, .1, .05, 1.4), v("sine", 640, .12, .03, 1.1, 1800, "lowpass", .05)],
	place_elf: [v("sine", 760, .14, .04, 1.3), v("triangle", 1140, .16, .025, 1.05, 2400, "lowpass", .06)],
	place_orc: [v("sawtooth", 160, .16, .05, .7, 500), v("square", 90, .12, .03, .8, 240)],
	place_dwarf: [v("square", 210, .08, .04, 1.1, 700), v("triangle", 140, .14, .04, .85, 400, "lowpass", .04)],
	place_warrior: [v("square", 300, .09, .04, .8, 900), v("sawtooth", 180, .12, .03, .7, 500)],
	place_king: [
		v("triangle", 330, .16, .045, 1.25),
		v("sine", 495, .2, .03, 1, 1600, "lowpass", .05),
		v("sine", 660, .22, .02, 1, 1800, "lowpass", .1)
	],
	place_baby: [v("sine", 880, .1, .035, 1.4, 2400), v("sine", 1320, .12, .02, 1.1, 2600, "lowpass", .06)],
	place_house: [v("triangle", 240, .1, .05, 1.15, 800), v("noise", 200, .08, .03, 1, 900)],
	place_farm: [v("triangle", 360, .1, .04, 1.2, 1e3), v("sine", 540, .12, .025, 1, 1400, "lowpass", .05)],
	place_tower: [v("square", 260, .12, .04, .85, 700), v("triangle", 390, .14, .03, 1.2, 1200, "lowpass", .04)],
	place_castle: [v("sawtooth", 150, .2, .04, .7, 420), v("triangle", 300, .22, .035, 1.3, 900, "lowpass", .06)],
	place_wall: [v("noise", 120, .09, .05, 1, 600), v("square", 110, .08, .03, .8, 300)],
	place_boat: [v("triangle", 280, .12, .04, 1.1, 800), v("noise", 300, .16, .03, 1, 500, "lowpass", .02)],
	place_fire: [v("noise", 400, .18, .05, 1, 900, "bandpass"), v("triangle", 180, .12, .03, 1.4, 600)],
	place_tree: [v("triangle", 220, .1, .04, .8, 700), v("noise", 180, .1, .025, 1, 500)],
	place_rock: [v("noise", 90, .12, .06, 1, 350), v("sine", 80, .1, .04, .7, 200)],
	place_bush: [v("sine", 480, .07, .03, 1.3, 1600), v("noise", 300, .06, .02, 1, 1200)],
	place_flower: [v("sine", 980, .08, .03, 1.25, 2400), v("triangle", 1460, .1, .02, 1, 2600, "lowpass", .04)],
	chop: [v("noise", 180, .07, .06, 1, 700), v("square", 140, .05, .03, .6, 400)],
	mine: [v("noise", 90, .08, .07, 1, 400), v("sine", 70, .1, .04, .7, 180)],
	hammer: [v("square", 190, .06, .045, .65, 600), v("noise", 150, .05, .03, 1, 500)],
	build_done: [v("triangle", 440, .1, .04, 1.2), v("sine", 660, .14, .03, 1, 1800, "lowpass", .06)],
	eat: [v("sine", 310, .08, .04, 1.4, 900), v("triangle", 200, .1, .03, .8, 500, "lowpass", .03)],
	sword: [v("sawtooth", 680, .07, .035, .45, 2200), v("noise", 900, .05, .04, 1, 2500, "highpass")],
	bite: [v("sawtooth", 150, .1, .05, .5, 500), v("noise", 200, .08, .04, 1, 800)],
	bow: [v("triangle", 520, .09, .03, .55, 1600), v("sine", 880, .06, .02, .7, 2e3)],
	hurt: [v("square", 240, .08, .04, .6, 800)],
	death: [v("triangle", 360, .22, .05, .35, 900), v("sine", 220, .28, .03, .4, 500, "lowpass", .04)],
	death_beast: [v("sawtooth", 200, .24, .05, .4, 600), v("noise", 140, .2, .04, 1, 400)],
	birth: [
		v("sine", 660, .12, .04, 1.2),
		v("sine", 880, .16, .03, 1.15, 2e3, "lowpass", .05),
		v("triangle", 1320, .18, .02, 1, 2400, "lowpass", .1)
	],
	chicken: [v("square", 980, .06, .03, 1.6, 2400), v("square", 1400, .05, .02, 1.2, 2800, "lowpass", .07)],
	sheep: [v("sawtooth", 320, .16, .03, 1.15, 700), v("triangle", 480, .12, .02, .9, 900, "lowpass", .06)],
	cow: [v("sawtooth", 130, .32, .05, .72, 380), v("triangle", 98, .36, .03, .8, 240, "lowpass", .05)],
	deer: [v("sine", 640, .1, .03, 1.35, 1800), v("triangle", 420, .12, .02, 1.1, 1200)],
	wolf: [v("sawtooth", 340, .42, .045, 1.55, 900), v("triangle", 220, .4, .03, 1.3, 500, "lowpass", .05)],
	bear: [v("sawtooth", 110, .28, .055, .65, 320), v("noise", 80, .2, .04, 1, 250)],
	dragon: [v("sawtooth", 90, .5, .05, 1.8, 400), v("square", 70, .45, .03, .6, 220, "lowpass", .08)],
	dragon_fire: [v("noise", 500, .35, .06, 1, 1400, "bandpass"), v("sawtooth", 180, .3, .04, .5, 600)],
	lightning: [
		v("noise", 2e3, .22, .09, 1, 3200, "highpass"),
		v("square", 90, .18, .05, .4, 200),
		v("sine", 1400, .05, .03, .3, 3e3, "highpass", .01)
	],
	meteor: [
		v("noise", 80, .45, .08, 1, 280),
		v("sine", 60, .5, .06, .35, 160),
		v("sawtooth", 140, .2, .03, .4, 400, "lowpass", .05)
	],
	fire: [v("noise", 600, .25, .05, 1, 1100, "bandpass"), v("triangle", 160, .16, .03, 1.5, 500)],
	rain: [v("noise", 1e3, .3, .04, 1, 1800, "highpass")],
	blood: [v("sawtooth", 90, .28, .05, .6, 280), v("noise", 200, .22, .04, 1, 500)],
	quake: [v("sine", 42, .6, .08, .7, 120), v("noise", 70, .55, .06, 1, 180)],
	tornado: [v("noise", 400, .45, .05, 1, 700, "bandpass"), v("sawtooth", 160, .4, .03, 1.4, 500)],
	tsunami: [v("noise", 180, .55, .07, 1, 400), v("sine", 70, .5, .04, .6, 160, "lowpass", .04)],
	plague: [v("triangle", 300, .25, .035, .7, 800), v("sine", 450, .3, .02, 1.3, 1200, "lowpass", .08)],
	freeze: [v("sine", 1400, .16, .035, 1.4, 3e3), v("triangle", 1800, .2, .02, 1.1, 3200, "lowpass", .04)],
	heal: [v("sine", 620, .12, .04, 1.3), v("sine", 930, .16, .03, 1.15, 2200, "lowpass", .05)],
	bless: [
		v("triangle", 520, .18, .04, 1.25),
		v("sine", 780, .22, .03, 1.1, 2e3, "lowpass", .06),
		v("sine", 1040, .24, .02, 1, 2400, "lowpass", .12)
	],
	erase: [v("noise", 250, .1, .05, 1, 700), v("sine", 180, .12, .03, .5, 400)],
	war: [
		v("sawtooth", 220, .22, .045, 1.15, 700),
		v("square", 165, .26, .035, 1, 400, "lowpass", .06),
		v("triangle", 330, .2, .025, 1.2, 900, "lowpass", .08)
	],
	peace: [v("sine", 480, .16, .035, 1.15), v("triangle", 720, .2, .025, 1, 1600, "lowpass", .07)],
	splash: [v("noise", 500, .14, .045, 1, 900, "bandpass"), v("sine", 240, .12, .03, 1.6, 700)],
	dawn: [v("sine", 520, .2, .03, 1.2), v("triangle", 780, .24, .02, 1.1, 1800, "lowpass", .08)],
	night: [v("sine", 280, .24, .03, .75, 700), v("triangle", 180, .28, .02, .8, 400, "lowpass", .06)],
	tower: [v("triangle", 740, .06, .03, .5, 2e3), v("noise", 1200, .04, .02, 1, 2500, "highpass")],
	lava: [v("noise", 180, .22, .04, 1, 350), v("sine", 90, .18, .03, 1.3, 200)],
	foot: [v("noise", 160, .04, .03, 1, 400), v("sine", 120, .04, .02, .8, 250)],
	foot_heavy: [v("noise", 90, .06, .045, 1, 250), v("sine", 60, .07, .03, .7, 140)],
	foot_hoof: [v("square", 180, .04, .03, .7, 500), v("noise", 200, .03, .02, 1, 600)],
	foot_paw: [v("noise", 220, .035, .025, 1, 700)],
	roar: [v("sawtooth", 80, .55, .06, 1.7, 360), v("noise", 100, .4, .04, 1, 280, "lowpass", .02)]
};
var Soundscape = class {
	ctx = null;
	master = null;
	musicGain = null;
	sfxGain = null;
	windGain = null;
	rainGain = null;
	nightGain = null;
	padGain = null;
	noiseBuf = null;
	last = /* @__PURE__ */ new Map();
	volumes = {
		master: .8,
		music: .55,
		sfx: .85,
		mute: false
	};
	noteTimer = 1.2;
	weather = "clear";
	night = 0;
	unlock() {
		if (this.ctx) {
			if (this.ctx.state === "suspended") this.ctx.resume();
			return;
		}
		const Ctx = window.AudioContext || window.webkitAudioContext;
		if (!Ctx) return;
		const ctx = new Ctx({ latencyHint: "interactive" });
		const master = ctx.createGain();
		const music = ctx.createGain();
		const sfx = ctx.createGain();
		const wind = ctx.createGain();
		const rain = ctx.createGain();
		const night = ctx.createGain();
		const pad = ctx.createGain();
		music.connect(master);
		sfx.connect(master);
		wind.connect(music);
		rain.connect(music);
		night.connect(music);
		pad.connect(music);
		master.connect(ctx.destination);
		this.ctx = ctx;
		this.master = master;
		this.musicGain = music;
		this.sfxGain = sfx;
		this.windGain = wind;
		this.rainGain = rain;
		this.nightGain = night;
		this.padGain = pad;
		const buffer = ctx.createBuffer(1, ctx.sampleRate * 2, ctx.sampleRate);
		const data = buffer.getChannelData(0);
		let brown = 0;
		for (let i = 0; i < data.length; i++) {
			const white = Math.random() * 2 - 1;
			brown = (brown + .02 * white) / 1.02;
			data[i] = brown * 2.4 + white * .15;
		}
		this.noiseBuf = buffer;
		const windSrc = ctx.createBufferSource();
		windSrc.buffer = buffer;
		windSrc.loop = true;
		const windFilter = ctx.createBiquadFilter();
		windFilter.type = "lowpass";
		windFilter.frequency.value = 420;
		windSrc.connect(windFilter);
		windFilter.connect(wind);
		windSrc.start();
		const rainSrc = ctx.createBufferSource();
		rainSrc.buffer = buffer;
		rainSrc.loop = true;
		const rainFilter = ctx.createBiquadFilter();
		rainFilter.type = "highpass";
		rainFilter.frequency.value = 900;
		rainSrc.connect(rainFilter);
		rainFilter.connect(rain);
		rainSrc.start();
		const nightSrc = ctx.createBufferSource();
		nightSrc.buffer = buffer;
		nightSrc.loop = true;
		const nightFilter = ctx.createBiquadFilter();
		nightFilter.type = "bandpass";
		nightFilter.frequency.value = 2800;
		nightFilter.Q.value = .7;
		nightSrc.connect(nightFilter);
		nightFilter.connect(night);
		nightSrc.start();
		const padOsc = ctx.createOscillator();
		const pad2 = ctx.createOscillator();
		const padFilter = ctx.createBiquadFilter();
		padOsc.type = "triangle";
		pad2.type = "sine";
		padOsc.frequency.value = 110;
		pad2.frequency.value = 164.8;
		padFilter.type = "lowpass";
		padFilter.frequency.value = 480;
		padOsc.connect(padFilter);
		pad2.connect(padFilter);
		padFilter.connect(this.padGain);
		padOsc.start();
		pad2.start();
		this.padGain.gain.value = .03;
		this.applyGains();
		this.applyAmbience();
		ctx.resume();
	}
	setVolumes(master, music, sfx, mute) {
		this.volumes = {
			master: master / 100,
			music: music / 100,
			sfx: sfx / 100,
			mute
		};
		this.applyGains();
	}
	setScene(weather, night) {
		this.weather = weather;
		this.night = night;
		this.applyAmbience();
	}
	suspend() {
		if (this.ctx && this.ctx.state === "running") this.ctx.suspend();
	}
	resume() {
		if (this.ctx && this.ctx.state === "suspended") this.ctx.resume();
	}
	update(dt) {
		if (!this.ctx || !this.musicGain || this.volumes.mute || this.volumes.music <= .01) return;
		this.noteTimer -= dt;
		if (this.noteTimer > 0) return;
		this.noteTimer = this.night > .6 ? 2.6 : 1.8;
		const scale = this.night > .55 ? [
			0,
			3,
			5,
			7,
			10
		] : [
			0,
			2,
			4,
			7,
			9
		];
		const step = scale[Math.floor(Math.random() * scale.length)] ?? 0;
		const midi = (this.night > .55 ? 57 : 62) + step;
		const freq = 440 * Math.pow(2, (midi - 69) / 12);
		this.tone(freq, 1.3, .035);
	}
	play(id, pan = 0) {
		if (!this.ctx || !this.sfxGain || !this.noiseBuf || this.volumes.mute || this.volumes.sfx <= .01) return;
		const now = this.ctx.currentTime;
		const gap = GAPS[id] ?? .04;
		if (now - (this.last.get(id) ?? -10) < gap) return;
		this.last.set(id, now);
		const wobble = id.startsWith("ui_") ? 1 : .94 + Math.random() * .12;
		for (const voice of RECIPES[id]) this.voice(voice, now, Math.max(-1, Math.min(1, pan)), wobble);
	}
	tone(freq, dur, gainValue) {
		if (!this.ctx || !this.musicGain) return;
		const ctx = this.ctx;
		const now = ctx.currentTime;
		const osc = ctx.createOscillator();
		const gain = ctx.createGain();
		const filter = ctx.createBiquadFilter();
		osc.type = "triangle";
		osc.frequency.value = freq;
		filter.type = "lowpass";
		filter.frequency.value = 1400;
		osc.connect(filter);
		filter.connect(gain);
		gain.connect(this.musicGain);
		gain.gain.setValueAtTime(1e-4, now);
		gain.gain.exponentialRampToValueAtTime(gainValue, now + .05);
		gain.gain.exponentialRampToValueAtTime(1e-4, now + dur);
		osc.start(now);
		osc.stop(now + dur + .02);
	}
	voice(voice, now, pan, wobble) {
		if (!this.ctx || !this.sfxGain || !this.noiseBuf) return;
		const ctx = this.ctx;
		const start = now + voice.delay;
		const gain = ctx.createGain();
		const filter = ctx.createBiquadFilter();
		const panner = ctx.createStereoPanner();
		filter.type = voice.filterType;
		filter.frequency.value = voice.filter;
		panner.pan.value = pan;
		filter.connect(gain);
		gain.connect(panner);
		panner.connect(this.sfxGain);
		gain.gain.setValueAtTime(1e-4, start);
		gain.gain.exponentialRampToValueAtTime(Math.max(2e-4, voice.gain), start + .012);
		gain.gain.exponentialRampToValueAtTime(1e-4, start + voice.dur);
		if (voice.osc === "noise") {
			const src = ctx.createBufferSource();
			src.buffer = this.noiseBuf;
			src.playbackRate.value = .6 + voice.f / 2e3 * wobble;
			src.connect(filter);
			src.start(start);
			src.stop(start + voice.dur + .02);
			src.onended = () => {
				src.disconnect();
				filter.disconnect();
				gain.disconnect();
				panner.disconnect();
			};
			return;
		}
		const osc = ctx.createOscillator();
		osc.type = voice.osc;
		const f0 = Math.max(30, voice.f * wobble);
		const f1 = Math.max(30, f0 * voice.slide);
		osc.frequency.setValueAtTime(f0, start);
		osc.frequency.exponentialRampToValueAtTime(f1, start + voice.dur);
		osc.connect(filter);
		osc.start(start);
		osc.stop(start + voice.dur + .02);
		osc.onended = () => {
			osc.disconnect();
			filter.disconnect();
			gain.disconnect();
			panner.disconnect();
		};
	}
	applyGains() {
		if (!this.master || !this.musicGain || !this.sfxGain || !this.ctx) return;
		const m = this.volumes.mute ? 0 : this.volumes.master * this.volumes.master;
		const now = this.ctx.currentTime;
		this.master.gain.setTargetAtTime(m, now, .04);
		this.musicGain.gain.setTargetAtTime(this.volumes.music * this.volumes.music, now, .05);
		this.sfxGain.gain.setTargetAtTime(this.volumes.sfx * this.volumes.sfx, now, .04);
	}
	applyAmbience() {
		if (!this.windGain || !this.rainGain || !this.nightGain || !this.ctx) return;
		const now = this.ctx.currentTime;
		const rain = this.weather === "rain" || this.weather === "storm" || this.weather === "blood" ? .22 : .001;
		const wind = this.weather === "storm" ? .2 : this.weather === "cloudy" ? .1 : .06;
		this.windGain.gain.setTargetAtTime(wind, now, .4);
		this.rainGain.gain.setTargetAtTime(rain, now, .4);
		this.nightGain.gain.setTargetAtTime(.001 + this.night * .045, now, .5);
	}
};
var SIZE_SPAN = {
	small: 48,
	medium: 72,
	large: 96
};
var CATS = [
	{
		id: "bangsa",
		tools: [
			"human",
			"elf",
			"orc",
			"dwarf",
			"warrior",
			"king"
		]
	},
	{
		id: "satwa",
		tools: [
			"chicken",
			"sheep",
			"cow",
			"deer",
			"wolf",
			"bear",
			"tiger",
			"dragon"
		]
	},
	{
		id: "alam",
		tools: [
			"tree",
			"pine",
			"palm",
			"rock",
			"bush",
			"flower",
			"grass",
			"sand",
			"forest",
			"snow",
			"swamp",
			"road",
			"lava"
		]
	},
	{
		id: "kota",
		tools: [
			"house",
			"farm",
			"tower",
			"castle",
			"shrine",
			"market",
			"wall",
			"boat",
			"firepit"
		]
	},
	{
		id: "bencana",
		tools: [
			"lightning",
			"meteor",
			"fire",
			"rain",
			"blood",
			"quake",
			"tornado",
			"tsunami",
			"plague"
		]
	},
	{
		id: "kuasa",
		tools: [
			"finger",
			"heal",
			"bless",
			"freeze",
			"peace",
			"warhorn",
			"erase"
		]
	}
];
function clamp(v, a, b) {
	return Math.max(a, Math.min(b, v));
}
function applyPreset(preset) {
	if (preset === "low") return {
		preset,
		resolution: 70,
		shadows: "low",
		vegetation: 55,
		viewDistance: 90,
		showFps: true,
		showPerf: false
	};
	if (preset === "medium") return {
		preset,
		resolution: 85,
		shadows: "medium",
		vegetation: 80,
		viewDistance: 120,
		showFps: true,
		showPerf: false
	};
	if (preset === "ultra") return {
		preset,
		resolution: 100,
		shadows: "high",
		vegetation: 100,
		viewDistance: 170,
		showFps: true,
		showPerf: false
	};
	return {
		preset: "high",
		resolution: 100,
		shadows: "high",
		vegetation: 100,
		viewDistance: 145,
		showFps: true,
		showPerf: false
	};
}
function defaultSettings() {
	return {
		version: 1,
		lang: "id",
		graphics: applyPreset("high"),
		audio: {
			master: 80,
			music: 55,
			sfx: 85,
			mute: false
		}
	};
}
var PEOPLE = [
	"Sari",
	"Bima",
	"Laras",
	"Dimas",
	"Wulan",
	"Guntur",
	"Maya",
	"Raka",
	"Intan",
	"Bayu",
	"Nadine",
	"Farid",
	"Cahya",
	"Putri",
	"Arka",
	"Dewi",
	"Yoga",
	"Sinta",
	"Hari",
	"Lestari",
	"Jaka",
	"Ayu",
	"Rama",
	"Diah",
	"Eka",
	"Nisa",
	"Tegar",
	"Mega",
	"Ilham",
	"Kirana"
];
var KNAMES = {
	human: [
		"Arun Pesisir",
		"Desa Fajar",
		"Negeri Sawah",
		"Kota Terang",
		"Kampung Daun"
	],
	elf: [
		"Rimba Sunyi",
		"Hutan Embun",
		"Dahan Putih",
		"Cahaya Lumut",
		"Sudut Hijau"
	],
	orc: [
		"Gua Merah",
		"Suku Batu",
		"Lembah Arang",
		"Taring Hitam",
		"Bukit Debu"
	],
	dwarf: [
		"Balai Palu",
		"Tambang Dalam",
		"Puncak Logam",
		"Terowongan Raja",
		"Dinding Besi"
	]
};
var RCOLORS = {
	human: [
		"#3e6f9a",
		"#2f5d86",
		"#4e7eaa"
	],
	elf: [
		"#2f7a52",
		"#246846",
		"#3c8d62"
	],
	orc: [
		"#8d4d32",
		"#6f3c28",
		"#a05a3a"
	],
	dwarf: [
		"#8d3d3d",
		"#6e3030",
		"#a35248"
	]
};
var BIOME = {
	grass: 0,
	sand: 1,
	forest: 2,
	snow: 3,
	swamp: 4,
	rock: 5,
	scorch: 6,
	road: 7,
	lava: 8
};
function mulberry32(seed) {
	let a = seed >>> 0;
	return () => {
		a |= 0;
		a = a + 1831565813 | 0;
		let t = Math.imul(a ^ a >>> 15, 1 | a);
		t = t + Math.imul(t ^ t >>> 7, 61 | t) ^ t;
		return ((t ^ t >>> 14) >>> 0) / 4294967296;
	};
}
function hash(ix, iz, seed) {
	let n = Math.imul(ix, 374761393) + Math.imul(iz, 668265263) + Math.imul(seed, 1442695041);
	n = Math.imul(n ^ n >>> 13, 1274126177);
	return ((n ^ n >>> 16) >>> 0) / 4294967296;
}
function noise(x, z, seed) {
	const x0 = Math.floor(x);
	const z0 = Math.floor(z);
	const fx = x - x0;
	const fz = z - z0;
	const sx = fx * fx * (3 - 2 * fx);
	const sz = fz * fz * (3 - 2 * fz);
	const a = hash(x0, z0, seed);
	const b = hash(x0 + 1, z0, seed);
	const c = hash(x0, z0 + 1, seed);
	const d = hash(x0 + 1, z0 + 1, seed);
	return a + (b - a) * sx + (c - a) * sz + (a - b - c + d) * sx * sz;
}
function fbm(x, z, seed) {
	let v = 0;
	let a = .5;
	let f = 1;
	for (let i = 0; i < 5; i++) {
		v += a * noise(x * f, z * f, seed + i * 19);
		a *= .5;
		f *= 2;
	}
	return v;
}
function b64(bytes) {
	let s = "";
	const chunk = 4096;
	for (let i = 0; i < bytes.length; i += chunk) {
		const slice = bytes.subarray(i, i + chunk);
		let part = "";
		for (let j = 0; j < slice.length; j++) part += String.fromCharCode(slice[j] ?? 0);
		s += part;
	}
	return btoa(s);
}
function unb64(s) {
	const bin = atob(s);
	const out = new Uint8Array(bin.length);
	for (let i = 0; i < bin.length; i++) out[i] = bin.charCodeAt(i);
	return out;
}
var LIMITS = {
	unit: 160,
	tree: 340,
	rock: 120,
	prop: 220,
	building: 140
};
var WorldSim = class WorldSim {
	id;
	name;
	sizeId;
	seed;
	span;
	res;
	height;
	biome;
	waterBase = 1.72;
	waterLevel = 1.72;
	time = 8.2;
	day = 1;
	year = 1;
	weather = "clear";
	weatherT = 48;
	tsunami = 0;
	quake = 0;
	tornado = null;
	units = [];
	buildings = [];
	trees = [];
	rocks = [];
	props = [];
	kingdoms = [];
	selected = null;
	terrainDirty = true;
	scatterDirty = true;
	births = 0;
	deaths = 0;
	raceBrush = "human";
	sfxQ = [];
	fxQ = [];
	log = [];
	toast = null;
	nextId = 1;
	rand;
	warT = 2;
	compact = false;
	dawnSent = false;
	eventT = 20;
	constructor(opts) {
		this.id = opts.id ?? `w-${opts.seed.toString(36)}-${Math.floor(Math.random() * 1e6).toString(36)}`;
		this.name = opts.name;
		this.sizeId = opts.size;
		this.seed = opts.seed >>> 0;
		this.span = SIZE_SPAN[opts.size];
		this.res = this.span + 1;
		this.height = new Float32Array(this.res * this.res);
		this.biome = new Uint8Array(this.res * this.res);
		this.rand = mulberry32(this.seed ^ 2654435769);
		this.generate();
		this.scatter();
		this.seedVillages();
	}
	static fromSave(raw) {
		try {
			const data = JSON.parse(raw);
			if (data.version !== 1 || !data.height) return null;
			const sim = new WorldSim({
				name: data.name,
				size: data.size,
				seed: data.seed,
				id: data.id
			});
			const hBytes = unb64(data.height);
			const bBytes = unb64(data.biome);
			if (hBytes.byteLength !== sim.height.byteLength || bBytes.length !== sim.biome.length) return null;
			sim.height.set(new Float32Array(hBytes.buffer, hBytes.byteOffset, sim.height.length));
			sim.biome.set(bBytes);
			sim.time = data.time;
			sim.day = data.day;
			sim.year = data.year;
			sim.weather = data.weather;
			sim.weatherT = data.weatherT;
			sim.waterLevel = data.waterLevel;
			sim.nextId = data.nextId;
			sim.units = data.units;
			sim.buildings = data.buildings;
			sim.trees = data.trees;
			sim.rocks = data.rocks;
			sim.props = data.props;
			sim.kingdoms = data.kingdoms;
			sim.births = data.births;
			sim.deaths = data.deaths;
			sim.terrainDirty = true;
			sim.scatterDirty = true;
			return sim;
		} catch {
			return null;
		}
	}
	serialize() {
		const blob = {
			version: 1,
			id: this.id,
			name: this.name,
			savedAt: Date.now(),
			size: this.sizeId,
			seed: this.seed,
			span: this.span,
			time: this.time,
			day: this.day,
			year: this.year,
			weather: this.weather,
			weatherT: this.weatherT,
			waterLevel: this.waterLevel,
			nextId: this.nextId,
			height: b64(new Uint8Array(this.height.buffer, this.height.byteOffset, this.height.byteLength)),
			biome: b64(this.biome),
			units: this.units.filter((u) => u.alive),
			buildings: this.buildings.filter((b) => b.alive),
			trees: this.trees,
			rocks: this.rocks.filter((r) => r.alive),
			props: this.props.filter((p) => p.alive),
			kingdoms: this.kingdoms,
			births: this.births,
			deaths: this.deaths
		};
		return JSON.stringify(blob);
	}
	heightAt(x, z) {
		const max = this.span;
		const xc = clamp(x, 0, max);
		const zc = clamp(z, 0, max);
		const x0 = Math.floor(xc);
		const z0 = Math.floor(zc);
		const x1 = Math.min(max, x0 + 1);
		const z1 = Math.min(max, z0 + 1);
		const tx = xc - x0;
		const tz = zc - z0;
		const n = this.res;
		const h00 = this.height[z0 * n + x0] ?? 0;
		const h10 = this.height[z0 * n + x1] ?? 0;
		const h01 = this.height[z1 * n + x0] ?? 0;
		const h11 = this.height[z1 * n + x1] ?? 0;
		return h00 + (h10 - h00) * tx + (h01 + (h11 - h01) * tx - (h00 + (h10 - h00) * tx)) * tz;
	}
	biomeAt(x, z) {
		const xi = clamp(Math.round(x), 0, this.span);
		const zi = clamp(Math.round(z), 0, this.span);
		return this.biome[zi * this.res + xi] ?? 0;
	}
	popCount() {
		let n = 0;
		for (const u of this.units) if (u.alive && u.kind === "person") n++;
		return n;
	}
	tick(dt) {
		dt = Math.min(dt, .45);
		const prev = this.time;
		this.time = (this.time + dt * (24 / 96)) % 24;
		if (prev > 20 && this.time < 6) {
			this.day += 1;
			if (this.day % 8 === 0) this.year += 1;
		}
		const dawn = this.time >= 5.4 && this.time < 6.3;
		if (dawn && !this.dawnSent) {
			this.dawnSent = true;
			this.sfx("dawn", this.span / 2, this.span / 2);
			this.pushLog({ t: "dawn" });
		}
		if (!dawn) this.dawnSent = false;
		if (prev < 19.6 && this.time >= 19.6) this.sfx("night", this.span / 2, this.span / 2);
		this.weatherT -= dt;
		if (this.weatherT <= 0 && this.weather !== "blood") {
			const r = this.rand();
			const next = r < .55 ? "clear" : r < .75 ? "cloudy" : r < .92 ? "rain" : "storm";
			if (next !== this.weather) this.pushLog({ t: "storm" });
			this.weather = next;
			this.weatherT = 36 + this.rand() * 40;
			if (next === "rain" || next === "storm") this.sfx("rain", this.span / 2, this.span / 2);
		}
		if (this.weather === "rain" || this.weather === "storm") {
			for (const t of this.trees) t.burn = Math.max(0, t.burn - dt * 2);
			for (const u of this.units) u.burn = Math.max(0, u.burn - dt * 2);
		}
		if (this.tsunami > 0) {
			this.tsunami -= dt;
			this.waterLevel = this.waterBase + Math.sin((1 - this.tsunami / 8) * Math.PI) * 2.15;
		} else this.waterLevel += (this.waterBase - this.waterLevel) * Math.min(1, dt * 1.5);
		if (this.quake > 0) this.quake -= dt;
		if (this.tornado) {
			const tor = this.tornado;
			tor.life -= dt;
			tor.x += tor.vx * dt;
			tor.z += tor.vz * dt;
			tor.vx += (this.rand() - .5) * dt * 8;
			tor.vz += (this.rand() - .5) * dt * 8;
			if (tor.life <= 0 || tor.x < 2 || tor.z < 2 || tor.x > this.span - 2 || tor.z > this.span - 2) this.tornado = null;
		}
		this.growKingdoms(dt);
		this.tickBuildings(dt);
		for (const tree of this.trees) if (!tree.alive) {
			tree.regrow -= dt;
			if (tree.regrow <= 0 && this.biomeAt(tree.x, tree.z) !== BIOME.road && this.biomeAt(tree.x, tree.z) !== BIOME.lava) {
				tree.alive = true;
				tree.hp = tree.maxHp;
				tree.burn = 0;
			}
		} else if (tree.burn > 0) {
			tree.burn -= dt;
			tree.hp -= dt * .8;
			if (tree.hp <= 0) {
				tree.alive = false;
				tree.regrow = 36;
			}
		}
		for (const u of this.units) this.tickUnit(u, dt);
		if (this.compact) {
			this.units = this.units.filter((u) => u.alive || u.fade > 0);
			this.buildings = this.buildings.filter((b) => b.alive);
			this.compact = false;
		}
		this.warT -= dt;
		if (this.warT <= 0) {
			this.warT = 2.4;
			this.considerWars();
		}
		this.eventT -= dt;
		if (this.eventT <= 0) {
			this.eventT = 24 + this.rand() * 30;
			this.rollEvent();
		}
	}
	apply(tool, x, z, brush) {
		if (!this.inMap(x, z)) {
			this.toast = "needLand";
			this.sfx("ui_error", x, z);
			return false;
		}
		const many = brush > 1;
		const spots = many ? this.ring(x, z, 5) : [{
			x,
			z
		}];
		if (tool === "human" || tool === "elf" || tool === "orc" || tool === "dwarf") this.raceBrush = tool;
		if ((/* @__PURE__ */ new Set([
			"lightning",
			"meteor",
			"fire",
			"rain",
			"blood",
			"quake",
			"tornado",
			"tsunami",
			"plague",
			"freeze",
			"heal",
			"bless",
			"peace",
			"warhorn",
			"finger"
		])).has(tool)) return this.power(tool, x, z, many ? 1.45 : 1);
		let ok = false;
		for (const s of spots) if (this.placeOne(tool, s.x, s.z)) ok = true;
		if (!ok && this.toast == null) {
			this.toast = "needLand";
			this.sfx("ui_error", x, z);
		}
		return ok;
	}
	selectAt(x, z) {
		let best = null;
		let bestD = 2.6;
		for (const u of this.units) {
			if (!u.alive) continue;
			const d = Math.hypot(u.x - x, u.z - z);
			const reach = u.race === "dragon" ? 3.4 : u.kind === "animal" ? 2.2 : 1.8;
			if (d < bestD && d < reach) {
				best = u;
				bestD = d;
			}
		}
		if (best) {
			this.selected = {
				kind: "unit",
				id: best.id
			};
			this.sfx("select", best.x, best.z);
			return this.inspectUnit(best);
		}
		let house = null;
		bestD = 2.4;
		for (const b of this.buildings) {
			if (!b.alive) continue;
			const d = Math.hypot(b.x - x, b.z - z);
			if (d < bestD) {
				house = b;
				bestD = d;
			}
		}
		if (house) {
			this.selected = {
				kind: "building",
				id: house.id
			};
			this.sfx("select", house.x, house.z);
			const king = this.kingdoms.find((k) => k.id === house?.kingdom);
			return {
				id: house.id,
				kind: "building",
				title: house.type,
				subtitle: house.type,
				hp: house.hp,
				maxHp: house.maxHp,
				hunger: null,
				state: "wander",
				kingdom: king?.name ?? null,
				color: king?.color ?? null
			};
		}
		this.selected = null;
		return null;
	}
	rollEvent() {
		const r = this.rand();
		const land = this.findLand(this.span * .5, this.span * .45);
		if (r < .2) {
			const k = this.kingdoms.find((kk) => !kk.fallen);
			if (!k) return;
			k.food = Math.min(100, k.food + 12);
			k.wood = Math.min(80, k.wood + 6);
			k.boost = Math.max(k.boost, 16);
			this.toast = "event_festival";
			this.sfx("bless", k.hx, k.hz);
		} else if (r < .38) {
			this.weather = "cloudy";
			this.weatherT = 18;
			this.toast = "event_eclipse";
			this.sfx("night", this.span / 2, this.span / 2);
		} else if (r < .56 && land) {
			for (let i = 0; i < 3; i++) this.addAnimal("deer", land.x + i * 1.1, land.z + i % 2);
			this.toast = "event_bounty";
			this.sfx("deer", land.x, land.z);
		} else if (r < .72) {
			const k = this.kingdoms.find((kk) => !kk.fallen);
			if (!k) return;
			this.spawnPerson(k.race, "villager", k.hx + 1.4, k.hz + .5, k.id);
			this.toast = "event_pilgrim";
			this.sfx("place_human", k.hx, k.hz);
		} else if (r < .86) {
			for (const k of this.kingdoms) if (!k.fallen) k.food = Math.max(0, k.food - 7);
			this.toast = "event_drought";
			this.sfx("ui_error", this.span / 2, this.span / 2);
		} else {
			for (const u of this.units) {
				if (!u.alive) continue;
				u.hp = Math.min(u.maxHp, u.hp + 10);
				u.plague = 0;
			}
			this.toast = "event_aurora";
			this.sfx("heal", this.span / 2, this.span / 2);
			this.fxQ.push({
				kind: "heal",
				x: this.span / 2,
				y: 4,
				z: this.span / 2,
				life: .9,
				max: .9
			});
		}
	}
	power(tool, x, z, scale) {
		const r = (n) => n * scale;
		if (tool === "finger") return true;
		if (tool === "lightning") {
			this.hurtArea(x, z, r(2.4), 46, true);
			this.scorch(x, z, r(1.6));
			this.fxQ.push({
				kind: "lightning",
				x,
				y: this.heightAt(x, z),
				z,
				life: .22,
				max: .22
			});
			this.sfx("lightning", x, z);
			return true;
		}
		if (tool === "meteor") {
			this.crater(x, z, r(5.5));
			this.hurtArea(x, z, r(6.2), 90, true);
			this.fxQ.push({
				kind: "meteor",
				x,
				y: this.heightAt(x, z),
				z,
				life: .7,
				max: .7
			});
			this.sfx("meteor", x, z);
			this.pushLog({ t: "meteor" });
			return true;
		}
		if (tool === "fire") {
			this.ignite(x, z, r(3.4));
			this.sfx("fire", x, z);
			return true;
		}
		if (tool === "rain") {
			this.weather = "rain";
			this.weatherT = 28;
			this.sfx("rain", x, z);
			this.pushLog({ t: "storm" });
			return true;
		}
		if (tool === "blood") {
			this.weather = "blood";
			this.weatherT = 14;
			this.sfx("blood", x, z);
			return true;
		}
		if (tool === "quake") {
			this.quake = 4.5;
			this.shakeTerrain(x, z, r(10));
			this.hurtArea(x, z, r(9), 18, false);
			this.sfx("quake", x, z);
			return true;
		}
		if (tool === "tornado") {
			this.tornado = {
				x,
				z,
				life: 12,
				vx: (this.rand() - .5) * 6,
				vz: (this.rand() - .5) * 6
			};
			this.sfx("tornado", x, z);
			return true;
		}
		if (tool === "tsunami") {
			this.tsunami = 8;
			this.sfx("tsunami", x, z);
			return true;
		}
		if (tool === "plague") {
			for (const u of this.units) if (u.alive && Math.hypot(u.x - x, u.z - z) < r(5)) u.plague = Math.max(u.plague, 10);
			this.sfx("plague", x, z);
			return true;
		}
		if (tool === "freeze") {
			for (const u of this.units) if (u.alive && Math.hypot(u.x - x, u.z - z) < r(5)) u.frozen = Math.max(u.frozen, 7);
			this.sfx("freeze", x, z);
			this.fxQ.push({
				kind: "heal",
				x,
				y: this.heightAt(x, z),
				z,
				life: .6,
				max: .6
			});
			return true;
		}
		if (tool === "heal") {
			for (const u of this.units) {
				if (!u.alive || Math.hypot(u.x - x, u.z - z) > r(4.5)) continue;
				u.hp = u.maxHp;
				u.plague = 0;
				u.burn = 0;
				u.frozen = 0;
				u.hunger = Math.min(u.hunger, .2);
			}
			this.sfx("heal", x, z);
			this.fxQ.push({
				kind: "heal",
				x,
				y: this.heightAt(x, z),
				z,
				life: .7,
				max: .7
			});
			return true;
		}
		if (tool === "bless") {
			const k = this.nearestKingdom(x, z);
			if (!k) {
				this.toast = "needLand";
				this.sfx("ui_error", x, z);
				return false;
			}
			k.food = Math.min(100, k.food + 14);
			k.wood = Math.min(80, k.wood + 10);
			k.boost = 26;
			this.sfx("bless", k.hx, k.hz);
			return true;
		}
		if (tool === "peace" || tool === "warhorn") {
			const pair = this.nearestPair(x, z);
			if (!pair) {
				this.toast = "needTwo";
				this.sfx("ui_error", x, z);
				return false;
			}
			if (tool === "peace") {
				pair[0].wars = pair[0].wars.filter((id) => id !== pair[1].id);
				pair[1].wars = pair[1].wars.filter((id) => id !== pair[0].id);
				this.sfx("peace", x, z);
				this.pushLog({
					t: "peace",
					a: pair[0].name,
					b: pair[1].name
				});
			} else this.declare(pair[0], pair[1]);
			return true;
		}
		return false;
	}
	placeOne(tool, x, z) {
		const h = this.heightAt(x, z);
		const wet = h < this.waterLevel + .18;
		const land = !wet && h < 7.2;
		if (tool === "erase") {
			this.erase(x, z, 2.4);
			this.sfx("erase", x, z);
			return true;
		}
		if (tool === "boat") {
			if (!wet) return false;
			return this.addBuilding("boat", x, z, -1);
		}
		if (tool === "grass" || tool === "sand" || tool === "forest" || tool === "snow" || tool === "swamp" || tool === "road" || tool === "lava") {
			const map = {
				grass: BIOME.grass,
				sand: BIOME.sand,
				forest: BIOME.forest,
				snow: BIOME.snow,
				swamp: BIOME.swamp,
				road: BIOME.road,
				lava: BIOME.lava
			};
			this.paint(x, z, tool === "road" ? 1.6 : 3.2, map[tool] ?? 0);
			this.sfx(tool === "lava" ? "lava" : "place_bush", x, z);
			return true;
		}
		if (tool === "tree" || tool === "pine" || tool === "palm") {
			if (!land) return false;
			const kind = tool === "pine" ? "pine" : tool === "palm" ? "palm" : "oak";
			return this.addTree(kind, x, z);
		}
		if (tool === "rock") return land && this.addRock(x, z);
		if (tool === "bush" || tool === "flower") return land && this.addProp(tool, x, z);
		if (tool === "house" || tool === "farm" || tool === "tower" || tool === "castle" || tool === "shrine" || tool === "market" || tool === "wall" || tool === "firepit") {
			if (!land) return false;
			const king = this.nearestKingdom(x, z);
			return this.addBuilding(tool, x, z, king?.id ?? -1);
		}
		if (tool === "chicken" || tool === "sheep" || tool === "cow" || tool === "deer" || tool === "wolf" || tool === "bear" || tool === "tiger" || tool === "dragon") {
			if (tool !== "dragon" && !land) return false;
			return this.addAnimal(tool, x, z);
		}
		if (tool === "human" || tool === "elf" || tool === "orc" || tool === "dwarf" || tool === "warrior" || tool === "king") {
			if (!land) return false;
			const race = tool === "warrior" || tool === "king" ? this.raceBrush : tool;
			const role = tool === "warrior" ? "warrior" : tool === "king" ? "king" : "villager";
			return this.addPerson(race, role, x, z);
		}
		return false;
	}
	tickUnit(u, dt) {
		if (!u.alive) {
			u.fade -= dt * 1.8;
			if (u.fade <= 0) this.compact = true;
			return;
		}
		u.age += dt;
		u.hit = Math.max(0, u.hit - dt);
		if (u.frozen > 0) u.frozen -= dt;
		if (u.burn > 0) {
			u.burn -= dt;
			u.hp -= dt * 7;
		}
		if (u.plague > 0) {
			u.plague -= dt;
			u.hp -= dt * 3.2;
			if (this.rand() < dt * .35) {
				const other = this.nearestUnit(u.x, u.z, 2.2, (o) => o.id !== u.id && o.alive && o.plague <= 0);
				if (other) other.plague = 8;
			}
		}
		if (this.biomeAt(u.x, u.z) === BIOME.lava && u.race !== "dragon") {
			u.burn = Math.max(u.burn, 1.5);
			u.hp -= dt * 10;
		}
		if (this.waterLevel > this.waterBase + .8 && this.heightAt(u.x, u.z) < this.waterLevel - .2 && u.race !== "dragon") u.hp -= dt * 6;
		if (this.tornado && u.race !== "dragon") {
			const d = Math.hypot(u.x - this.tornado.x, u.z - this.tornado.z);
			if (d < 6 && d > .15) {
				u.x += (this.tornado.x - u.x) / d * 7 * dt;
				u.z += (this.tornado.z - u.z) / d * 7 * dt;
				u.hp -= dt * 6;
			}
		}
		if (this.weather === "blood" && u.kind === "person") u.hp -= dt * 2.4;
		if (u.kind === "person") {
			const night = this.isNight();
			u.hunger = Math.min(1.4, u.hunger + dt * (night && u.intent === "sleep" ? .004 : .011));
			if (u.hunger > 1) u.hp -= dt * 4;
		}
		if (u.hp <= 0) {
			this.kill(u);
			return;
		}
		if (u.frozen > 0) {
			u.moving = false;
			return;
		}
		if (u.role === "baby" && u.age > 22) {
			u.role = "villager";
			u.maxHp = 36;
			u.hp = 36;
		}
		u.timer -= dt;
		if (u.timer <= 0) {
			u.timer = .75 + this.rand() * .55;
			this.decide(u);
		}
		this.act(u, dt);
		this.steer(u, dt);
	}
	decide(u) {
		if (u.kind === "animal") {
			this.decideAnimal(u);
			return;
		}
		const king = this.kingdoms.find((k) => k.id === u.kingdom && !k.fallen);
		const threat = this.nearestHostile(u, u.role === "warrior" ? 16 : 8);
		if (threat && (u.role === "villager" || u.role === "baby") && (u.hp < u.maxHp * .85 || u.role === "baby")) {
			u.intent = "flee";
			u.target = threat.id;
			return;
		}
		if (threat && u.role !== "baby" && (u.role === "warrior" || u.role === "king" || Math.hypot(threat.x - u.x, threat.z - u.z) < 2.3)) {
			u.intent = "fight";
			u.target = threat.id;
			return;
		}
		if (this.isNight() && u.role !== "warrior") {
			const home = this.nearestBuilding(u, "house");
			if (home) {
				u.intent = "sleep";
				u.target = home.id;
				return;
			}
		}
		if (king && u.hunger > .72 && king.food > 0) {
			u.intent = "eat";
			u.tx = king.hx;
			u.tz = king.hz;
			u.target = -1;
			return;
		}
		if (!king || u.role === "baby") {
			this.wander(u, king);
			return;
		}
		if (u.role === "villager" || u.role === "king") {
			const boost = king.boost > 0;
			if (king.wood < (boost ? 24 : 16)) {
				const tree = this.nearestTree(u.x, u.z, 20);
				if (tree) {
					u.intent = "chop";
					u.target = tree.id;
					return;
				}
			}
			if (king.food < 14) {
				const farm = this.nearestBuilding(u, "farm");
				if (farm) {
					u.intent = "farm";
					u.target = farm.id;
					return;
				}
			}
			if (king.stone < 8) {
				const rock = this.nearestRock(u.x, u.z, 18);
				if (rock) {
					u.intent = "mine";
					u.target = rock.id;
					return;
				}
			}
			const houses = this.buildings.filter((b) => b.alive && b.type === "house" && b.kingdom === king.id).length;
			const pop = this.units.filter((p) => p.alive && p.kingdom === king.id).length;
			if (king.wood >= 6 && houses < Math.max(1, Math.ceil(pop / 3))) {
				const spot = this.siteNear(king.hx, king.hz, 3.2);
				if (spot) {
					u.intent = "build";
					u.build = "house";
					u.tx = spot.x;
					u.tz = spot.z;
					u.work = 0;
					return;
				}
			}
			const farms = this.buildings.filter((b) => b.alive && b.type === "farm" && b.kingdom === king.id).length;
			if (king.wood >= 3 && farms < 2 && king.food < 24) {
				const spot = this.siteNear(king.hx, king.hz, 3);
				if (spot) {
					u.intent = "build";
					u.build = "farm";
					u.tx = spot.x;
					u.tz = spot.z;
					u.work = 0;
					return;
				}
			}
			if (king.wars.length > 0 && king.stone >= 4) {
				if (this.buildings.filter((b) => b.alive && b.type === "tower" && b.kingdom === king.id).length < 2) {
					const spot = this.siteNear(king.hx, king.hz, 2.6);
					if (spot) {
						u.intent = "build";
						u.build = "tower";
						u.tx = spot.x;
						u.tz = spot.z;
						u.work = 0;
						return;
					}
				}
			}
		}
		this.wander(u, king);
	}
	decideAnimal(u) {
		if (u.race === "dragon") {
			const k = this.kingdoms.find((kk) => !kk.fallen);
			if (k && this.rand() < .6) {
				u.tx = k.hx + (this.rand() - .5) * 8;
				u.tz = k.hz + (this.rand() - .5) * 8;
			} else this.wander(u, null);
			u.intent = "wander";
			if (u.cool <= 0 && k && Math.hypot(u.x - k.hx, u.z - k.hz) < 12) {
				u.cool = 5.5;
				this.ignite(u.x, u.z, 2.8);
				this.sfx("dragon_fire", u.x, u.z);
				this.pushLog({ t: "dragon" });
			}
			return;
		}
		if (u.race === "wolf" || u.race === "bear" || u.race === "tiger") {
			const prey = this.nearestUnit(u.x, u.z, u.race === "bear" ? 9 : 14, (o) => {
				if (!o.alive || o.id === u.id) return false;
				if (u.race === "tiger") return o.kind === "person" || o.race === "deer" || o.race === "cow" || o.race === "sheep";
				if (u.race === "wolf") return o.race === "deer" || o.race === "chicken" || o.race === "sheep" || o.kind === "person";
				return o.kind === "person" || o.race === "cow" || o.race === "deer";
			});
			if (prey) {
				u.intent = "fight";
				u.target = prey.id;
				return;
			}
		}
		if (u.race === "deer" || u.race === "sheep" || u.race === "chicken" || u.race === "cow") {
			const hunter = this.nearestUnit(u.x, u.z, 8, (o) => o.alive && (o.race === "wolf" || o.race === "bear" || o.race === "tiger" || o.race === "dragon" || o.role === "warrior"));
			if (hunter) {
				u.intent = "flee";
				u.target = hunter.id;
				return;
			}
		}
		this.wander(u, null);
	}
	act(u, dt) {
		const king = this.kingdoms.find((k) => k.id === u.kingdom);
		const rate = king?.boost ? 1.65 : 1;
		if (u.intent === "fight") {
			const foe = this.byId(u.target);
			if (!foe || !foe.alive) {
				u.intent = "wander";
				return;
			}
			if (Math.hypot(foe.x - u.x, foe.z - u.z) < (u.race === "dragon" ? 3.2 : 1.45)) {
				u.tx = u.x;
				u.tz = u.z;
				u.cool -= dt;
				if (u.cool <= 0) {
					u.cool = u.race === "dragon" ? 1.3 : .78;
					const dmg = u.role === "warrior" ? 11 : u.role === "king" ? 8 : u.race === "tiger" ? 13 : u.race === "wolf" ? 9 : u.race === "bear" ? 14 : u.race === "dragon" ? 18 : u.kind === "animal" ? 4 : 5;
					foe.hp -= dmg;
					foe.hit = .18;
					this.sfx(u.kind === "animal" ? u.race === "dragon" ? "roar" : "bite" : "sword", u.x, u.z);
					if (foe.hp <= 0) this.kill(foe, king?.id ?? -1);
				}
			} else {
				u.tx = foe.x;
				u.tz = foe.z;
			}
			return;
		}
		if (u.intent === "chop") {
			const tree = this.trees.find((t) => t.id === u.target && t.alive);
			if (!tree) {
				u.intent = "wander";
				return;
			}
			if (Math.hypot(tree.x - u.x, tree.z - u.z) < 1.35) {
				u.work += dt * rate;
				if (u.work > .85) {
					u.work = 0;
					tree.hp -= 1;
					if (king) king.wood = Math.min(80, king.wood + 1);
					this.sfx("chop", tree.x, tree.z);
					if (tree.hp <= 0) {
						tree.alive = false;
						tree.regrow = 34;
						if (king) king.wood = Math.min(80, king.wood + 2);
						u.intent = "wander";
					}
				}
			} else {
				u.tx = tree.x;
				u.tz = tree.z;
			}
			return;
		}
		if (u.intent === "mine") {
			const rock = this.rocks.find((t) => t.id === u.target && t.alive);
			if (!rock) {
				u.intent = "wander";
				return;
			}
			if (Math.hypot(rock.x - u.x, rock.z - u.z) < 1.45) {
				u.work += dt * rate;
				if (u.work > 1) {
					u.work = 0;
					rock.hp -= 1;
					if (king) king.stone = Math.min(60, king.stone + 1);
					this.sfx("mine", rock.x, rock.z);
					if (rock.hp <= 0) {
						rock.alive = false;
						u.intent = "wander";
					}
				}
			} else {
				u.tx = rock.x;
				u.tz = rock.z;
			}
			return;
		}
		if (u.intent === "farm") {
			const farm = this.buildings.find((b) => b.id === u.target && b.alive);
			if (!farm) {
				u.intent = "wander";
				return;
			}
			u.tx = farm.x;
			u.tz = farm.z;
			if (Math.hypot(farm.x - u.x, farm.z - u.z) < 1.6 && king) king.food = Math.min(100, king.food + dt * .55 * rate);
			return;
		}
		if (u.intent === "build" && u.build) {
			if (Math.hypot(u.tx - u.x, u.tz - u.z) < 1.3) {
				u.work += dt * rate;
				if (Math.floor(u.work * 2) !== Math.floor((u.work - dt) * 2)) this.sfx("hammer", u.x, u.z);
				const cost = u.build === "house" ? {
					wood: 6,
					stone: 0
				} : u.build === "farm" ? {
					wood: 3,
					stone: 0
				} : {
					wood: 1,
					stone: 4
				};
				if (u.work > 3.1) {
					if (king && king.wood >= cost.wood && king.stone >= cost.stone && this.siteFree(u.tx, u.tz, 2.2)) {
						king.wood -= cost.wood;
						king.stone -= cost.stone;
						this.addBuilding(u.build, u.tx, u.tz, king.id, true);
					}
					u.intent = "wander";
					u.work = 0;
				}
			}
			return;
		}
		if (u.intent === "eat" && king) {
			u.tx = king.hx;
			u.tz = king.hz;
			if (Math.hypot(u.x - king.hx, u.z - king.hz) < 2.2 && king.food > 0) {
				king.food -= 1;
				u.hunger = .12;
				this.sfx("eat", u.x, u.z);
				u.intent = "wander";
			}
			return;
		}
		if (u.intent === "sleep") {
			const home = this.buildings.find((b) => b.id === u.target && b.alive);
			if (!home) {
				u.intent = "wander";
				return;
			}
			u.tx = home.x;
			u.tz = home.z + .4;
			if (Math.hypot(u.x - home.x, u.z - home.z) < 1.5) {
				u.moving = false;
				u.hp = Math.min(u.maxHp, u.hp + dt * 1.5);
			}
			return;
		}
		if (u.intent === "flee") {
			const foe = this.byId(u.target);
			if (!foe || !foe.alive) {
				u.intent = "wander";
				return;
			}
			const dx = u.x - foe.x;
			const dz = u.z - foe.z;
			const d = Math.hypot(dx, dz) || 1;
			u.tx = clamp(u.x + dx / d * 4, 2, this.span - 2);
			u.tz = clamp(u.z + dz / d * 4, 2, this.span - 2);
		}
	}
	steer(u, dt) {
		let speed = u.role === "warrior" ? 2.55 : u.role === "king" ? 1.85 : u.role === "baby" ? 1.25 : u.kind === "person" ? 2.15 : 1.8;
		if (u.race === "wolf") speed = 3.25;
		if (u.race === "tiger") speed = 3.45;
		if (u.race === "deer") speed = 3.35;
		if (u.race === "dragon") speed = 4.6;
		if (u.race === "bear") speed = 2.15;
		if (u.race === "cow") speed = 1.25;
		if (u.race === "chicken") speed = 1.5;
		if (this.heightAt(u.x, u.z) < this.waterLevel + .05) speed *= .55;
		const dx = u.tx - u.x;
		const dz = u.tz - u.z;
		const dist = Math.hypot(dx, dz);
		if (dist > .18) {
			u.x += dx / dist * speed * dt;
			u.z += dz / dist * speed * dt;
			u.yaw = Math.atan2(-dx, -dz);
			u.moving = true;
			u.x = clamp(u.x, 1.5, this.span - 1.5);
			u.z = clamp(u.z, 1.5, this.span - 1.5);
		} else u.moving = false;
	}
	growKingdoms(dt) {
		for (const k of this.kingdoms) {
			if (k.fallen) continue;
			k.boost = Math.max(0, k.boost - dt);
			k.breed -= dt;
			const members = this.units.filter((u) => u.alive && u.kingdom === k.id);
			if (members.length === 0) {
				k.fallen = true;
				this.pushLog({
					t: "wipe",
					a: k.name
				});
				this.sfx("death", k.hx, k.hz);
				continue;
			}
			const kingUnit = members.find((u) => u.role === "king");
			if (kingUnit) {
				k.hx += (kingUnit.x - k.hx) * .02;
				k.hz += (kingUnit.z - k.hz) * .02;
			}
			for (const farm of this.buildings) if (farm.alive && farm.kingdom === k.id && farm.type === "farm") k.food = Math.min(100, k.food + dt * .22 * (k.boost > 0 ? 2 : 1));
			const houses = this.buildings.filter((b) => b.alive && b.type === "house" && b.kingdom === k.id).length;
			const shrines = this.buildings.filter((b) => b.alive && b.type === "shrine" && b.kingdom === k.id).length;
			const markets = this.buildings.filter((b) => b.alive && b.type === "market" && b.kingdom === k.id).length;
			if (shrines > 0) k.breed -= dt * .45;
			if (markets > 0) k.food = Math.min(100, k.food + dt * .16 * markets);
			const adults = members.filter((u) => u.role !== "baby" && u.age > 10);
			if (k.breed <= 0 && adults.length >= 2 && k.food >= 6 && members.length < houses * 4 + 3 && this.units.length < LIMITS.unit) {
				k.breed = 16;
				k.food -= 2;
				const parent = adults[Math.floor(this.rand() * adults.length)] ?? adults[0];
				if (parent) {
					this.spawnPerson(k.race, "baby", parent.x + .4, parent.z + .3, k.id);
					this.births += 1;
					this.sfx("birth", parent.x, parent.z);
					this.pushLog({
						t: "born",
						a: k.name
					});
				}
			}
		}
	}
	tickBuildings(dt) {
		for (const b of this.buildings) {
			if (!b.alive || b.type !== "tower") continue;
			b.cool -= dt;
			if (b.cool > 0) continue;
			const foe = this.nearestUnit(b.x, b.z, 9, (u) => {
				if (!u.alive) return false;
				if (u.race === "wolf" || u.race === "bear" || u.race === "tiger" || u.race === "dragon") return true;
				if (u.kind !== "person" || u.kingdom < 0) return false;
				const home = this.kingdoms.find((k) => k.id === b.kingdom);
				return !!home && home.wars.includes(u.kingdom);
			});
			if (!foe) continue;
			b.cool = 1.25;
			foe.hp -= 7;
			foe.hit = .12;
			this.sfx("tower", b.x, b.z);
			this.fxQ.push({
				kind: "bolt",
				x: b.x,
				y: this.heightAt(b.x, b.z) + 2.2,
				z: b.z,
				x2: foe.x,
				y2: this.heightAt(foe.x, foe.z) + 1,
				z2: foe.z,
				life: .18,
				max: .18
			});
			if (foe.hp <= 0) this.kill(foe, b.kingdom);
		}
	}
	considerWars() {
		for (let i = 0; i < this.kingdoms.length; i++) for (let j = i + 1; j < this.kingdoms.length; j++) {
			const a = this.kingdoms[i];
			const b = this.kingdoms[j];
			if (!a || !b || a.fallen || b.fallen || a.race === b.race) continue;
			if (a.wars.includes(b.id)) continue;
			if (Math.hypot(a.hx - b.hx, a.hz - b.hz) < 18) this.declare(a, b);
		}
	}
	declare(a, b) {
		if (!a.wars.includes(b.id)) a.wars.push(b.id);
		if (!b.wars.includes(a.id)) b.wars.push(a.id);
		this.sfx("war", (a.hx + b.hx) / 2, (a.hz + b.hz) / 2);
		this.pushLog({
			t: "war",
			a: a.name,
			b: b.name
		});
	}
	kill(u, killerKingdom = -1) {
		if (!u.alive) return;
		u.alive = false;
		u.fade = 1;
		u.moving = false;
		this.deaths += 1;
		this.compact = true;
		this.sfx(u.kind === "person" ? "death" : "death_beast", u.x, u.z);
		if (killerKingdom >= 0) {
			const k = this.kingdoms.find((kk) => kk.id === killerKingdom);
			if (k) k.food = Math.min(100, k.food + 1);
		}
	}
	addPerson(race, role, x, z) {
		let king = this.kingdoms.find((k) => !k.fallen && k.race === race && Math.hypot(k.hx - x, k.hz - z) < 18);
		if (role === "king" && king) {
			if (this.units.find((u) => u.alive && u.kingdom === king?.id && u.role === "king")) role = "warrior";
		}
		if (!king) {
			const created = this.foundKingdom(race, x, z);
			if (!created) return false;
			king = created;
		}
		if (!king) return false;
		if (!this.spawnPerson(race, role, x, z, king.id)) return false;
		if (role === "king") {
			king.hx = x;
			king.hz = z;
			if (!this.buildings.some((b) => b.alive && b.kingdom === king?.id && b.type === "castle")) this.addBuilding("castle", x, z - 1.6, king.id, true);
		}
		const sound = role === "king" ? "place_king" : role === "warrior" ? "place_warrior" : role === "baby" ? "place_baby" : race === "elf" ? "place_elf" : race === "orc" ? "place_orc" : race === "dwarf" ? "place_dwarf" : "place_human";
		this.sfx(sound, x, z);
		return true;
	}
	spawnPerson(race, role, x, z, kingdom) {
		if (this.units.length >= LIMITS.unit) {
			this.toast = "full";
			return null;
		}
		const hp = role === "warrior" ? 78 : role === "king" ? 110 : role === "baby" ? 18 : 36;
		const u = {
			id: this.nextId++,
			kind: "person",
			race,
			role,
			name: PEOPLE[Math.floor(this.rand() * PEOPLE.length)] ?? "Warga",
			kingdom,
			x,
			z,
			yaw: this.rand() * Math.PI * 2,
			hp,
			maxHp: hp,
			hunger: .2,
			age: role === "baby" ? 0 : 18,
			alive: true,
			fade: 1,
			intent: "wander",
			target: -1,
			tx: x,
			tz: z,
			timer: this.rand(),
			cool: 0,
			work: 0,
			frozen: 0,
			burn: 0,
			plague: 0,
			hit: 0,
			phase: this.rand() * Math.PI * 2,
			moving: false,
			build: null
		};
		this.units.push(u);
		return u;
	}
	addAnimal(kind, x, z) {
		if (kind === "dragon" && this.units.filter((u) => u.alive && u.race === "dragon").length >= 2) {
			this.toast = "full";
			return false;
		}
		if (this.units.length >= LIMITS.unit) {
			this.toast = "full";
			return false;
		}
		const hp = kind === "dragon" ? 260 : kind === "bear" ? 100 : kind === "tiger" ? 78 : kind === "wolf" ? 44 : kind === "cow" ? 40 : kind === "deer" ? 28 : kind === "sheep" ? 22 : 12;
		this.units.push({
			id: this.nextId++,
			kind: "animal",
			race: kind,
			role: "beast",
			name: kind,
			kingdom: -1,
			x,
			z,
			yaw: this.rand() * Math.PI * 2,
			hp,
			maxHp: hp,
			hunger: 0,
			age: 4,
			alive: true,
			fade: 1,
			intent: "wander",
			target: -1,
			tx: x,
			tz: z,
			timer: this.rand(),
			cool: 1,
			work: 0,
			frozen: 0,
			burn: 0,
			plague: 0,
			hit: 0,
			phase: this.rand() * Math.PI * 2,
			moving: false,
			build: null
		});
		const sound = kind === "chicken" ? "chicken" : kind === "sheep" ? "sheep" : kind === "cow" ? "cow" : kind === "deer" ? "deer" : kind === "wolf" ? "wolf" : kind === "tiger" ? "roar" : kind === "bear" ? "bear" : "dragon";
		this.sfx(sound, x, z);
		return true;
	}
	addBuilding(type, x, z, kingdom, quiet = false) {
		if (this.buildings.length >= LIMITS.building) {
			this.toast = "full";
			return false;
		}
		const hp = type === "castle" ? 240 : type === "shrine" ? 180 : type === "tower" ? 140 : type === "market" ? 90 : type === "wall" ? 90 : type === "house" ? 80 : 50;
		this.buildings.push({
			id: this.nextId++,
			type,
			x,
			z,
			yaw: this.rand() * Math.PI * 2,
			hp,
			maxHp: hp,
			kingdom,
			alive: true,
			cool: .4
		});
		if (type === "castle") {
			const k = this.kingdoms.find((kk) => kk.id === kingdom);
			if (k) {
				k.hx = x;
				k.hz = z;
			}
		}
		const sound = type === "house" ? "place_house" : type === "farm" ? "place_farm" : type === "tower" ? "place_tower" : type === "castle" ? "place_castle" : type === "shrine" ? "bless" : type === "market" ? "place_house" : type === "wall" ? "place_wall" : type === "boat" ? "place_boat" : "place_fire";
		if (!quiet) this.sfx(sound, x, z);
		else this.sfx("build_done", x, z);
		if (!quiet || type === "house" || type === "farm" || type === "tower") {
			const k = this.kingdoms.find((kk) => kk.id === kingdom);
			if (k && !quiet) this.pushLog({
				t: "build",
				a: k.name,
				what: type
			});
		}
		return true;
	}
	addTree(kind, x, z) {
		if (this.trees.filter((t) => t.alive).length >= LIMITS.tree) {
			this.toast = "full";
			return false;
		}
		this.trees.push({
			id: this.nextId++,
			kind,
			x,
			z,
			hp: 3,
			maxHp: 3,
			alive: true,
			burn: 0,
			regrow: 0,
			scale: .85 + this.rand() * .45,
			yaw: this.rand() * Math.PI,
			phase: this.rand() * 6
		});
		this.sfx("place_tree", x, z);
		return true;
	}
	addRock(x, z) {
		if (this.rocks.length >= LIMITS.rock) return false;
		this.rocks.push({
			id: this.nextId++,
			x,
			z,
			hp: 3,
			alive: true,
			scale: .7 + this.rand() * .8,
			phase: this.rand() * 6
		});
		this.sfx("place_rock", x, z);
		return true;
	}
	addProp(kind, x, z) {
		if (this.props.length >= LIMITS.prop) return false;
		this.props.push({
			id: this.nextId++,
			kind,
			x,
			z,
			alive: true,
			scale: .8 + this.rand() * .5,
			yaw: this.rand() * 6,
			phase: this.rand() * 6
		});
		this.sfx(kind === "bush" ? "place_bush" : "place_flower", x, z);
		return true;
	}
	foundKingdom(race, x, z) {
		const used = new Set(this.kingdoms.map((k) => k.name));
		const name = KNAMES[race].find((n) => !used.has(n)) ?? `${KNAMES[race][0]} ${this.kingdoms.length + 1}`;
		const color = RCOLORS[race][this.kingdoms.length % RCOLORS[race].length] ?? "#3e6f9a";
		const king = {
			id: this.nextId++,
			race,
			name,
			color,
			hx: x,
			hz: z,
			food: 14,
			wood: 8,
			stone: 4,
			wars: [],
			boost: 0,
			breed: 8,
			fallen: false
		};
		this.kingdoms.push(king);
		return king;
	}
	generate() {
		const n = this.res;
		const lavaX = this.span * .74;
		const lavaZ = this.span * .7;
		for (let z = 0; z < n; z++) for (let x = 0; x < n; x++) {
			const dx = (x / this.span - .5) * 2;
			const dz = (z / this.span - .5) * 2;
			const d = Math.hypot(dx * 1.05, dz * .92);
			const mask = Math.pow(Math.max(0, 1 - d * .9), 1.2);
			let h = mask * (2.3 + fbm(x * .055, z * .055, this.seed) * 5.4);
			h += fbm(x * .13, z * .13, this.seed + 3) * mask * 1.15;
			if (d > 1) h *= .25;
			const moisture = fbm(x * .07 + 4, z * .07, this.seed + 9);
			let biome = BIOME.grass;
			if (h < this.waterBase + .28) biome = BIOME.sand;
			else if (h > 6.15) biome = BIOME.snow;
			else if (moisture > .62 && h < 2.5) biome = BIOME.swamp;
			else if (moisture > .52) biome = BIOME.forest;
			if (Math.hypot(x - lavaX, z - lavaZ) < 3.1) {
				biome = BIOME.lava;
				h = Math.min(h, this.waterBase + .35);
			}
			this.height[z * n + x] = h;
			this.biome[z * n + x] = biome;
		}
		for (let z = 1; z < n - 1; z++) for (let x = 1; x < n - 1; x++) {
			const i = z * n + x;
			const h = this.height[i] ?? 0;
			const slope = Math.hypot((this.height[i + 1] ?? h) - (this.height[i - 1] ?? h), (this.height[i + n] ?? h) - (this.height[i - n] ?? h));
			const b = this.biome[i] ?? 0;
			if (slope > 1.15 && b !== BIOME.sand && b !== BIOME.snow && b !== BIOME.lava && h > this.waterBase + .4) this.biome[i] = BIOME.rock;
		}
	}
	scatter() {
		const step = 2;
		for (let z = 3; z < this.span - 3; z += step) for (let x = 3; x < this.span - 3; x += step) {
			const jx = x + (hash(x, z, this.seed) - .5) * 1.4;
			const jz = z + (hash(z, x, this.seed + 2) - .5) * 1.4;
			const b = this.biomeAt(jx, jz);
			if (this.heightAt(jx, jz) < this.waterBase + .35) continue;
			const r = hash(x * 3, z * 5, this.seed + 11);
			if ((b === BIOME.forest || b === BIOME.grass || b === BIOME.swamp) && r > .42 && this.trees.length < LIMITS.tree) {
				const kind = b === BIOME.swamp ? "palm" : r > .78 ? "pine" : "oak";
				this.trees.push({
					id: this.nextId++,
					kind,
					x: jx,
					z: jz,
					hp: 3,
					maxHp: 3,
					alive: true,
					burn: 0,
					regrow: 0,
					scale: .8 + hash(x, z, 4) * .55,
					yaw: hash(x, z, 5) * Math.PI,
					phase: hash(x, z, 6) * 6
				});
			} else if (b === BIOME.rock && r > .45 && this.rocks.length < LIMITS.rock) this.rocks.push({
				id: this.nextId++,
				x: jx,
				z: jz,
				hp: 3,
				alive: true,
				scale: .6 + r,
				phase: r * 4
			});
			else if ((b === BIOME.grass || b === BIOME.forest) && r > .86 && this.props.length < LIMITS.prop) this.props.push({
				id: this.nextId++,
				kind: r > .93 ? "flower" : "bush",
				x: jx,
				z: jz,
				alive: true,
				scale: .75 + r * .4,
				yaw: r * 6,
				phase: r * 3
			});
		}
		this.scatterDirty = true;
	}
	seedVillages() {
		const human = this.findLand(this.span * .38, this.span * .46);
		const orc = this.findLand(this.span * .68, this.span * .58);
		if (human) {
			const k = this.foundKingdom("human", human.x, human.z);
			if (k) {
				this.spawnPerson("human", "king", human.x, human.z, k.id);
				for (let i = 0; i < 6; i++) this.spawnPerson("human", "villager", human.x + (this.rand() - .5) * 5, human.z + (this.rand() - .5) * 5, k.id);
				for (let i = 0; i < 2; i++) this.spawnPerson("human", "warrior", human.x + 2 + i, human.z + 1, k.id);
				this.addBuilding("castle", human.x, human.z - 1.8, k.id, true);
				this.addBuilding("house", human.x - 3.2, human.z + 1.4, k.id, true);
				this.addBuilding("house", human.x + 3, human.z + .6, k.id, true);
				this.addBuilding("house", human.x - 1.2, human.z + 3.3, k.id, true);
				this.addBuilding("farm", human.x + 1.5, human.z + 4.2, k.id, true);
				this.addBuilding("firepit", human.x + .8, human.z + 1.5, k.id, true);
				for (let i = 0; i < 3; i++) this.addAnimal("chicken", human.x + 3 + i * .6, human.z + 2);
				this.addAnimal("sheep", human.x - 4, human.z + 2);
			}
		}
		if (orc && (!human || Math.hypot(orc.x - human.x, orc.z - human.z) > 16)) {
			const k = this.foundKingdom("orc", orc.x, orc.z);
			if (k) {
				this.spawnPerson("orc", "king", orc.x, orc.z, k.id);
				for (let i = 0; i < 4; i++) this.spawnPerson("orc", "villager", orc.x + (this.rand() - .5) * 4, orc.z + (this.rand() - .5) * 4, k.id);
				for (let i = 0; i < 2; i++) this.spawnPerson("orc", "warrior", orc.x - 2, orc.z + i, k.id);
				this.addBuilding("castle", orc.x, orc.z - 1.6, k.id, true);
				this.addBuilding("house", orc.x + 2.8, orc.z + 1, k.id, true);
				this.addBuilding("house", orc.x - 2.6, orc.z + 1.4, k.id, true);
				this.addBuilding("firepit", orc.x + .6, orc.z + 1.6, k.id, true);
			}
		}
		const wild = this.findLand(this.span * .52, this.span * .28);
		if (wild) {
			this.addAnimal("deer", wild.x, wild.z);
			this.addAnimal("deer", wild.x + 1.4, wild.z - .6);
			this.addAnimal("deer", wild.x - 1, wild.z + 1);
		}
		const den = this.findLand(this.span * .24, this.span * .72);
		if (den) {
			this.addAnimal("wolf", den.x, den.z);
			this.addAnimal("wolf", den.x + 1.2, den.z + .4);
		}
		const cave = this.findLand(this.span * .8, this.span * .3);
		if (cave) this.addAnimal("bear", cave.x, cave.z);
	}
	findLand(px, pz) {
		let best = null;
		let bestD = 1e9;
		for (let i = 0; i < 180; i++) {
			const x = 4 + this.rand() * (this.span - 8);
			const z = 4 + this.rand() * (this.span - 8);
			const h = this.heightAt(x, z);
			const b = this.biomeAt(x, z);
			if (h < this.waterBase + .55 || h > 5.4) continue;
			if (b === BIOME.sand || b === BIOME.lava || b === BIOME.snow || b === BIOME.rock) continue;
			const d = Math.hypot(x - px, z - pz);
			if (d < bestD) {
				bestD = d;
				best = {
					x,
					z
				};
			}
		}
		return best;
	}
	paint(x, z, radius, biome) {
		const r = Math.ceil(radius);
		const x0 = clamp(Math.floor(x - r), 0, this.span);
		const x1 = clamp(Math.ceil(x + r), 0, this.span);
		const z0 = clamp(Math.floor(z - r), 0, this.span);
		const z1 = clamp(Math.ceil(z + r), 0, this.span);
		for (let zz = z0; zz <= z1; zz++) for (let xx = x0; xx <= x1; xx++) {
			if (Math.hypot(xx - x, zz - z) > radius) continue;
			this.biome[zz * this.res + xx] = biome;
			if (biome === BIOME.lava) this.height[zz * this.res + xx] = Math.min(this.height[zz * this.res + xx] ?? 0, this.waterBase + .4);
		}
		this.terrainDirty = true;
	}
	crater(x, z, radius) {
		const r = Math.ceil(radius);
		for (let zz = Math.max(0, Math.floor(z - r)); zz <= Math.min(this.span, Math.ceil(z + r)); zz++) for (let xx = Math.max(0, Math.floor(x - r)); xx <= Math.min(this.span, Math.ceil(x + r)); xx++) {
			const d = Math.hypot(xx - x, zz - z);
			if (d > radius) continue;
			const i = zz * this.res + xx;
			const inf = 1 - d / radius;
			this.height[i] = Math.max(.2, (this.height[i] ?? 0) - inf * 1.7);
			this.biome[i] = BIOME.scorch;
		}
		this.terrainDirty = true;
		this.ignite(x, z, radius * .7);
	}
	shakeTerrain(x, z, radius) {
		for (let i = 0; i < 80; i++) {
			const xx = clamp(Math.round(x + (this.rand() - .5) * radius * 2), 1, this.span - 1);
			const idx = clamp(Math.round(z + (this.rand() - .5) * radius * 2), 1, this.span - 1) * this.res + xx;
			this.height[idx] = Math.max(.15, (this.height[idx] ?? 0) + (this.rand() - .5) * .55);
		}
		this.terrainDirty = true;
	}
	scorch(x, z, radius) {
		this.paint(x, z, radius, BIOME.scorch);
	}
	ignite(x, z, radius) {
		for (const t of this.trees) if (t.alive && Math.hypot(t.x - x, t.z - z) < radius) t.burn = Math.max(t.burn, 4);
		for (const u of this.units) if (u.alive && Math.hypot(u.x - x, u.z - z) < radius) u.burn = Math.max(u.burn, 3.5);
		for (const b of this.buildings) if (b.alive && Math.hypot(b.x - x, b.z - z) < radius) {
			b.hp -= 28;
			if (b.hp <= 0) {
				b.alive = false;
				this.compact = true;
			}
		}
		this.fxQ.push({
			kind: "boom",
			x,
			y: this.heightAt(x, z),
			z,
			life: .45,
			max: .45
		});
	}
	hurtArea(x, z, radius, dmg, ignite) {
		for (const u of this.units) {
			if (!u.alive || Math.hypot(u.x - x, u.z - z) > radius) continue;
			u.hp -= dmg;
			u.hit = .2;
			if (ignite) u.burn = Math.max(u.burn, 2.5);
			if (u.hp <= 0) this.kill(u);
		}
		if (ignite) this.ignite(x, z, radius * .85);
	}
	erase(x, z, radius) {
		for (const u of this.units) if (u.alive && Math.hypot(u.x - x, u.z - z) < radius) this.kill(u);
		for (const b of this.buildings) if (b.alive && Math.hypot(b.x - x, b.z - z) < radius + .6) {
			b.alive = false;
			this.compact = true;
		}
		for (const t of this.trees) if (t.alive && Math.hypot(t.x - x, t.z - z) < radius) {
			t.alive = false;
			t.regrow = 50;
		}
		for (const r of this.rocks) if (r.alive && Math.hypot(r.x - x, r.z - z) < radius) r.alive = false;
		for (const p of this.props) if (p.alive && Math.hypot(p.x - x, p.z - z) < radius) p.alive = false;
	}
	ring(x, z, count) {
		const spots = [{
			x,
			z
		}];
		for (let i = 0; i < count - 1; i++) {
			const a = i / (count - 1) * Math.PI * 2;
			spots.push({
				x: x + Math.cos(a) * 2.3,
				z: z + Math.sin(a) * 2.3
			});
		}
		return spots;
	}
	wander(u, king) {
		u.intent = "wander";
		const ox = king ? king.hx : u.x;
		const oz = king ? king.hz : u.z;
		const spread = king ? 7 : 6;
		u.tx = clamp(ox + (this.rand() - .5) * spread * 2, 2, this.span - 2);
		u.tz = clamp(oz + (this.rand() - .5) * spread * 2, 2, this.span - 2);
		u.target = -1;
	}
	siteNear(x, z, gap) {
		for (let i = 0; i < 10; i++) {
			const s = {
				x: x + (this.rand() - .5) * 10,
				z: z + (this.rand() - .5) * 10
			};
			if (this.siteFree(s.x, s.z, gap) && this.heightAt(s.x, s.z) > this.waterLevel + .4) return s;
		}
		return null;
	}
	siteFree(x, z, gap) {
		if (!this.inMap(x, z)) return false;
		for (const b of this.buildings) if (b.alive && Math.hypot(b.x - x, b.z - z) < gap) return false;
		for (const t of this.trees) if (t.alive && Math.hypot(t.x - x, t.z - z) < gap * .65) return false;
		return true;
	}
	nearestKingdom(x, z) {
		let best = null;
		let d0 = 1e9;
		for (const k of this.kingdoms) {
			if (k.fallen) continue;
			const d = Math.hypot(k.hx - x, k.hz - z);
			if (d < d0) {
				d0 = d;
				best = k;
			}
		}
		return best;
	}
	nearestPair(x, z) {
		const list = this.kingdoms.filter((k) => !k.fallen).sort((a, b) => Math.hypot(a.hx - x, a.hz - z) - Math.hypot(b.hx - x, b.hz - z));
		if (list.length < 2) return null;
		const a = list[0];
		const b = list[1];
		if (!a || !b) return null;
		return [a, b];
	}
	nearestHostile(u, reach) {
		return this.nearestUnit(u.x, u.z, reach, (o) => {
			if (!o.alive || o.id === u.id) return false;
			if (o.race === "wolf" || o.race === "bear" || o.race === "dragon") return u.kind === "person";
			if (u.kind !== "person" || o.kind !== "person") return false;
			const home = this.kingdoms.find((k) => k.id === u.kingdom);
			return !!home && home.wars.includes(o.kingdom);
		});
	}
	nearestUnit(x, z, reach, test) {
		let best = null;
		let d0 = reach;
		for (const u of this.units) {
			if (!test(u)) continue;
			const d = Math.hypot(u.x - x, u.z - z);
			if (d < d0) {
				d0 = d;
				best = u;
			}
		}
		return best;
	}
	nearestTree(x, z, reach) {
		let best = null;
		let d0 = reach;
		for (const t of this.trees) {
			if (!t.alive) continue;
			const d = Math.hypot(t.x - x, t.z - z);
			if (d < d0) {
				d0 = d;
				best = t;
			}
		}
		return best;
	}
	nearestRock(x, z, reach) {
		let best = null;
		let d0 = reach;
		for (const t of this.rocks) {
			if (!t.alive) continue;
			const d = Math.hypot(t.x - x, t.z - z);
			if (d < d0) {
				d0 = d;
				best = t;
			}
		}
		return best;
	}
	nearestBuilding(u, type) {
		let best = null;
		let d0 = 1e9;
		for (const b of this.buildings) {
			if (!b.alive || b.type !== type || b.kingdom !== u.kingdom) continue;
			const d = Math.hypot(b.x - u.x, b.z - u.z);
			if (d < d0) {
				d0 = d;
				best = b;
			}
		}
		return best;
	}
	byId(id) {
		return this.units.find((u) => u.id === id) ?? null;
	}
	inMap(x, z) {
		return x > 1 && z > 1 && x < this.span - 1 && z < this.span - 1;
	}
	isNight() {
		return this.time < 5.5 || this.time > 19.4;
	}
	sfx(id, x, z) {
		this.sfxQ.push({
			id,
			x,
			z
		});
	}
	pushLog(item) {
		this.log.unshift(item);
		if (this.log.length > 8) this.log.pop();
	}
	inspectUnit(u) {
		const king = this.kingdoms.find((k) => k.id === u.kingdom);
		return {
			id: u.id,
			kind: "unit",
			title: u.kind === "person" ? u.name : u.race,
			subtitle: u.kind === "person" ? `${u.role}:${u.race}` : u.race,
			hp: Math.max(0, u.hp),
			maxHp: u.maxHp,
			hunger: u.kind === "person" ? u.hunger : null,
			state: u.alive ? u.intent : "dead",
			kingdom: king?.name ?? null,
			color: king?.color ?? null
		};
	}
	inspectSelected() {
		if (!this.selected) return null;
		if (this.selected.kind === "unit") {
			const u = this.byId(this.selected.id);
			if (!u || !u.alive) {
				this.selected = null;
				return null;
			}
			return this.inspectUnit(u);
		}
		const b = this.buildings.find((x) => x.id === this.selected?.id && x.alive);
		if (!b) {
			this.selected = null;
			return null;
		}
		const king = this.kingdoms.find((k) => k.id === b.kingdom);
		return {
			id: b.id,
			kind: "building",
			title: b.type,
			subtitle: b.type,
			hp: b.hp,
			maxHp: b.maxHp,
			hunger: null,
			state: "wander",
			kingdom: king?.name ?? null,
			color: king?.color ?? null
		};
	}
};
var cache = /* @__PURE__ */ new Map();
function geo(key, make) {
	let g = cache.get(key);
	if (!g) {
		g = make();
		cache.set(key, g);
	}
	return g;
}
function capsule(r, len) {
	return geo(`cap-${r}-${len}`, () => new CapsuleGeometry(r, len, 4, 8));
}
function sphere(r) {
	return geo(`sph-${r}`, () => new SphereGeometry(r, 10, 8));
}
function box(w, h, d) {
	return geo(`box-${w}-${h}-${d}`, () => new BoxGeometry(w, h, d));
}
function cyl(rt, rb, h, s = 8) {
	return geo(`cyl-${rt}-${rb}-${h}-${s}`, () => new CylinderGeometry(rt, rb, h, s));
}
function cone(r, h, s = 8) {
	return geo(`cone-${r}-${h}-${s}`, () => new ConeGeometry(r, h, s));
}
function bake(parts, sx = 1, sy = 1, sz = 1) {
	const positions = [];
	const normals = [];
	const colors = [];
	const v = new Vector3();
	const nrm = new Vector3();
	const color = new Color();
	for (const part of parts) {
		const source = part.geo.index ? part.geo.toNonIndexed() : part.geo;
		const pos = source.attributes.position;
		const nor = source.attributes.normal;
		if (!pos || !nor) continue;
		const m = new Matrix4().compose(new Vector3(part.x, part.y, part.z), new Quaternion().setFromEuler(new Euler(part.rx ?? 0, part.ry ?? 0, part.rz ?? 0)), new Vector3(part.sx ?? 1, part.sy ?? 1, part.sz ?? 1));
		const nm = new Matrix3().getNormalMatrix(m);
		color.set(part.color);
		for (let i = 0; i < pos.count; i++) {
			v.fromBufferAttribute(pos, i).applyMatrix4(m);
			nrm.fromBufferAttribute(nor, i).applyMatrix3(nm).normalize();
			positions.push(v.x * sx, v.y * sy, v.z * sz);
			normals.push(nrm.x, nrm.y, nrm.z);
			colors.push(color.r, color.g, color.b);
		}
	}
	const out = new BufferGeometry();
	out.setAttribute("position", new Float32BufferAttribute(positions, 3));
	out.setAttribute("normal", new Float32BufferAttribute(normals, 3));
	out.setAttribute("color", new Float32BufferAttribute(colors, 3));
	out.computeBoundingSphere();
	return out;
}
function person(o) {
	const skin = o.skin;
	const b = o.bulk;
	const headR = o.baby ? .2 : .155;
	const legR = .075 * b;
	const legLen = o.baby ? .22 : .4;
	const legY = legLen * .5 + legR;
	const hip = legY + legLen * .5 + legR * .2;
	const torsoR = (o.baby ? .16 : .175) * b;
	const torsoLen = o.baby ? .22 : .38;
	const torsoY = hip + torsoLen * .35;
	const shoulder = torsoY + torsoLen * .32;
	const headY = shoulder + headR * .85;
	const armX = torsoR + .08 * b;
	const parts = [
		{
			geo: capsule(legR, legLen),
			x: -.1 * b,
			y: legY,
			z: 0,
			color: o.pants,
			limb: 1
		},
		{
			geo: capsule(legR, legLen),
			x: .1 * b,
			y: legY,
			z: 0,
			color: o.pants,
			limb: 2
		},
		{
			geo: sphere(.09 * b),
			x: -.1 * b,
			y: .06,
			z: .03,
			color: o.boot,
			limb: 1,
			sx: 1.1,
			sz: 1.4
		},
		{
			geo: sphere(.09 * b),
			x: .1 * b,
			y: .06,
			z: .03,
			color: o.boot,
			limb: 2,
			sx: 1.1,
			sz: 1.4
		},
		{
			geo: capsule(torsoR, torsoLen),
			x: 0,
			y: torsoY,
			z: 0,
			color: o.cloth,
			limb: 0,
			sz: .82
		},
		{
			geo: box(torsoR * 1.7, .08, torsoR * .5),
			x: 0,
			y: shoulder - .02,
			z: 0,
			color: o.trim,
			limb: 0
		},
		{
			geo: capsule(.055 * b, .32),
			x: -armX,
			y: shoulder - .12,
			z: 0,
			color: o.cloth,
			limb: 3
		},
		{
			geo: capsule(.055 * b, .32),
			x: armX,
			y: shoulder - .12,
			z: 0,
			color: o.cloth,
			limb: 4
		},
		{
			geo: sphere(.055 * b),
			x: -armX,
			y: shoulder - .34,
			z: .02,
			color: skin,
			limb: 3
		},
		{
			geo: sphere(.055 * b),
			x: armX,
			y: shoulder - .34,
			z: .02,
			color: skin,
			limb: 4
		},
		{
			geo: sphere(headR),
			x: 0,
			y: headY,
			z: 0,
			color: skin,
			limb: 0
		},
		{
			geo: sphere(headR * 1.02),
			x: 0,
			y: headY + headR * .28,
			z: -.02,
			color: o.hair,
			limb: 0,
			sy: .62
		},
		{
			geo: sphere(.028),
			x: -.055,
			y: headY + .02,
			z: headR * .82,
			color: 1841430,
			limb: 0
		},
		{
			geo: sphere(.028),
			x: .055,
			y: headY + .02,
			z: headR * .82,
			color: 1841430,
			limb: 0
		},
		{
			geo: sphere(.03),
			x: 0,
			y: headY - .02,
			z: headR * .92,
			color: skin,
			limb: 0,
			sx: .8,
			sy: .7
		},
		{
			geo: box(.07, .012, .02),
			x: 0,
			y: headY - .07,
			z: headR * .86,
			color: 9065288,
			limb: 0
		}
	];
	if (o.ears) parts.push({
		geo: cone(.04, .12, 5),
		x: -headR * .95,
		y: headY,
		z: 0,
		rz: Math.PI / 2.2,
		color: skin,
		limb: 0
	}, {
		geo: cone(.04, .12, 5),
		x: headR * .95,
		y: headY,
		z: 0,
		rz: -Math.PI / 2.2,
		color: skin,
		limb: 0
	});
	if (o.tusks) parts.push({
		geo: cone(.02, .09, 5),
		x: -.05,
		y: headY - .08,
		z: headR * .75,
		rx: Math.PI / 2.4,
		color: 15985367,
		limb: 0
	}, {
		geo: cone(.02, .09, 5),
		x: .05,
		y: headY - .08,
		z: headR * .75,
		rx: Math.PI / 2.4,
		color: 15985367,
		limb: 0
	});
	if (o.beard) parts.push({
		geo: cone(.11, .28, 7),
		x: 0,
		y: headY - .22,
		z: .04,
		color: o.hair,
		limb: 0
	});
	if (o.hat === "cap") parts.push({
		geo: cyl(headR * 1.05, headR * 1.05, .06, 10),
		x: 0,
		y: headY + headR * .72,
		z: 0,
		color: o.trim,
		limb: 0
	});
	else if (o.hat === "hood") parts.push({
		geo: sphere(headR * 1.12),
		x: 0,
		y: headY + .04,
		z: -.02,
		color: o.trim,
		limb: 0,
		sy: .85
	});
	else if (o.hat === "helmet") parts.push({
		geo: sphere(headR * 1.08),
		x: 0,
		y: headY + .04,
		z: 0,
		color: 9278360,
		limb: 0,
		sy: .72
	}, {
		geo: box(.16, .06, .04),
		x: 0,
		y: headY + .02,
		z: headR,
		color: 7238776,
		limb: 0
	});
	else if (o.hat === "crown") parts.push({
		geo: cyl(headR * .85, headR * .9, .08, 8),
		x: 0,
		y: headY + headR * .85,
		z: 0,
		color: 13934938,
		limb: 0
	}, {
		geo: cone(.04, .14, 5),
		x: -.08,
		y: headY + headR * 1.05,
		z: 0,
		color: 13934938,
		limb: 0
	}, {
		geo: cone(.04, .18, 5),
		x: 0,
		y: headY + headR * 1.1,
		z: 0,
		color: 13934938,
		limb: 0
	}, {
		geo: cone(.04, .14, 5),
		x: .08,
		y: headY + headR * 1.05,
		z: 0,
		color: 13934938,
		limb: 0
	});
	if (o.cape) parts.push({
		geo: box(.34, .55, .04),
		x: 0,
		y: torsoY,
		z: -torsoR * .7,
		color: o.trim,
		limb: 0
	});
	if (o.shield) parts.push({
		geo: box(.06, .36, .28),
		x: -armX - .06,
		y: shoulder - .28,
		z: .04,
		color: o.trim,
		limb: 3
	});
	if (o.sword) parts.push({
		geo: box(.03, .46, .05),
		x: armX + .02,
		y: shoulder - .55,
		z: .08,
		color: 14278114,
		limb: 4
	}, {
		geo: box(.1, .04, .06),
		x: armX + .02,
		y: shoulder - .32,
		z: .08,
		color: 7029286,
		limb: 4
	});
	const tall = o.baby ? 1.15 : 1.28 * o.tall;
	return bake(parts, tall, tall, tall);
}
function oak() {
	return bake([
		{
			geo: cyl(.11, .16, 1.15, 7),
			x: 0,
			y: .58,
			z: 0,
			color: 7030320,
			limb: 0
		},
		{
			geo: sphere(.62),
			x: 0,
			y: 1.55,
			z: 0,
			color: 4160058,
			limb: 0
		},
		{
			geo: sphere(.48),
			x: .32,
			y: 1.35,
			z: .12,
			color: 5147717,
			limb: 0
		},
		{
			geo: sphere(.42),
			x: -.28,
			y: 1.42,
			z: -.1,
			color: 3106868,
			limb: 0
		},
		{
			geo: sphere(.28),
			x: .05,
			y: 2,
			z: -.05,
			color: 6792026,
			limb: 0
		}
	]);
}
function pine() {
	return bake([
		{
			geo: cyl(.08, .12, .7, 6),
			x: 0,
			y: .35,
			z: 0,
			color: 6045744,
			limb: 0
		},
		{
			geo: cone(.7, 1.05, 8),
			x: 0,
			y: 1.05,
			z: 0,
			color: 2054714,
			limb: 0
		},
		{
			geo: cone(.52, .9, 8),
			x: 0,
			y: 1.6,
			z: 0,
			color: 2781264,
			limb: 0
		},
		{
			geo: cone(.32, .7, 7),
			x: 0,
			y: 2.1,
			z: 0,
			color: 3441244,
			limb: 0
		}
	]);
}
function palm() {
	const parts = [
		{
			geo: cyl(.07, .1, .45, 6),
			x: 0,
			y: .22,
			z: 0,
			color: 9069124,
			limb: 0
		},
		{
			geo: cyl(.06, .08, .45, 6),
			x: .05,
			y: .62,
			z: 0,
			rz: -.18,
			color: 10121292,
			limb: 0
		},
		{
			geo: cyl(.055, .07, .4, 6),
			x: .12,
			y: .98,
			z: 0,
			rz: -.28,
			color: 10910546,
			limb: 0
		}
	];
	for (let i = 0; i < 6; i++) {
		const a = i / 6 * Math.PI * 2;
		parts.push({
			geo: cone(.08, .85, 4),
			x: .16 + Math.cos(a) * .15,
			y: 1.22,
			z: Math.sin(a) * .15,
			rx: 1.15,
			ry: a,
			color: i % 2 ? 3115592 : 4104794,
			limb: 0
		});
	}
	parts.push({
		geo: sphere(.1),
		x: .16,
		y: 1.22,
		z: 0,
		color: 2386744,
		limb: 0
	});
	return bake(parts);
}
function chicken() {
	return bake([
		{
			geo: sphere(.16),
			x: 0,
			y: .28,
			z: 0,
			color: 16052714,
			limb: 0,
			sx: 1.25,
			sy: .9,
			sz: 1.05
		},
		{
			geo: sphere(.1),
			x: 0,
			y: .42,
			z: .14,
			color: 16775924,
			limb: 0
		},
		{
			geo: cone(.035, .1, 5),
			x: 0,
			y: .4,
			z: .24,
			rx: Math.PI / 2,
			color: 14852666,
			limb: 0
		},
		{
			geo: sphere(.045),
			x: 0,
			y: .5,
			z: .1,
			color: 12863802,
			limb: 0
		},
		{
			geo: sphere(.018),
			x: -.035,
			y: .45,
			z: .2,
			color: 1841430,
			limb: 0
		},
		{
			geo: sphere(.018),
			x: .035,
			y: .45,
			z: .2,
			color: 1841430,
			limb: 0
		},
		{
			geo: sphere(.08),
			x: -.12,
			y: .3,
			z: 0,
			color: 15196888,
			limb: 3,
			sy: .45
		},
		{
			geo: sphere(.08),
			x: .12,
			y: .3,
			z: 0,
			color: 15196888,
			limb: 4,
			sy: .45
		},
		{
			geo: cyl(.015, .02, .16, 4),
			x: -.05,
			y: .08,
			z: .02,
			color: 14852666,
			limb: 1
		},
		{
			geo: cyl(.015, .02, .16, 4),
			x: .05,
			y: .08,
			z: .02,
			color: 14852666,
			limb: 2
		}
	], 1.7, 1.7, 1.7);
}
function sheep() {
	return bake([
		{
			geo: sphere(.28),
			x: 0,
			y: .42,
			z: 0,
			color: 16250094,
			limb: 0,
			sx: 1.3,
			sy: .9,
			sz: 1.05
		},
		{
			geo: sphere(.16),
			x: 0,
			y: .48,
			z: .28,
			color: 16250094,
			limb: 0
		},
		{
			geo: sphere(.1),
			x: 0,
			y: .5,
			z: .38,
			color: 2761759,
			limb: 0,
			sz: 1.15
		},
		{
			geo: sphere(.02),
			x: -.04,
			y: .54,
			z: .46,
			color: 273,
			limb: 0
		},
		{
			geo: sphere(.02),
			x: .04,
			y: .54,
			z: .46,
			color: 273,
			limb: 0
		},
		{
			geo: cyl(.04, .045, .28, 5),
			x: -.14,
			y: .16,
			z: .12,
			color: 2761759,
			limb: 1
		},
		{
			geo: cyl(.04, .045, .28, 5),
			x: .14,
			y: .16,
			z: .12,
			color: 2761759,
			limb: 2
		},
		{
			geo: cyl(.04, .045, .28, 5),
			x: -.14,
			y: .16,
			z: -.12,
			color: 2761759,
			limb: 1
		},
		{
			geo: cyl(.04, .045, .28, 5),
			x: .14,
			y: .16,
			z: -.12,
			color: 2761759,
			limb: 2
		}
	], 1.45, 1.45, 1.45);
}
function cow() {
	return bake([
		{
			geo: box(.72, .38, .36),
			x: 0,
			y: .52,
			z: 0,
			color: 15986662,
			limb: 0
		},
		{
			geo: box(.22, .16, .22),
			x: -.16,
			y: .62,
			z: .02,
			color: 3814447,
			limb: 0
		},
		{
			geo: box(.16, .14, .18),
			x: .18,
			y: .58,
			z: .04,
			color: 3814447,
			limb: 0
		},
		{
			geo: box(.22, .2, .2),
			x: 0,
			y: .62,
			z: .38,
			color: 16249834,
			limb: 0
		},
		{
			geo: sphere(.06),
			x: -.08,
			y: .78,
			z: .36,
			color: 15259568,
			limb: 0,
			sx: .4,
			sy: 1
		},
		{
			geo: sphere(.06),
			x: .08,
			y: .78,
			z: .36,
			color: 15259568,
			limb: 0,
			sx: .4,
			sy: 1
		},
		{
			geo: sphere(.018),
			x: -.06,
			y: .66,
			z: .48,
			color: 273,
			limb: 0
		},
		{
			geo: sphere(.018),
			x: .06,
			y: .66,
			z: .48,
			color: 273,
			limb: 0
		},
		{
			geo: cyl(.05, .055, .36, 5),
			x: -.22,
			y: .2,
			z: .12,
			color: 3814447,
			limb: 1
		},
		{
			geo: cyl(.05, .055, .36, 5),
			x: .22,
			y: .2,
			z: .12,
			color: 3814447,
			limb: 2
		},
		{
			geo: cyl(.05, .055, .36, 5),
			x: -.22,
			y: .2,
			z: -.12,
			color: 3814447,
			limb: 1
		},
		{
			geo: cyl(.05, .055, .36, 5),
			x: .22,
			y: .2,
			z: -.12,
			color: 3814447,
			limb: 2
		},
		{
			geo: cyl(.03, .02, .22, 4),
			x: 0,
			y: .48,
			z: -.28,
			rx: Math.PI / 2.4,
			color: 3814447,
			limb: 0
		}
	], 1.35, 1.35, 1.35);
}
function deer() {
	return bake([
		{
			geo: capsule(.14, .55),
			x: 0,
			y: .78,
			z: 0,
			rz: Math.PI / 2,
			color: 9067058,
			limb: 0
		},
		{
			geo: capsule(.08, .22),
			x: 0,
			y: 1.02,
			z: .38,
			rx: -.9,
			color: 9067058,
			limb: 0
		},
		{
			geo: sphere(.11),
			x: 0,
			y: 1.22,
			z: .58,
			color: 10119232,
			limb: 0
		},
		{
			geo: sphere(.02),
			x: -.04,
			y: 1.26,
			z: .66,
			color: 1841430,
			limb: 0
		},
		{
			geo: sphere(.02),
			x: .04,
			y: 1.26,
			z: .66,
			color: 1841430,
			limb: 0
		},
		{
			geo: cyl(.012, .012, .28, 4),
			x: -.04,
			y: 1.38,
			z: .52,
			rz: .5,
			color: 15128504,
			limb: 0
		},
		{
			geo: cyl(.012, .012, .22, 4),
			x: -.08,
			y: 1.48,
			z: .46,
			rz: 1.1,
			color: 15128504,
			limb: 0
		},
		{
			geo: cyl(.012, .012, .28, 4),
			x: .04,
			y: 1.38,
			z: .52,
			rz: -.5,
			color: 15128504,
			limb: 0
		},
		{
			geo: cyl(.012, .012, .22, 4),
			x: .08,
			y: 1.48,
			z: .46,
			rz: -1.1,
			color: 15128504,
			limb: 0
		},
		{
			geo: cyl(.035, .04, .48, 5),
			x: -.12,
			y: .32,
			z: .16,
			color: 7029286,
			limb: 1
		},
		{
			geo: cyl(.035, .04, .48, 5),
			x: .12,
			y: .32,
			z: .16,
			color: 7029286,
			limb: 2
		},
		{
			geo: cyl(.035, .04, .48, 5),
			x: -.12,
			y: .32,
			z: -.18,
			color: 7029286,
			limb: 1
		},
		{
			geo: cyl(.035, .04, .48, 5),
			x: .12,
			y: .32,
			z: -.18,
			color: 7029286,
			limb: 2
		}
	], 1.25, 1.25, 1.25);
}
function wolf() {
	return bake([
		{
			geo: capsule(.14, .55),
			x: 0,
			y: .48,
			z: 0,
			rz: Math.PI / 2,
			color: 7172728,
			limb: 0
		},
		{
			geo: cone(.1, .28, 6),
			x: 0,
			y: .52,
			z: .42,
			rx: Math.PI / 2,
			color: 6054246,
			limb: 0
		},
		{
			geo: sphere(.045),
			x: -.06,
			y: .66,
			z: .22,
			color: 5133144,
			limb: 0
		},
		{
			geo: sphere(.045),
			x: .06,
			y: .66,
			z: .22,
			color: 5133144,
			limb: 0
		},
		{
			geo: sphere(.02),
			x: -.035,
			y: .56,
			z: .52,
			color: 15909198,
			limb: 0
		},
		{
			geo: sphere(.02),
			x: .035,
			y: .56,
			z: .52,
			color: 15909198,
			limb: 0
		},
		{
			geo: cone(.035, .22, 5),
			x: 0,
			y: .58,
			z: -.4,
			rx: -1.2,
			color: 5922660,
			limb: 0
		},
		{
			geo: cyl(.035, .04, .34, 5),
			x: -.12,
			y: .2,
			z: .16,
			color: 4080456,
			limb: 1
		},
		{
			geo: cyl(.035, .04, .34, 5),
			x: .12,
			y: .2,
			z: .16,
			color: 4080456,
			limb: 2
		},
		{
			geo: cyl(.035, .04, .34, 5),
			x: -.12,
			y: .2,
			z: -.16,
			color: 4080456,
			limb: 1
		},
		{
			geo: cyl(.035, .04, .34, 5),
			x: .12,
			y: .2,
			z: -.16,
			color: 4080456,
			limb: 2
		}
	], 1.45, 1.45, 1.45);
}
function bear() {
	return bake([
		{
			geo: sphere(.34),
			x: 0,
			y: .55,
			z: 0,
			color: 6047288,
			limb: 0,
			sx: 1.25,
			sy: .85,
			sz: .95
		},
		{
			geo: sphere(.2),
			x: 0,
			y: .62,
			z: .32,
			color: 6968132,
			limb: 0
		},
		{
			geo: sphere(.08),
			x: 0,
			y: .52,
			z: .48,
			color: 12887178,
			limb: 0,
			sz: 1.2
		},
		{
			geo: sphere(.07),
			x: -.12,
			y: .78,
			z: .22,
			color: 4864044,
			limb: 0
		},
		{
			geo: sphere(.07),
			x: .12,
			y: .78,
			z: .22,
			color: 4864044,
			limb: 0
		},
		{
			geo: sphere(.025),
			x: -.06,
			y: .66,
			z: .46,
			color: 1841430,
			limb: 0
		},
		{
			geo: sphere(.025),
			x: .06,
			y: .66,
			z: .46,
			color: 1841430,
			limb: 0
		},
		{
			geo: cyl(.07, .08, .32, 6),
			x: -.22,
			y: .22,
			z: .14,
			color: 4864044,
			limb: 1
		},
		{
			geo: cyl(.07, .08, .32, 6),
			x: .22,
			y: .22,
			z: .14,
			color: 4864044,
			limb: 2
		},
		{
			geo: cyl(.08, .09, .28, 6),
			x: -.2,
			y: .2,
			z: -.16,
			color: 4075044,
			limb: 1
		},
		{
			geo: cyl(.08, .09, .28, 6),
			x: .2,
			y: .2,
			z: -.16,
			color: 4075044,
			limb: 2
		}
	], 1.4, 1.4, 1.4);
}
function dragon() {
	return bake([
		{
			geo: capsule(.28, 1.1),
			x: 0,
			y: .85,
			z: 0,
			rz: Math.PI / 2,
			color: 3108194,
			limb: 0
		},
		{
			geo: capsule(.16, .4),
			x: 0,
			y: 1.15,
			z: .7,
			rx: -.7,
			color: 3440756,
			limb: 0
		},
		{
			geo: sphere(.22),
			x: 0,
			y: 1.4,
			z: 1.05,
			color: 3968898,
			limb: 0,
			sz: 1.25
		},
		{
			geo: cone(.1, .32, 6),
			x: 0,
			y: 1.32,
			z: 1.32,
			rx: Math.PI / 2,
			color: 2776662,
			limb: 0
		},
		{
			geo: cone(.04, .22, 5),
			x: -.08,
			y: 1.62,
			z: .98,
			rz: .4,
			color: 13934938,
			limb: 0
		},
		{
			geo: cone(.04, .22, 5),
			x: .08,
			y: 1.62,
			z: .98,
			rz: -.4,
			color: 13934938,
			limb: 0
		},
		{
			geo: sphere(.035),
			x: -.08,
			y: 1.46,
			z: 1.2,
			color: 15909198,
			limb: 0
		},
		{
			geo: sphere(.035),
			x: .08,
			y: 1.46,
			z: 1.2,
			color: 15909198,
			limb: 0
		},
		{
			geo: sphere(.22),
			x: 0,
			y: .78,
			z: .05,
			color: 12868664,
			limb: 0,
			sx: .7,
			sy: .55,
			sz: 1.1
		},
		{
			geo: capsule(.12, .55),
			x: 0,
			y: .7,
			z: -.85,
			rz: Math.PI / 2,
			color: 2581080,
			limb: 0,
			sx: .7
		},
		{
			geo: cone(.08, .4, 5),
			x: 0,
			y: .62,
			z: -1.3,
			rx: -Math.PI / 2,
			color: 2052424,
			limb: 0
		},
		{
			geo: box(.9, .05, .55),
			x: -.7,
			y: 1.15,
			z: -.05,
			color: 1854020,
			limb: 3,
			rz: .35
		},
		{
			geo: box(.9, .05, .55),
			x: .7,
			y: 1.15,
			z: -.05,
			color: 1854020,
			limb: 4,
			rz: -.35
		},
		{
			geo: box(.55, .04, .28),
			x: -.55,
			y: 1.18,
			z: .05,
			color: 12868664,
			limb: 3
		},
		{
			geo: box(.55, .04, .28),
			x: .55,
			y: 1.18,
			z: .05,
			color: 12868664,
			limb: 4
		},
		{
			geo: cyl(.06, .07, .4, 5),
			x: -.22,
			y: .35,
			z: .28,
			color: 2381647,
			limb: 1
		},
		{
			geo: cyl(.06, .07, .4, 5),
			x: .22,
			y: .35,
			z: .28,
			color: 2381647,
			limb: 2
		},
		{
			geo: cyl(.07, .08, .36, 5),
			x: -.24,
			y: .32,
			z: -.28,
			color: 1918786,
			limb: 1
		},
		{
			geo: cyl(.07, .08, .36, 5),
			x: .24,
			y: .32,
			z: -.28,
			color: 1918786,
			limb: 2
		}
	]);
}
function tiger() {
	return bake([
		{
			geo: capsule(.16, .7),
			x: 0,
			y: .52,
			z: 0,
			rz: Math.PI / 2,
			color: 14715438,
			limb: 0
		},
		{
			geo: box(.08, .04, .22),
			x: 0,
			y: .66,
			z: .05,
			color: 1841430,
			limb: 0
		},
		{
			geo: box(.08, .04, .18),
			x: 0,
			y: .62,
			z: -.18,
			color: 1841430,
			limb: 0
		},
		{
			geo: cone(.12, .32, 6),
			x: 0,
			y: .55,
			z: .5,
			rx: Math.PI / 2,
			color: 13924386,
			limb: 0
		},
		{
			geo: sphere(.05),
			x: -.07,
			y: .72,
			z: .28,
			color: 15921128,
			limb: 0
		},
		{
			geo: sphere(.05),
			x: .07,
			y: .72,
			z: .28,
			color: 15921128,
			limb: 0
		},
		{
			geo: sphere(.018),
			x: -.04,
			y: .58,
			z: .62,
			color: 15909198,
			limb: 0
		},
		{
			geo: sphere(.018),
			x: .04,
			y: .58,
			z: .62,
			color: 15909198,
			limb: 0
		},
		{
			geo: cone(.04, .42, 5),
			x: 0,
			y: .62,
			z: -.52,
			rx: -1.15,
			color: 12872232,
			limb: 0
		},
		{
			geo: cyl(.045, .05, .38, 5),
			x: -.14,
			y: .22,
			z: .18,
			color: 12872232,
			limb: 1
		},
		{
			geo: cyl(.045, .05, .38, 5),
			x: .14,
			y: .22,
			z: .18,
			color: 12872232,
			limb: 2
		},
		{
			geo: cyl(.05, .055, .36, 5),
			x: -.14,
			y: .22,
			z: -.2,
			color: 11558434,
			limb: 1
		},
		{
			geo: cyl(.05, .055, .36, 5),
			x: .14,
			y: .22,
			z: -.2,
			color: 11558434,
			limb: 2
		}
	], 1.55, 1.55, 1.55);
}
function shrine() {
	const stone = 13351062;
	const dark = 9268034;
	return bake([
		{
			geo: box(2.6, .32, 2.6),
			x: 0,
			y: .16,
			z: 0,
			color: 12035210,
			limb: 0
		},
		{
			geo: box(1.9, .36, 1.9),
			x: 0,
			y: .48,
			z: 0,
			color: stone,
			limb: 0
		},
		{
			geo: box(1.25, .4, 1.25),
			x: 0,
			y: .84,
			z: 0,
			color: 14666664,
			limb: 0
		},
		{
			geo: box(.72, .58, .72),
			x: 0,
			y: 1.3,
			z: 0,
			color: dark,
			limb: 0
		},
		{
			geo: cone(.32, .48, 4),
			x: 0,
			y: 1.78,
			z: 0,
			color: 13934938,
			limb: 0
		},
		{
			geo: sphere(.1),
			x: 0,
			y: 2.05,
			z: 0,
			color: 16770984,
			limb: 0
		},
		{
			geo: cyl(.06, .06, .7, 5),
			x: -1.05,
			y: .5,
			z: -1.05,
			color: dark,
			limb: 0
		},
		{
			geo: cyl(.06, .06, .7, 5),
			x: 1.05,
			y: .5,
			z: -1.05,
			color: dark,
			limb: 0
		},
		{
			geo: cyl(.06, .06, .7, 5),
			x: -1.05,
			y: .5,
			z: 1.05,
			color: dark,
			limb: 0
		},
		{
			geo: cyl(.06, .06, .7, 5),
			x: 1.05,
			y: .5,
			z: 1.05,
			color: dark,
			limb: 0
		}
	]);
}
function market() {
	return bake([
		{
			geo: box(2.3, .12, 1.7),
			x: 0,
			y: .06,
			z: 0,
			color: 7234136,
			limb: 0
		},
		{
			geo: cyl(.05, .05, 1.35, 5),
			x: -1,
			y: .72,
			z: -.7,
			color: 7029286,
			limb: 0
		},
		{
			geo: cyl(.05, .05, 1.35, 5),
			x: 1,
			y: .72,
			z: -.7,
			color: 7029286,
			limb: 0
		},
		{
			geo: cyl(.05, .05, 1.35, 5),
			x: -1,
			y: .72,
			z: .7,
			color: 7029286,
			limb: 0
		},
		{
			geo: cyl(.05, .05, 1.35, 5),
			x: 1,
			y: .72,
			z: .7,
			color: 7029286,
			limb: 0
		},
		{
			geo: box(2.6, .08, 2),
			x: 0,
			y: 1.42,
			z: 0,
			color: 12868664,
			limb: 0
		},
		{
			geo: box(2.2, .06, .16),
			x: 0,
			y: 1.2,
			z: .85,
			color: 15193e3,
			limb: 0
		},
		{
			geo: box(1.5, .32, .7),
			x: 0,
			y: .5,
			z: 0,
			color: 15193e3,
			limb: 0
		},
		{
			geo: sphere(.12),
			x: -.45,
			y: .78,
			z: .2,
			color: 14183290,
			limb: 0
		},
		{
			geo: sphere(.11),
			x: .4,
			y: .76,
			z: -.12,
			color: 4098629,
			limb: 0
		},
		{
			geo: sphere(.1),
			x: .05,
			y: .8,
			z: .25,
			color: 15913835,
			limb: 0
		}
	]);
}
function bird() {
	return bake([
		{
			geo: sphere(.08),
			x: 0,
			y: .08,
			z: 0,
			color: 2896696,
			limb: 0,
			sx: 1.5,
			sy: .65,
			sz: .85
		},
		{
			geo: box(.28, .015, .1),
			x: -.16,
			y: .1,
			z: 0,
			color: 6055792,
			limb: 3,
			rz: .45
		},
		{
			geo: box(.28, .015, .1),
			x: .16,
			y: .1,
			z: 0,
			color: 6055792,
			limb: 4,
			rz: -.45
		},
		{
			geo: cone(.03, .09, 4),
			x: 0,
			y: .08,
			z: .1,
			rx: Math.PI / 2,
			color: 15249754,
			limb: 0
		}
	]);
}
function house() {
	const wall = 12886650;
	const roof = 9321778;
	const wood = 6044200;
	const win = 14019062;
	return bake([
		{
			geo: box(2.35, .18, 1.9),
			x: 0,
			y: .09,
			z: 0,
			color: 9275008,
			limb: 0
		},
		{
			geo: box(2.1, 1.05, 1.6),
			x: 0,
			y: .7,
			z: 0,
			color: wall,
			limb: 0
		},
		{
			geo: cone(1.55, .85, 4),
			x: 0,
			y: 1.55,
			z: 0,
			ry: Math.PI / 4,
			color: roof,
			limb: 0
		},
		{
			geo: box(.38, .72, .08),
			x: 0,
			y: .52,
			z: .84,
			color: wood,
			limb: 0
		},
		{
			geo: box(.32, .28, .06),
			x: -.55,
			y: .9,
			z: .83,
			color: win,
			limb: 0
		},
		{
			geo: box(.32, .28, .06),
			x: .55,
			y: .9,
			z: .83,
			color: win,
			limb: 0
		},
		{
			geo: box(.22, .4, .22),
			x: .7,
			y: 1.35,
			z: -.35,
			color: 8021336,
			limb: 0
		},
		{
			geo: box(.16, .08, .55),
			x: 0,
			y: .08,
			z: 1.05,
			color: 7234136,
			limb: 0
		}
	]);
}
function farm() {
	return bake([
		{
			geo: box(2.3, .12, 1.7),
			x: 0,
			y: .06,
			z: 0,
			color: 6965810,
			limb: 0
		},
		{
			geo: box(1.9, .1, .22),
			x: 0,
			y: .16,
			z: -.45,
			color: 4098629,
			limb: 0
		},
		{
			geo: box(1.9, .1, .22),
			x: 0,
			y: .16,
			z: 0,
			color: 5151308,
			limb: 0
		},
		{
			geo: box(1.9, .1, .22),
			x: 0,
			y: .16,
			z: .45,
			color: 3108408,
			limb: 0
		},
		{
			geo: cyl(.04, .04, .55, 5),
			x: -1.05,
			y: .32,
			z: -.75,
			color: 7029286,
			limb: 0
		},
		{
			geo: cyl(.04, .04, .55, 5),
			x: 1.05,
			y: .32,
			z: -.75,
			color: 7029286,
			limb: 0
		},
		{
			geo: cyl(.04, .04, .55, 5),
			x: -1.05,
			y: .32,
			z: .75,
			color: 7029286,
			limb: 0
		},
		{
			geo: cyl(.04, .04, .55, 5),
			x: 1.05,
			y: .32,
			z: .75,
			color: 7029286,
			limb: 0
		}
	]);
}
function tower() {
	return bake([
		{
			geo: cyl(.7, .85, 2.4, 8),
			x: 0,
			y: 1.2,
			z: 0,
			color: 9276036,
			limb: 0
		},
		{
			geo: cone(1.05, .9, 8),
			x: 0,
			y: 2.7,
			z: 0,
			color: 9321778,
			limb: 0
		},
		{
			geo: box(.28, .42, .08),
			x: 0,
			y: .5,
			z: .8,
			color: 4861474,
			limb: 0
		},
		{
			geo: box(.28, .32, .06),
			x: 0,
			y: 1.5,
			z: .78,
			color: 14019062,
			limb: 0
		},
		{
			geo: box(.22, .22, .06),
			x: .55,
			y: 1.7,
			z: .35,
			color: 14019062,
			limb: 0
		}
	]);
}
function castle() {
	const stone = 10130830;
	const roof = 7222320;
	return bake([
		{
			geo: box(3.4, 1.3, 2.6),
			x: 0,
			y: .7,
			z: 0,
			color: stone,
			limb: 0
		},
		{
			geo: box(1.3, 2.1, 1.3),
			x: 0,
			y: 1.15,
			z: -.15,
			color: 9341314,
			limb: 0
		},
		{
			geo: cone(.95, .8, 4),
			x: 0,
			y: 2.45,
			z: -.15,
			ry: Math.PI / 4,
			color: roof,
			limb: 0
		},
		{
			geo: cyl(.38, .42, 1.8, 7),
			x: -1.45,
			y: .95,
			z: -1.05,
			color: stone,
			limb: 0
		},
		{
			geo: cyl(.38, .42, 1.8, 7),
			x: 1.45,
			y: .95,
			z: -1.05,
			color: stone,
			limb: 0
		},
		{
			geo: cyl(.38, .42, 1.8, 7),
			x: -1.45,
			y: .95,
			z: 1.05,
			color: stone,
			limb: 0
		},
		{
			geo: cyl(.38, .42, 1.8, 7),
			x: 1.45,
			y: .95,
			z: 1.05,
			color: stone,
			limb: 0
		},
		{
			geo: cone(.5, .55, 7),
			x: -1.45,
			y: 2.05,
			z: -1.05,
			color: roof,
			limb: 0
		},
		{
			geo: cone(.5, .55, 7),
			x: 1.45,
			y: 2.05,
			z: -1.05,
			color: roof,
			limb: 0
		},
		{
			geo: cone(.5, .55, 7),
			x: -1.45,
			y: 2.05,
			z: 1.05,
			color: roof,
			limb: 0
		},
		{
			geo: cone(.5, .55, 7),
			x: 1.45,
			y: 2.05,
			z: 1.05,
			color: roof,
			limb: 0
		},
		{
			geo: box(.7, .9, .1),
			x: 0,
			y: .5,
			z: 1.35,
			color: 4074018,
			limb: 0
		},
		{
			geo: box(.28, .28, .06),
			x: 0,
			y: 1.7,
			z: .52,
			color: 14019062,
			limb: 0
		},
		{
			geo: cyl(.03, .03, .7, 4),
			x: 0,
			y: 2.9,
			z: -.15,
			color: 7029286,
			limb: 0
		}
	]);
}
function wall() {
	return bake([
		{
			geo: box(2.1, 1.05, .42),
			x: 0,
			y: .55,
			z: 0,
			color: 9078400,
			limb: 0
		},
		{
			geo: box(.28, .28, .48),
			x: -.7,
			y: 1.15,
			z: 0,
			color: 8157298,
			limb: 0
		},
		{
			geo: box(.28, .28, .48),
			x: 0,
			y: 1.15,
			z: 0,
			color: 8157298,
			limb: 0
		},
		{
			geo: box(.28, .28, .48),
			x: .7,
			y: 1.15,
			z: 0,
			color: 8157298,
			limb: 0
		}
	]);
}
function boat() {
	return bake([
		{
			geo: box(.7, .28, 1.7),
			x: 0,
			y: .24,
			z: 0,
			color: 9321778,
			limb: 0,
			sx: 1,
			sy: .8,
			sz: 1
		},
		{
			geo: box(.5, .16, .4),
			x: 0,
			y: .4,
			z: -.15,
			color: 15194052,
			limb: 0
		},
		{
			geo: cyl(.03, .03, .9, 5),
			x: 0,
			y: .85,
			z: -.15,
			color: 7029286,
			limb: 0
		},
		{
			geo: box(.02, .45, .32),
			x: .12,
			y: .85,
			z: -.15,
			color: 16052196,
			limb: 0
		}
	]);
}
function firepit() {
	const parts = [];
	for (let i = 0; i < 6; i++) {
		const a = i / 6 * Math.PI * 2;
		parts.push({
			geo: sphere(.12),
			x: Math.cos(a) * .32,
			y: .08,
			z: Math.sin(a) * .32,
			color: 7235424,
			limb: 0,
			sy: .7
		});
	}
	parts.push({
		geo: cyl(.18, .22, .08, 8),
		x: 0,
		y: .05,
		z: 0,
		color: 3814190,
		limb: 0
	});
	return bake(parts, 1.4, 1.4, 1.4);
}
function flame() {
	return bake([{
		geo: cone(.12, .38, 6),
		x: 0,
		y: .28,
		z: 0,
		color: 16742962,
		limb: 0
	}, {
		geo: cone(.07, .24, 6),
		x: .02,
		y: .4,
		z: 0,
		color: 16769162,
		limb: 0
	}]);
}
function flag() {
	return bake([{
		geo: box(.42, .28, .03),
		x: .2,
		y: 0,
		z: 0,
		color: 16777215,
		limb: 0
	}]);
}
function rock() {
	return bake([{
		geo: geo("ico", () => new IcosahedronGeometry(.55, 0)),
		x: 0,
		y: .32,
		z: 0,
		color: 9078400,
		limb: 0,
		sx: 1.2,
		sy: .75,
		sz: 1
	}, {
		geo: sphere(.28),
		x: .28,
		y: .22,
		z: .08,
		color: 7236196,
		limb: 0
	}]);
}
function bush() {
	return bake([
		{
			geo: sphere(.32),
			x: 0,
			y: .28,
			z: 0,
			color: 3111486,
			limb: 0
		},
		{
			geo: sphere(.22),
			x: .18,
			y: .24,
			z: .08,
			color: 4099146,
			limb: 0
		},
		{
			geo: sphere(.18),
			x: -.16,
			y: .22,
			z: -.05,
			color: 2385970,
			limb: 0
		}
	]);
}
function flower() {
	return bake([
		{
			geo: cyl(.015, .02, .28, 4),
			x: 0,
			y: .14,
			z: 0,
			color: 3107380,
			limb: 0
		},
		{
			geo: sphere(.07),
			x: 0,
			y: .32,
			z: 0,
			color: 14183290,
			limb: 0
		},
		{
			geo: sphere(.035),
			x: 0,
			y: .32,
			z: 0,
			color: 15913835,
			limb: 0
		}
	]);
}
function grass() {
	return bake([{
		geo: cone(.05, .42, 4),
		x: 0,
		y: .21,
		z: 0,
		color: 5151302,
		limb: 0
	}, {
		geo: cone(.035, .3, 3),
		x: .06,
		y: .15,
		z: .02,
		rz: .3,
		color: 4028984,
		limb: 0
	}]);
}
var RACES = {
	human: {
		skin: 14726287,
		cloth: 4091802,
		trim: 2773624,
		hair: 4863016,
		pants: 4016738,
		boot: 4863016
	},
	elf: {
		skin: 15782580,
		cloth: 3111506,
		trim: 1989180,
		hair: 15127194,
		pants: 2380858,
		boot: 7033656
	},
	orc: {
		skin: 8231522,
		cloth: 6964018,
		trim: 5124646,
		hair: 2761756,
		pants: 4076588,
		boot: 2892828
	},
	dwarf: {
		skin: 14133124,
		cloth: 9256253,
		trim: 7221296,
		hair: 9063976,
		pants: 4864562,
		boot: 3812388
	}
};
function buildGeometries() {
	const map = /* @__PURE__ */ new Map();
	const races = Object.keys(RACES);
	for (const race of races) {
		const base = {
			...RACES[race],
			bulk: race === "orc" ? 1.18 : race === "dwarf" ? 1.22 : race === "elf" ? .92 : 1,
			tall: race === "dwarf" ? .78 : race === "elf" ? 1.08 : race === "orc" ? 1.04 : 1
		};
		map.set(race, person({
			...base,
			hat: race === "elf" ? "hood" : race === "dwarf" ? "cap" : "none",
			beard: race === "dwarf",
			tusks: race === "orc",
			ears: race === "elf"
		}));
		map.set(`${race}_w`, person({
			...base,
			hat: "helmet",
			sword: true,
			shield: true
		}));
		map.set(`${race}_k`, person({
			...base,
			hat: "crown",
			cape: true,
			sword: true,
			beard: race === "dwarf" || race === "human"
		}));
	}
	const human = RACES.human;
	map.set("baby", person({
		...human,
		bulk: .85,
		tall: 1,
		hat: "none",
		baby: true,
		cloth: 14140580,
		pants: 13351066
	}));
	map.set("chicken", chicken());
	map.set("sheep", sheep());
	map.set("cow", cow());
	map.set("deer", deer());
	map.set("wolf", wolf());
	map.set("bear", bear());
	map.set("tiger", tiger());
	map.set("dragon", dragon());
	map.set("oak", oak());
	map.set("pine", pine());
	map.set("palm", palm());
	map.set("rock", rock());
	map.set("bush", bush());
	map.set("flower", flower());
	map.set("house", house());
	map.set("farm", farm());
	map.set("tower", tower());
	map.set("castle", castle());
	map.set("shrine", shrine());
	map.set("market", market());
	map.set("wall", wall());
	map.set("boat", boat());
	map.set("firepit", firepit());
	map.set("flame", flame());
	map.set("flag", flag());
	map.set("bird", bird());
	map.set("grass", grass());
	return map;
}
var MAX = {
	human: 48,
	elf: 40,
	orc: 40,
	dwarf: 36,
	human_w: 24,
	elf_w: 20,
	orc_w: 20,
	dwarf_w: 20,
	human_k: 6,
	elf_k: 6,
	orc_k: 6,
	dwarf_k: 6,
	baby: 36,
	chicken: 36,
	sheep: 24,
	cow: 20,
	deer: 24,
	wolf: 16,
	bear: 10,
	tiger: 12,
	dragon: 4,
	oak: 240,
	pine: 140,
	palm: 90,
	rock: 140,
	bush: 140,
	flower: 120,
	house: 80,
	farm: 40,
	tower: 30,
	castle: 12,
	shrine: 16,
	market: 20,
	wall: 90,
	boat: 16,
	firepit: 28,
	flame: 48,
	flag: 12,
	bird: 10,
	grass: 1100
};
var BIOME_COLOR = {
	0: [
		.36,
		.56,
		.28
	],
	1: [
		.79,
		.71,
		.48
	],
	2: [
		.22,
		.4,
		.2
	],
	3: [
		.86,
		.9,
		.93
	],
	4: [
		.28,
		.38,
		.25
	],
	5: [
		.45,
		.44,
		.41
	],
	6: [
		.32,
		.24,
		.18
	],
	7: [
		.42,
		.38,
		.32
	],
	8: [
		.72,
		.24,
		.08
	]
};
var WorldView = class {
	canvas;
	scene = new Scene();
	camera = new OrthographicCamera(-36, 36, 36, -36, .1, 700);
	renderer;
	focus = new Vector3();
	yaw = .45;
	dist = 36;
	shake = 0;
	drawCalls = 0;
	sim = null;
	gfx = null;
	geos;
	meshes = /* @__PURE__ */ new Map();
	lit;
	soft;
	flameMat;
	flagMat;
	terrainMat;
	terrain = null;
	water;
	waterMat;
	sky;
	skyMat;
	sun;
	moon;
	hemi;
	ambient;
	lamps = [];
	clouds = [];
	rain;
	rainPos;
	stars;
	ring;
	meteor;
	bolt;
	boom;
	fx = [];
	grass = [];
	dummy = new Object3D();
	tint = new Color();
	tmp = new Vector3();
	tmp2 = new Vector3();
	raycaster = new Raycaster();
	sunDir = new Vector3();
	time = 0;
	builtSpan = -1;
	constructor(canvas) {
		this.canvas = canvas;
		this.renderer = new WebGLRenderer({
			canvas,
			antialias: true,
			alpha: false,
			powerPreference: "high-performance"
		});
		this.renderer.outputColorSpace = SRGBColorSpace;
		this.renderer.toneMapping = 4;
		this.renderer.toneMappingExposure = 1.12;
		this.renderer.shadowMap.enabled = true;
		this.renderer.shadowMap.type = 2;
		this.renderer.setClearColor(10401992, 1);
		this.lit = new MeshStandardMaterial({
			vertexColors: true,
			roughness: .68,
			metalness: .03
		});
		this.soft = new MeshStandardMaterial({
			vertexColors: true,
			roughness: .86,
			metalness: 0
		});
		this.flameMat = new MeshStandardMaterial({
			vertexColors: true,
			emissive: new Color(16738858),
			emissiveIntensity: 1.5,
			roughness: .42
		});
		this.flagMat = new MeshStandardMaterial({
			vertexColors: true,
			roughness: .5,
			metalness: .04,
			side: 2
		});
		this.terrainMat = new MeshStandardMaterial({
			vertexColors: true,
			roughness: .94,
			metalness: 0
		});
		this.sun = new DirectionalLight(16773588, 2.5);
		this.sun.castShadow = true;
		this.sun.shadow.mapSize.set(2048, 2048);
		this.sun.shadow.bias = -3e-4;
		this.sun.shadow.normalBias = .045;
		this.sun.shadow.camera.near = 2;
		this.sun.shadow.camera.far = 180;
		this.scene.add(this.sun, this.sun.target);
		this.moon = new DirectionalLight(10204893, .15);
		this.scene.add(this.moon, this.moon.target);
		this.hemi = new HemisphereLight(12967413, 7178834, .55);
		this.ambient = new AmbientLight(12043471, .28);
		this.scene.add(this.hemi, this.ambient);
		for (let i = 0; i < 4; i++) {
			const lamp = new PointLight(16757610, 0, 16, 2);
			this.lamps.push(lamp);
			this.scene.add(lamp);
		}
		this.skyMat = new ShaderMaterial({
			side: 1,
			depthWrite: false,
			fog: false,
			uniforms: {
				uTop: { value: new Color("#7eb6e8") },
				uHor: { value: new Color("#f3e2c4") },
				uBot: { value: new Color("#d7c3a4") },
				uSun: { value: new Vector3(0, 1, 0) },
				uStars: { value: 0 }
			},
			vertexShader: `
        varying vec3 vPos;
        void main() {
          vPos = position;
          gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0);
        }
      `,
			fragmentShader: `
        varying vec3 vPos;
        uniform vec3 uTop;
        uniform vec3 uHor;
        uniform vec3 uBot;
        uniform vec3 uSun;
        uniform float uStars;
        void main() {
          vec3 dir = normalize(vPos);
          float h = clamp(dir.y * 0.55 + 0.35, 0.0, 1.0);
          vec3 col = mix(uBot, uHor, smoothstep(0.0, 0.42, h));
          col = mix(col, uTop, smoothstep(0.28, 0.95, h));
          vec3 sun = normalize(uSun);
          float disc = pow(max(dot(dir, sun), 0.0), 90.0);
          float glow = pow(max(dot(dir, sun), 0.0), 8.0);
          col += vec3(1.0, 0.86, 0.62) * disc + vec3(1.0, 0.72, 0.4) * glow * 0.28;
          float star = fract(sin(dot(floor(dir.xy * 180.0), vec2(12.9898, 78.233))) * 43758.5453);
          col += step(0.993, star) * uStars;
          gl_FragColor = vec4(col, 1.0);
        }
      `
		});
		this.sky = new Mesh(new SphereGeometry(360, 24, 16), this.skyMat);
		this.sky.frustumCulled = false;
		this.scene.add(this.sky);
		this.waterMat = new ShaderMaterial({
			transparent: true,
			depthWrite: false,
			fog: false,
			uniforms: {
				uTime: { value: 0 },
				uDeep: { value: new Color("#1d5c78") },
				uShallow: { value: new Color("#6eb8b0") },
				uSun: { value: new Vector3(0, 1, 0) },
				uBlood: { value: 0 }
			},
			vertexShader: `
        uniform float uTime;
        varying vec3 vW;
        varying vec3 vN;
        varying float vCrest;
        void main() {
          vec3 p = position;
          float w1 = sin(p.x * 0.31 + uTime * 1.35) * 0.09;
          float w2 = sin(p.z * 0.22 - uTime * 0.95 + p.x * 0.07) * 0.07;
          float w3 = sin((p.x + p.z) * 0.55 + uTime * 2.1) * 0.025;
          p.y += w1 + w2 + w3;
          vec4 wp = modelMatrix * vec4(p, 1.0);
          vW = wp.xyz;
          vCrest = w3 * 18.0 + 0.5;
          vN = normalize(vec3(
            -cos(p.x * 0.31 + uTime * 1.35) * 0.09,
            1.0,
            -cos(p.z * 0.22 - uTime * 0.95) * 0.07
          ));
          gl_Position = projectionMatrix * viewMatrix * wp;
        }
      `,
			fragmentShader: `
        uniform vec3 uDeep;
        uniform vec3 uShallow;
        uniform vec3 uSun;
        uniform float uBlood;
        varying vec3 vW;
        varying vec3 vN;
        varying float vCrest;
        void main() {
          vec3 viewDir = normalize(cameraPosition - vW);
          vec3 n = normalize(vN);
          float fres = pow(1.0 - max(dot(viewDir, n), 0.0), 2.2);
          vec3 col = mix(uDeep, uShallow, fres);
          float foam = smoothstep(0.62, 0.95, vCrest);
          col = mix(col, vec3(0.9, 0.96, 0.95), foam * 0.45);
          col = mix(col, vec3(0.45, 0.05, 0.07), uBlood);
          vec3 ref = reflect(-normalize(uSun), n);
          float spec = pow(max(dot(ref, viewDir), 0.0), 64.0);
          float glitter = pow(max(dot(ref, viewDir), 0.0), 12.0);
          col += vec3(1.0, 0.95, 0.82) * spec * 0.7;
          col += vec3(0.75, 0.9, 0.95) * glitter * 0.12;
          gl_FragColor = vec4(col, 0.82);
        }
      `
		});
		const waterGeo = new PlaneGeometry(1, 1, 48, 48);
		waterGeo.rotateX(-Math.PI / 2);
		this.water = new Mesh(waterGeo, this.waterMat);
		this.water.renderOrder = 2;
		this.scene.add(this.water);
		const cloudGeo = new SphereGeometry(1, 8, 6);
		const cloudMat = new MeshStandardMaterial({
			color: 16250094,
			roughness: 1,
			transparent: true,
			opacity: .82
		});
		for (let i = 0; i < 8; i++) {
			const c = new Mesh(cloudGeo, cloudMat);
			c.position.set((i - 4) * 18, 16 + i % 3, i % 4 * 14 - 20);
			c.scale.set(6 + i % 3, 1.4, 3.5);
			c.castShadow = false;
			this.clouds.push(c);
			this.scene.add(c);
		}
		const starGeo = new BufferGeometry();
		const starPos = /* @__PURE__ */ new Float32Array(540);
		for (let i = 0; i < 180; i++) {
			const y = 40 + Math.random() * 80;
			const a = Math.random() * Math.PI * 2;
			const r = 40 + Math.random() * 80;
			starPos[i * 3] = Math.cos(a) * r;
			starPos[i * 3 + 1] = y;
			starPos[i * 3 + 2] = Math.sin(a) * r;
		}
		starGeo.setAttribute("position", new BufferAttribute(starPos, 3));
		this.stars = new Points(starGeo, new PointsMaterial({
			color: 16054271,
			size: .45,
			transparent: true,
			opacity: 0
		}));
		this.scene.add(this.stars);
		this.rainPos = /* @__PURE__ */ new Float32Array(2100);
		for (let i = 0; i < 700; i++) {
			this.rainPos[i * 3] = Math.random();
			this.rainPos[i * 3 + 1] = Math.random() * 24;
			this.rainPos[i * 3 + 2] = Math.random();
		}
		const rainGeo = new BufferGeometry();
		rainGeo.setAttribute("position", new BufferAttribute(this.rainPos, 3));
		this.rain = new Points(rainGeo, new PointsMaterial({
			color: 14017775,
			size: .08,
			transparent: true,
			opacity: .7
		}));
		this.rain.visible = false;
		this.rain.frustumCulled = false;
		this.scene.add(this.rain);
		this.ring = new Mesh(new RingGeometry(.45, .62, 20), new MeshBasicMaterial({
			color: 16052712,
			side: 2,
			transparent: true,
			opacity: .9
		}));
		this.ring.rotation.x = -Math.PI / 2;
		this.ring.visible = false;
		this.scene.add(this.ring);
		this.meteor = new Mesh(new IcosahedronGeometry(.55, 0), new MeshStandardMaterial({
			color: 9062962,
			roughness: .6,
			emissive: 16734751,
			emissiveIntensity: .6
		}));
		this.meteor.visible = false;
		this.meteor.castShadow = true;
		this.scene.add(this.meteor);
		const boltGeo = new BufferGeometry();
		boltGeo.setAttribute("position", new BufferAttribute(/* @__PURE__ */ new Float32Array(24), 3));
		this.bolt = new Line(boltGeo, new LineBasicMaterial({ color: 16054271 }));
		this.bolt.visible = false;
		this.bolt.frustumCulled = false;
		this.scene.add(this.bolt);
		this.boom = new Mesh(new RingGeometry(.4, .7, 20), new MeshBasicMaterial({
			color: 16757082,
			side: 2,
			transparent: true,
			opacity: .8
		}));
		this.boom.rotation.x = -Math.PI / 2;
		this.boom.visible = false;
		this.scene.add(this.boom);
		this.scene.fog = new Fog(13228260, 40, 150);
		this.geos = buildGeometries();
		this.focus.set(36, 0, 36);
	}
	bind(sim) {
		this.sim = sim;
		this.focus.set(sim.span * .46, 0, sim.span * .5);
		if (this.builtSpan !== sim.span) this.makeTerrain(sim);
		this.refreshTerrain();
		this.refreshGrass();
		const span = sim.span + 30;
		this.water.scale.set(span, 1, span);
		this.water.position.set(sim.span / 2, sim.waterLevel, sim.span / 2);
	}
	setGraphics(g) {
		this.gfx = g;
		const on = g.shadows !== "off";
		this.renderer.shadowMap.enabled = on;
		this.sun.castShadow = on;
		const size = g.shadows === "high" ? 2048 : g.shadows === "medium" ? 1024 : 512;
		if (this.sun.shadow.mapSize.x !== size) {
			this.sun.shadow.mapSize.set(size, size);
			this.sun.shadow.map?.dispose();
			this.sun.shadow.map = null;
		}
		this.resize();
		if (this.sim) this.refreshGrass();
	}
	resize() {
		const w = Math.max(1, this.canvas.clientWidth);
		const h = Math.max(1, this.canvas.clientHeight);
		const pr = Math.min(1.75, window.devicePixelRatio || 1) * ((this.gfx?.resolution ?? 100) / 100);
		this.renderer.setPixelRatio(pr);
		this.renderer.setSize(w, h, false);
		const viewHeight = 72;
		this.camera.zoom = 36 / this.dist;
		const aspect = w / h;
		this.camera.left = -72 * aspect / 2;
		this.camera.right = viewHeight * aspect / 2;
		this.camera.top = viewHeight / 2;
		this.camera.bottom = -36;
		this.camera.far = Math.max(700, (this.gfx?.viewDistance ?? 140) * 5);
		this.camera.updateProjectionMatrix();
	}
	spawn(fx) {
		for (const item of fx) {
			if (this.fx.length > 16) this.fx.shift();
			this.fx.push({ ...item });
			if (item.kind === "meteor" || item.kind === "boom") this.shake = Math.max(this.shake, .35);
			if (item.kind === "lightning") this.shake = Math.max(this.shake, .12);
		}
	}
	sync(dt) {
		const sim = this.sim;
		if (!sim) return;
		this.time += dt;
		if (sim.terrainDirty) {
			this.refreshTerrain();
			this.refreshGrass();
			sim.terrainDirty = false;
			sim.scatterDirty = false;
		} else if (sim.scatterDirty) {
			this.refreshGrass();
			sim.scatterDirty = false;
		}
		this.updateWorld(dt);
		this.updateCamera(dt);
		this.renderer.render(this.scene, this.camera);
		this.drawCalls = this.renderer.info.render.calls;
	}
	screenToGround(clientX, clientY) {
		const sim = this.sim;
		if (!sim) return null;
		const rect = this.canvas.getBoundingClientRect();
		const ndcX = (clientX - rect.left) / rect.width * 2 - 1;
		const ndcY = -((clientY - rect.top) / rect.height * 2 - 1);
		this.raycaster.setFromCamera(new Vector2(ndcX, ndcY), this.camera);
		const origin = this.raycaster.ray.origin;
		const dir = this.raycaster.ray.direction;
		let t = 0;
		for (let i = 0; i < 42; i++) {
			t += i < 8 ? 1.2 : 2.4;
			this.tmp.copy(origin).addScaledVector(dir, t);
			if (this.tmp.y < sim.heightAt(this.tmp.x, this.tmp.z)) {
				let lo = t - (i < 8 ? 1.2 : 2.4);
				let hi = t;
				for (let k = 0; k < 6; k++) {
					const mid = (lo + hi) * .5;
					this.tmp2.copy(origin).addScaledVector(dir, mid);
					if (this.tmp2.y < sim.heightAt(this.tmp2.x, this.tmp2.z)) hi = mid;
					else lo = mid;
				}
				this.tmp.copy(origin).addScaledVector(dir, hi);
				return {
					x: this.tmp.x,
					z: this.tmp.z
				};
			}
		}
		if (Math.abs(dir.y) > .02) {
			const tPlane = (sim.waterLevel - origin.y) / dir.y;
			if (tPlane > 0) {
				this.tmp.copy(origin).addScaledVector(dir, tPlane);
				return {
					x: this.tmp.x,
					z: this.tmp.z
				};
			}
		}
		return null;
	}
	panOf(x, z) {
		const sim = this.sim;
		if (!sim) return 0;
		this.tmp.set(x, sim.heightAt(x, z) + 1, z).project(this.camera);
		return clamp(this.tmp.x, -1, 1);
	}
	drawMinimap(ctx, w, h) {
		const sim = this.sim;
		if (!sim) return;
		ctx.clearRect(0, 0, w, h);
		const step = Math.max(1, Math.floor(sim.span / 48));
		const n = sim.res;
		for (let z = 0; z < sim.span; z += step) for (let x = 0; x < sim.span; x += step) {
			const col = BIOME_COLOR[sim.biome[z * n + x] ?? 0] ?? BIOME_COLOR[0] ?? [
				.3,
				.4,
				.3
			];
			const wet = (sim.height[z * n + x] ?? 0) < sim.waterLevel ? .55 : 1;
			ctx.fillStyle = `rgb(${Math.floor(col[0] * 255 * wet)},${Math.floor(col[1] * 255 * wet)},${Math.floor(col[2] * 255 * wet)})`;
			ctx.fillRect(x / sim.span * w, z / sim.span * h, step / sim.span * w + 1, step / sim.span * h + 1);
		}
		for (const k of sim.kingdoms) {
			if (k.fallen) continue;
			ctx.fillStyle = k.color;
			ctx.beginPath();
			ctx.arc(k.hx / sim.span * w, k.hz / sim.span * h, 3.5, 0, Math.PI * 2);
			ctx.fill();
		}
		ctx.fillStyle = "#f4f1e8";
		ctx.fillRect(this.focus.x / sim.span * w - 1.5, this.focus.z / sim.span * h - 1.5, 3, 3);
	}
	dispose() {
		this.renderer.setAnimationLoop(null);
		this.renderer.dispose();
		this.renderer.forceContextLoss();
		this.terrain?.geometry.dispose();
		this.geos.forEach((g) => g.dispose());
	}
	makeTerrain(sim) {
		if (this.terrain) {
			this.scene.remove(this.terrain);
			this.terrain.geometry.dispose();
		}
		const n = sim.res;
		const geo = new BufferGeometry();
		const positions = new Float32Array(n * n * 3);
		const colors = new Float32Array(n * n * 3);
		const indices = [];
		for (let z = 0; z < sim.span; z++) for (let x = 0; x < sim.span; x++) {
			const a = z * n + x;
			const b = a + 1;
			const c = a + n;
			const d = c + 1;
			indices.push(a, c, b, b, c, d);
		}
		geo.setAttribute("position", new BufferAttribute(positions, 3));
		geo.setAttribute("color", new BufferAttribute(colors, 3));
		geo.setIndex(indices);
		this.terrain = new Mesh(geo, this.terrainMat);
		this.terrain.receiveShadow = true;
		this.terrain.castShadow = false;
		this.scene.add(this.terrain);
		this.builtSpan = sim.span;
	}
	refreshTerrain() {
		const sim = this.sim;
		const mesh = this.terrain;
		if (!sim || !mesh) return;
		const pos = mesh.geometry.getAttribute("position");
		const col = mesh.geometry.getAttribute("color");
		const n = sim.res;
		const season = Math.floor(sim.day / 2) % 4;
		for (let z = 0; z < n; z++) for (let x = 0; x < n; x++) {
			const i = z * n + x;
			const h = sim.height[i] ?? 0;
			pos.setXYZ(i, x, h, z);
			const biome = sim.biome[i] ?? 0;
			const base = BIOME_COLOR[biome] ?? BIOME_COLOR[0] ?? [
				.3,
				.4,
				.3
			];
			let r = base[0];
			let g = base[1];
			let b = base[2];
			const nse = (x * 13 + z * 7) % 11 / 11;
			r += (nse - .5) * .05;
			g += (nse - .5) * .06;
			if (biome === 0 || biome === 2) {
				if (season === 1) {
					r += .06;
					g -= .02;
				} else if (season === 3) {
					r -= .03;
					b += .05;
				}
			}
			const left = sim.height[i - 1] ?? h;
			const right = sim.height[i + 1] ?? h;
			const up = sim.height[i - n] ?? h;
			const down = sim.height[i + n] ?? h;
			const ao = clamp(.7 + (h - (left + right + up + down) * .25) * .65, .42, 1.18);
			const slope = Math.hypot(right - left, down - up);
			if (slope > .85 && biome !== 1 && biome !== 3 && biome !== 8) {
				const rock = clamp((slope - .85) / 1.2, 0, .7);
				r = r * (1 - rock) + .45 * rock;
				g = g * (1 - rock) + .44 * rock;
				b = b * (1 - rock) + .41 * rock;
			}
			if (h < sim.waterLevel + .15) {
				r = r * .65 + .1;
				g = g * .7 + .18;
				b = b * .55 + .28;
			}
			col.setXYZ(i, r * ao, g * ao, b * ao);
		}
		pos.needsUpdate = true;
		col.needsUpdate = true;
		mesh.geometry.computeVertexNormals();
	}
	refreshGrass() {
		const sim = this.sim;
		if (!sim) return;
		const frac = (this.gfx?.vegetation ?? 100) / 100;
		const target = Math.floor(780 * frac);
		this.grass = [];
		const span = sim.span;
		for (let i = 0; i < target * 3 && this.grass.length < target; i++) {
			const x = 1 + i * 47 % (span - 2) + i * 13 % 10 * .08;
			const z = 1 + i * 29 % (span - 2) + i * 17 % 10 * .08;
			const b = sim.biomeAt(x, z);
			if (sim.heightAt(x, z) < sim.waterLevel + .2) continue;
			if (b !== 0 && b !== 2 && b !== 4) continue;
			this.grass.push({
				x,
				z,
				s: .7 + i * 17 % 10 / 18,
				p: i % 12 * .4
			});
		}
	}
	mesh(key, cast, material) {
		let mesh = this.meshes.get(key);
		if (mesh) return mesh;
		const g = this.geos.get(key);
		if (!g) return null;
		const max = MAX[key] ?? 32;
		mesh = new InstancedMesh(g, material ?? this.lit, max);
		mesh.count = 0;
		mesh.castShadow = cast;
		mesh.receiveShadow = true;
		mesh.frustumCulled = false;
		mesh.instanceMatrix.setUsage(DynamicDrawUsage);
		this.scene.add(mesh);
		this.meshes.set(key, mesh);
		return mesh;
	}
	begin() {
		const counts = /* @__PURE__ */ new Map();
		for (const [key, mesh] of this.meshes) {
			counts.set(key, 0);
			mesh.count = 0;
		}
		return counts;
	}
	push(key, x, y, z, yaw, scale, sway, color, cast = true, material) {
		const mesh = this.mesh(key, cast, material);
		if (!mesh) return;
		const i = mesh.count;
		if (i >= mesh.instanceMatrix.count) return;
		const bob = sway === 0 ? 0 : Math.abs(Math.sin(this.time * 7 + sway)) * .045;
		this.dummy.position.set(x, y + bob, z);
		this.dummy.rotation.set(0, yaw + Math.PI, Math.sin(this.time * 1.4 + sway) * (sway === 0 ? 0 : .05));
		this.dummy.scale.setScalar(Math.max(.001, scale));
		this.dummy.updateMatrix();
		mesh.setMatrixAt(i, this.dummy.matrix);
		if (color) mesh.setColorAt(i, color);
		mesh.count = i + 1;
	}
	finish() {
		for (const mesh of this.meshes.values()) {
			mesh.instanceMatrix.needsUpdate = true;
			if (mesh.instanceColor) mesh.instanceColor.needsUpdate = true;
			mesh.visible = mesh.count > 0;
		}
	}
	updateWorld(dt) {
		const sim = this.sim;
		if (!sim) return;
		this.begin();
		const veg = (this.gfx?.vegetation ?? 100) / 100;
		for (const u of sim.units) {
			if (!u.alive && u.fade <= 0) continue;
			const key = u.kind === "animal" ? u.race : u.role === "baby" ? "baby" : u.role === "warrior" ? `${u.race}_w` : u.role === "king" ? `${u.race}_k` : u.race;
			const h = sim.heightAt(u.x, u.z);
			const fly = u.race === "dragon" ? 2.5 + Math.sin(this.time * 2 + u.phase) * .35 : 0;
			let tint = null;
			if (u.hit > 0) this.tint.setRGB(1, .45, .4);
			else if (u.burn > .2) this.tint.setRGB(1, .5, .28);
			else if (u.frozen > 0) this.tint.setRGB(.72, .86, 1);
			else if (u.plague > 0) this.tint.setRGB(.62, .9, .5);
			else this.tint.setRGB(1, 1, 1);
			tint = this.tint;
			const scale = (u.alive ? 1 : u.fade) * (u.role === "baby" ? .82 : 1);
			this.push(key, u.x, h + fly, u.z, u.yaw, scale, u.moving ? u.phase : 0, tint);
		}
		for (const b of sim.buildings) {
			if (!b.alive) continue;
			const h = b.type === "boat" ? sim.waterLevel - .05 : sim.heightAt(b.x, b.z);
			this.push(b.type, b.x, h, b.z, b.yaw, 1, 0, null);
		}
		for (const t of sim.trees) {
			if (!t.alive) continue;
			if (veg < .99 && t.id % 100 > veg * 100) continue;
			const h = sim.heightAt(t.x, t.z);
			this.push(t.kind, t.x, h, t.z, t.yaw, t.scale * (t.burn > 0 ? .92 : 1), t.phase + 2, null);
		}
		for (const r of sim.rocks) {
			if (!r.alive) continue;
			this.push("rock", r.x, sim.heightAt(r.x, r.z), r.z, r.phase, r.scale, 0, null);
		}
		for (const p of sim.props) {
			if (!p.alive) continue;
			this.push(p.kind, p.x, sim.heightAt(p.x, p.z), p.z, p.yaw, p.scale, p.phase, null, false);
		}
		for (const g of this.grass) this.push("grass", g.x, sim.heightAt(g.x, g.z), g.z, g.p, g.s, g.p, null, false, this.soft);
		let fi = 0;
		for (const b of sim.buildings) {
			if (!b.alive || b.type !== "firepit") continue;
			const pulse = .85 + Math.sin(this.time * 10 + fi) * .18;
			this.push("flame", b.x, sim.heightAt(b.x, b.z) + .05, b.z, this.time * 2, pulse, 0, null, false, this.flameMat);
			fi++;
		}
		for (const b of sim.buildings) {
			if (!b.alive || b.type !== "shrine") continue;
			const pulse = .45 + Math.sin(this.time * 3 + b.id) * .08;
			this.push("flame", b.x, sim.heightAt(b.x, b.z) + 1.85, b.z, 0, pulse, 0, null, false, this.flameMat);
		}
		for (const k of sim.kingdoms) {
			if (k.fallen) continue;
			this.tint.set(k.color);
			this.push("flag", k.hx, sim.heightAt(k.hx, k.hz) + 3.15, k.hz, Math.sin(this.time * 2 + k.id) * .4, 1, 0, this.tint, false, this.flagMat);
		}
		for (let i = 0; i < 7; i++) {
			const a = this.time * .42 + i * .9;
			const rad = 8 + i % 4 * 3.2;
			const x = this.focus.x + Math.cos(a) * rad;
			const z = this.focus.z + Math.sin(a * .85) * rad * .62;
			const y = sim.heightAt(x, z) + 7.5 + i % 3 * 1.4 + Math.sin(this.time * 3 + i) * .35;
			this.push("bird", x, y, z, -a, 1, i + 1, null, false);
		}
		this.finish();
		if (sim.selected) {
			let sx = 0;
			let sz = 0;
			let ok = false;
			if (sim.selected.kind === "unit") {
				const u = sim.units.find((n) => n.id === sim.selected?.id && n.alive);
				if (u) {
					sx = u.x;
					sz = u.z;
					ok = true;
				}
			} else {
				const b = sim.buildings.find((n) => n.id === sim.selected?.id && n.alive);
				if (b) {
					sx = b.x;
					sz = b.z;
					ok = true;
				}
			}
			this.ring.visible = ok;
			if (ok) this.ring.position.set(sx, sim.heightAt(sx, sz) + .08, sz);
		} else this.ring.visible = false;
		this.updateFx(dt, sim);
		this.updateWeather(dt, sim);
	}
	updateFx(dt, sim) {
		let boltOn = false;
		let meteorOn = false;
		let boomOn = false;
		for (const f of this.fx) f.life -= dt;
		this.fx = this.fx.filter((f) => f.life > 0);
		for (const f of this.fx) if (f.kind === "lightning" || f.kind === "bolt") {
			const attr = this.bolt.geometry.getAttribute("position");
			const x1 = f.x2 ?? f.x + 1.5;
			const y1 = f.y2 ?? f.y + 1;
			const z1 = f.z2 ?? f.z;
			const top = f.kind === "lightning" ? f.y + 18 : f.y;
			attr.setXYZ(0, f.kind === "lightning" ? f.x : f.x, top, f.kind === "lightning" ? f.z : f.z);
			attr.setXYZ(1, f.x + .6, (top + y1) * .7, f.z - .4);
			attr.setXYZ(2, x1, y1, z1);
			attr.needsUpdate = true;
			this.bolt.material.color.set(f.kind === "lightning" ? 16251903 : 16769704);
			boltOn = true;
		} else if (f.kind === "meteor") {
			const t = 1 - f.life / f.max;
			this.meteor.visible = true;
			this.meteor.position.set(f.x + (1 - t) * 6, f.y + (1 - t) * 26, f.z - (1 - t) * 4);
			meteorOn = true;
		} else if (f.kind === "boom" || f.kind === "heal" || f.kind === "splash") {
			const t = 1 - f.life / f.max;
			this.boom.visible = true;
			this.boom.position.set(f.x, sim.heightAt(f.x, f.z) + .15, f.z);
			const s = .6 + t * (f.kind === "heal" ? 4 : 7);
			this.boom.scale.setScalar(s);
			this.boom.material.opacity = .75 * (1 - t);
			this.boom.material.color.set(f.kind === "heal" ? 12050626 : f.kind === "splash" ? 12969199 : 16757082);
			boomOn = true;
		}
		this.bolt.visible = boltOn;
		if (!meteorOn) this.meteor.visible = false;
		if (!boomOn) this.boom.visible = false;
		if (sim.tornado) {
			this.boom.visible = true;
			const t = sim.tornado;
			this.boom.position.set(t.x, sim.heightAt(t.x, t.z) + .2, t.z);
			this.boom.scale.setScalar(3.2 + Math.sin(this.time * 8) * .3);
			this.boom.material.opacity = .55;
			this.boom.material.color.set(14015956);
		}
	}
	updateWeather(dt, sim) {
		const hour = sim.time;
		const elev = Math.sin((hour - 6) / 12 * Math.PI);
		const day = clamp(elev, 0, 1);
		const dusk = Math.exp(-((hour - 6.3) ** 2) / 2.2) + Math.exp(-((hour - 18.2) ** 2) / 2.4);
		const night = 1 - day;
		const storm = sim.weather === "storm" ? .35 : sim.weather === "cloudy" ? .18 : 0;
		const top = new Color("#16324d").lerp(new Color("#79b4e4"), day);
		top.lerp(new Color("#c47a58"), dusk * .45);
		const hor = new Color("#1a2740").lerp(new Color("#f2d7b0"), day);
		hor.lerp(new Color("#e38a55"), dusk * .7);
		if (storm > 0) {
			top.lerp(new Color("#6d7c88"), storm);
			hor.lerp(new Color("#8a939a"), storm);
		}
		(this.skyMat.uniforms.uTop?.value).copy(top);
		(this.skyMat.uniforms.uHor?.value).copy(hor);
		(this.skyMat.uniforms.uBot?.value).copy(hor);
		const az = (hour - 6) / 24 * Math.PI * 2;
		this.sunDir.set(Math.cos(az), Math.max(.05, elev), Math.sin(az));
		(this.skyMat.uniforms.uSun?.value).copy(this.sunDir);
		this.skyMat.uniforms.uStars.value = night * .85;
		this.stars.material.opacity = night * .9;
		this.stars.position.copy(this.camera.position).setY(0);
		this.sun.color.set(dusk > .2 ? "#ffb27a" : "#fff2d2");
		this.sun.intensity = .18 + day * 2.55 * (1 - storm * .45);
		this.moon.intensity = night * .38;
		this.hemi.intensity = .22 + day * .42;
		this.hemi.color.set(night > .5 ? "#8ea4c4" : "#d5e6f6");
		this.hemi.groundColor.set(night > .5 ? "#1d2a22" : "#6e8a58");
		this.ambient.intensity = .16 + night * .12 + day * .08;
		this.renderer.toneMappingExposure = .82 + day * .32;
		const fog = this.scene.fog;
		fog.color.copy(hor);
		const view = this.gfx?.viewDistance ?? 140;
		fog.near = 18 + day * 10;
		fog.far = view * (.75 + day * .25);
		this.sun.position.set(this.focus.x + this.sunDir.x * 70, 12 + this.sunDir.y * 60, this.focus.z + this.sunDir.z * 48);
		this.sun.target.position.set(this.focus.x, 0, this.focus.z);
		this.moon.position.set(this.focus.x - this.sunDir.x * 50, 30, this.focus.z - this.sunDir.z * 40);
		this.moon.target.position.copy(this.sun.target.position);
		const span = Math.max(22, this.dist * .85);
		const cam = this.sun.shadow.camera;
		cam.left = -span;
		cam.right = span;
		cam.top = span;
		cam.bottom = -span;
		cam.updateProjectionMatrix();
		this.water.position.y = sim.waterLevel;
		this.waterMat.uniforms.uTime.value = this.time;
		(this.waterMat.uniforms.uSun?.value).copy(this.sunDir);
		this.waterMat.uniforms.uBlood.value = sim.weather === "blood" ? .55 : 0;
		if (sim.weather === "blood") {
			(this.waterMat.uniforms.uDeep?.value).set("#6a2430");
			(this.waterMat.uniforms.uShallow?.value).set("#c46a72");
		} else {
			(this.waterMat.uniforms.uDeep?.value).set(night > .6 ? "#0e2436" : "#1c5d78");
			(this.waterMat.uniforms.uShallow?.value).set(night > .6 ? "#24506a" : "#79c0b4");
		}
		const wet = sim.weather === "rain" || sim.weather === "storm" || sim.weather === "blood";
		this.rain.visible = wet;
		if (wet) {
			const attr = this.rain.geometry.getAttribute("position");
			const spanR = Math.max(18, this.dist);
			for (let i = 0; i < 700; i++) {
				let y = (this.rainPos[i * 3 + 1] ?? 0) - dt * (sim.weather === "storm" ? 38 : 26);
				if (y < 0) y = 22;
				this.rainPos[i * 3 + 1] = y;
				const rx = this.focus.x + ((this.rainPos[i * 3] ?? 0) - .5) * spanR * 1.6;
				const rz = this.focus.z + ((this.rainPos[i * 3 + 2] ?? 0) - .5) * spanR * 1.6;
				attr.setXYZ(i, rx, y + sim.heightAt(rx, rz), rz);
			}
			attr.needsUpdate = true;
			this.rain.material.color.set(sim.weather === "blood" ? 9053232 : 14018546);
		}
		for (let i = 0; i < this.clouds.length; i++) {
			const c = this.clouds[i];
			if (!c) continue;
			c.position.x += dt * (1.2 + i * .15);
			if (c.position.x > sim.span + 30) c.position.x = -20;
			c.position.y = 14 + day * 4 + (sim.weather === "storm" ? -4 : 0);
			c.material.opacity = sim.weather === "clear" ? .72 : .9;
		}
		const lights = [];
		for (const b of sim.buildings) {
			if (!b.alive) continue;
			if (b.type === "firepit") lights.push({
				x: b.x,
				z: b.z,
				hot: 2.2
			});
			else if (b.type === "shrine") lights.push({
				x: b.x,
				z: b.z,
				hot: 1.35
			});
			else if (night > .35 && (b.type === "house" || b.type === "castle" || b.type === "tower" || b.type === "market")) lights.push({
				x: b.x,
				z: b.z,
				hot: .8
			});
		}
		lights.sort((a, b) => Math.hypot(a.x - this.focus.x, a.z - this.focus.z) - Math.hypot(b.x - this.focus.x, b.z - this.focus.z));
		for (let i = 0; i < this.lamps.length; i++) {
			const lamp = this.lamps[i];
			const src = lights[i];
			if (!lamp) continue;
			if (!src) {
				lamp.intensity = 0;
				continue;
			}
			lamp.position.set(src.x, sim.heightAt(src.x, src.z) + 1.5, src.z);
			lamp.intensity = src.hot * (src.hot > 1.5 ? 1 : .35 + night);
			lamp.color.set(src.hot > 1.5 ? 16751178 : 16766884);
		}
		if (sim.quake > 0) this.shake = Math.max(this.shake, .18);
	}
	updateCamera(dt) {
		const sim = this.sim;
		if (!sim) return;
		this.shake = Math.max(0, this.shake - dt * 1.4);
		const gy = sim.heightAt(this.focus.x, this.focus.z);
		const fx = -Math.sin(this.yaw);
		const fz = -Math.cos(this.yaw);
		const lift = Math.max(26, this.dist * .95);
		const back = lift * .82;
		this.camera.zoom = 36 / this.dist;
		this.camera.updateProjectionMatrix();
		this.camera.up.set(0, 1, 0);
		this.camera.position.set(this.focus.x - fx * back + Math.sin(this.time * 42) * this.shake, gy + lift * .7 + Math.cos(this.time * 37) * this.shake * .35, this.focus.z - fz * back);
		this.camera.lookAt(this.focus.x, gy + .35, this.focus.z);
		this.sky.position.copy(this.camera.position);
	}
};
var INDEX_KEY = "singgasana-index-v1";
var SETTINGS_KEY = "singgasana-settings-v1";
function readIndex() {
	try {
		const raw = localStorage.getItem(INDEX_KEY);
		if (!raw) return [];
		const list = JSON.parse(raw);
		return Array.isArray(list) ? list : [];
	} catch {
		return [];
	}
}
function writeIndex(list) {
	localStorage.setItem(INDEX_KEY, JSON.stringify(list.slice(0, 8)));
}
var IslandEngine = class {
	canvas;
	onSnap;
	view = null;
	sim = null;
	audio = new Soundscape();
	keys = /* @__PURE__ */ new Set();
	probeKeys = null;
	pointers = /* @__PURE__ */ new Map();
	drag = 0;
	painting = false;
	panning = false;
	lastX = 0;
	lastY = 0;
	pinch = 0;
	lastPaint = {
		x: 0,
		z: 0,
		ok: false
	};
	space = false;
	phase = "menu";
	paused = false;
	speed = 1;
	tool = "finger";
	cat = "bangsa";
	brush = 1;
	settings = defaultSettings();
	forwardSpeed = 0;
	fps = 0;
	frameMs = 16;
	marks = [];
	acc = 0;
	clock = 0;
	emitAt = 0;
	miniAt = 0;
	voiceAt = 1.6;
	stepAt = .4;
	splashAt = 2;
	toastKey = null;
	toastAt = 0;
	dead = false;
	webgl = null;
	minimap = null;
	loop = (now) => this.frame(now);
	constructor(canvas, onSnap) {
		this.canvas = canvas;
		this.onSnap = onSnap;
		this.settings = this.loadSettings();
	}
	start() {
		try {
			this.view = new WorldView(this.canvas);
			this.view.setGraphics(this.settings.graphics);
		} catch (err) {
			this.webgl = err instanceof Error ? err.message : "webgl";
			this.emit();
			return;
		}
		this.reroll({
			name: "Pulau Fajar",
			size: "medium",
			seed: Math.random() * 1e9 >>> 0
		}, false);
		window.addEventListener("keydown", this.onKeyDown);
		window.addEventListener("keyup", this.onKeyUp);
		window.addEventListener("blur", this.onBlur);
		document.addEventListener("visibilitychange", this.onVis);
		this.canvas.addEventListener("pointerdown", this.onPointerDown);
		this.canvas.addEventListener("pointermove", this.onPointerMove);
		this.canvas.addEventListener("pointerup", this.onPointerUp);
		this.canvas.addEventListener("pointercancel", this.onPointerUp);
		this.canvas.addEventListener("wheel", this.onWheel, { passive: false });
		this.canvas.addEventListener("contextmenu", (e) => e.preventDefault());
		window.addEventListener("resize", this.onResize);
		this.onResize();
		this.mountProbe();
		this.view.renderer.setAnimationLoop(this.loop);
		this.emit();
	}
	dispose() {
		this.dead = true;
		this.view?.dispose();
		window.removeEventListener("keydown", this.onKeyDown);
		window.removeEventListener("keyup", this.onKeyUp);
		window.removeEventListener("blur", this.onBlur);
		document.removeEventListener("visibilitychange", this.onVis);
		this.canvas.removeEventListener("pointerdown", this.onPointerDown);
		this.canvas.removeEventListener("pointermove", this.onPointerMove);
		this.canvas.removeEventListener("pointerup", this.onPointerUp);
		this.canvas.removeEventListener("pointercancel", this.onPointerUp);
		this.canvas.removeEventListener("wheel", this.onWheel);
		window.removeEventListener("resize", this.onResize);
	}
	attachMinimap(canvas) {
		this.minimap = canvas;
	}
	enter() {
		if (!this.sim) return;
		this.audio.unlock();
		this.phase = "play";
		this.paused = false;
		this.speed = 1;
		this.audio.play("ui_open");
		this.emit();
	}
	reroll(opts, enter) {
		this.audio.unlock();
		this.sim = new WorldSim(opts);
		this.view?.bind(this.sim);
		this.phase = enter ? "play" : "menu";
		this.paused = false;
		this.audio.play("ui_open");
		this.emit();
	}
	save() {
		if (!this.sim) return;
		this.audio.unlock();
		try {
			const raw = this.sim.serialize();
			localStorage.setItem(`singgasana-w-${this.sim.id}`, raw);
			const meta = {
				id: this.sim.id,
				name: this.sim.name,
				savedAt: Date.now(),
				size: this.sim.sizeId,
				day: this.sim.day,
				pop: this.sim.popCount()
			};
			const list = readIndex().filter((w) => w.id !== meta.id);
			list.unshift(meta);
			writeIndex(list);
			this.toastKey = "savedOk";
			this.toastAt = 2.4;
			this.audio.play("ui_save");
		} catch {
			this.toastKey = "full";
			this.toastAt = 2.2;
			this.audio.play("ui_error");
		}
		this.emit();
	}
	load(id) {
		this.audio.unlock();
		const raw = localStorage.getItem(`singgasana-w-${id}`);
		if (!raw) return;
		const sim = WorldSim.fromSave(raw);
		if (!sim || !this.view) {
			this.audio.play("ui_error");
			return;
		}
		this.sim = sim;
		this.view.bind(sim);
		this.phase = "play";
		this.paused = false;
		this.audio.play("ui_open");
		this.emit();
	}
	remove(id) {
		localStorage.removeItem(`singgasana-w-${id}`);
		writeIndex(readIndex().filter((w) => w.id !== id));
		this.audio.unlock();
		this.audio.play("ui_close");
		this.emit();
	}
	rename(name) {
		if (this.sim) this.sim.name = name.slice(0, 32);
		this.emit();
	}
	setSpeed(speed) {
		this.speed = speed;
		this.paused = speed <= 0;
		this.audio.unlock();
		this.audio.play("ui_tap");
		this.emit();
	}
	togglePause() {
		if (this.phase !== "play") return;
		this.paused = !this.paused;
		if (this.paused) this.speed = 0;
		else if (this.speed <= 0) this.speed = 1;
		this.audio.unlock();
		this.audio.play(this.paused ? "ui_close" : "ui_open");
		this.emit();
	}
	goMenu() {
		this.phase = "menu";
		this.paused = false;
		this.audio.unlock();
		this.audio.play("ui_close");
		this.emit();
	}
	setTool(tool) {
		this.tool = tool;
		const found = CATS.find((c) => c.tools.includes(tool));
		if (found) this.cat = found.id;
		this.audio.unlock();
		this.audio.play("ui_tap");
		this.emit();
	}
	setCat(cat) {
		this.cat = cat;
		const first = CATS.find((c) => c.id === cat)?.tools[0];
		if (first) this.tool = first;
		this.audio.unlock();
		this.audio.play("ui_tap");
		this.emit();
	}
	setBrush(n) {
		this.brush = n > 1 ? 5 : 1;
		this.audio.unlock();
		this.audio.play("ui_tap");
		this.emit();
	}
	focusKingdom(id) {
		const k = this.sim?.kingdoms.find((item) => item.id === id);
		const view = this.view;
		if (!k || !view) return;
		view.focus.set(k.hx, 0, k.hz);
		this.audio.unlock();
		this.audio.play("select", 0);
		this.emit();
	}
	focusNorm(nx, nz) {
		if (!this.sim || !this.view) return;
		this.view.focus.set(clamp(nx, .02, .98) * this.sim.span, 0, clamp(nz, .02, .98) * this.sim.span);
	}
	clearInspect() {
		if (this.sim) this.sim.selected = null;
		this.emit();
	}
	setLang(lang) {
		this.settings.lang = lang;
		this.persistSettings();
		this.audio.unlock();
		this.audio.play("ui_tap");
		this.emit();
	}
	setGraphics(partial, replacePreset = false) {
		if (replacePreset && partial.preset) this.settings.graphics = {
			...applyPreset(partial.preset),
			showFps: this.settings.graphics.showFps,
			showPerf: this.settings.graphics.showPerf
		};
		else this.settings.graphics = {
			...this.settings.graphics,
			...partial
		};
		this.view?.setGraphics(this.settings.graphics);
		this.persistSettings();
		this.emit();
	}
	setAudio(partial) {
		this.settings.audio = {
			...this.settings.audio,
			...partial
		};
		this.audio.setVolumes(this.settings.audio.master, this.settings.audio.music, this.settings.audio.sfx, this.settings.audio.mute);
		this.persistSettings();
		this.emit();
	}
	nudgeZoom(dir) {
		if (!this.view) return;
		this.audio.unlock();
		this.view.dist = clamp(this.view.dist * (dir > 0 ? .86 : 1.16), 14, 78);
	}
	loadSettings() {
		try {
			const raw = localStorage.getItem(SETTINGS_KEY);
			if (!raw) return defaultSettings();
			const parsed = JSON.parse(raw);
			if (parsed.version !== 1) return defaultSettings();
			return {
				...defaultSettings(),
				...parsed,
				graphics: {
					...defaultSettings().graphics,
					...parsed.graphics
				},
				audio: {
					...defaultSettings().audio,
					...parsed.audio
				}
			};
		} catch {
			return defaultSettings();
		}
	}
	persistSettings() {
		localStorage.setItem(SETTINGS_KEY, JSON.stringify(this.settings));
	}
	mountProbe() {
		if (!new URLSearchParams(location.search).has("qa")) return;
		const view = this.view;
		if (!view) return;
		window.__controlsTest = {
			getYaw: () => view.yaw,
			getSpeed: () => this.forwardSpeed,
			setKeys: (codes) => {
				this.probeKeys = new Set(codes);
			}
		};
	}
	onResize = () => {
		this.view?.resize();
	};
	onVis = () => {
		if (document.hidden) this.audio.suspend();
		else this.audio.resume();
	};
	onBlur = () => {
		this.keys.clear();
		this.space = false;
	};
	onKeyDown = (e) => {
		const target = e.target;
		if (target instanceof HTMLElement) {
			const tag = target.tagName;
			if (tag === "INPUT" || tag === "TEXTAREA" || target.isContentEditable) return;
		}
		this.keys.add(e.code);
		if (e.code === "Space") this.space = true;
		if ([
			"Space",
			"ArrowUp",
			"ArrowDown",
			"ArrowLeft",
			"ArrowRight"
		].includes(e.code)) e.preventDefault();
		if (e.code === "Escape" && this.phase === "play") this.togglePause();
		this.audio.unlock();
	};
	onKeyUp = (e) => {
		this.keys.delete(e.code);
		if (e.code === "Space") this.space = false;
	};
	onWheel = (e) => {
		if (!this.view) return;
		e.preventDefault();
		this.view.dist = clamp(this.view.dist * (e.deltaY > 0 ? 1.08 : .92), 14, 78);
	};
	onPointerDown = (e) => {
		this.audio.unlock();
		this.pointers.set(e.pointerId, {
			x: e.clientX,
			y: e.clientY,
			button: e.button
		});
		this.drag = 0;
		this.lastX = e.clientX;
		this.lastY = e.clientY;
		this.painting = false;
		this.panning = e.button === 1 || e.button === 2 || this.space || this.tool === "finger" || this.phase !== "play";
		if (this.pointers.size === 2) {
			const pts = [...this.pointers.values()];
			this.pinch = Math.hypot((pts[0]?.x ?? 0) - (pts[1]?.x ?? 0), (pts[0]?.y ?? 0) - (pts[1]?.y ?? 0));
			this.panning = true;
			this.painting = false;
		}
		this.canvas.setPointerCapture(e.pointerId);
	};
	onPointerMove = (e) => {
		const prev = this.pointers.get(e.pointerId);
		if (!prev || !this.view || !this.sim) return;
		const dx = e.clientX - prev.x;
		const dy = e.clientY - prev.y;
		prev.x = e.clientX;
		prev.y = e.clientY;
		this.drag += Math.abs(dx) + Math.abs(dy);
		if (this.pointers.size >= 2) {
			const pts = [...this.pointers.values()];
			const dist = Math.hypot((pts[0]?.x ?? 0) - (pts[1]?.x ?? 0), (pts[0]?.y ?? 0) - (pts[1]?.y ?? 0));
			if (this.pinch > 0) this.view.dist = clamp(this.view.dist / (dist / this.pinch), 14, 78);
			this.pinch = dist;
			this.pan(dx, dy);
			return;
		}
		if (this.drag > 7 && (this.panning || this.space || this.tool === "finger" || this.phase !== "play")) {
			this.panning = true;
			this.pan(dx, dy);
			return;
		}
		if (this.phase === "play" && this.drag > 7 && this.tool !== "finger") {
			this.painting = true;
			this.stroke(e.clientX, e.clientY);
		}
	};
	onPointerUp = (e) => {
		const was = this.pointers.get(e.pointerId);
		this.pointers.delete(e.pointerId);
		if (this.pointers.size < 2) this.pinch = 0;
		if (!was || !this.view || !this.sim) return;
		if (this.drag < 8 && e.button === 0 && this.phase === "play") {
			const hit = this.view.screenToGround(e.clientX, e.clientY);
			if (hit) {
				if (this.tool === "finger") this.sim.selectAt(hit.x, hit.z);
				else this.sim.apply(this.tool, hit.x, hit.z, this.brush);
				this.afterSimAction();
			}
		}
		this.painting = false;
		this.lastPaint.ok = false;
	};
	pan(dx, dy) {
		const view = this.view;
		if (!view) return;
		view.camera.updateMatrixWorld();
		const e = view.camera.matrixWorld.elements;
		const scale = view.dist * .00235;
		const rx = e[0] ?? 1;
		const rz = e[2] ?? 0;
		const ux = e[4] ?? 0;
		const uz = e[6] ?? 1;
		view.focus.x -= (rx * dx + ux * dy) * scale;
		view.focus.z -= (rz * dx + uz * dy) * scale;
		this.clampFocus();
	}
	stroke(clientX, clientY) {
		const view = this.view;
		const sim = this.sim;
		if (!view || !sim) return;
		const hit = view.screenToGround(clientX, clientY);
		if (!hit) return;
		if (this.lastPaint.ok && Math.hypot(hit.x - this.lastPaint.x, hit.z - this.lastPaint.z) < 1.15) return;
		this.lastPaint = {
			x: hit.x,
			z: hit.z,
			ok: true
		};
		sim.apply(this.tool, hit.x, hit.z, 1);
		this.afterSimAction();
	}
	afterSimAction() {
		const sim = this.sim;
		const view = this.view;
		if (!sim || !view) return;
		const fx = sim.fxQ.splice(0, sim.fxQ.length);
		view.spawn(fx);
		if (fx.some((f) => f.kind === "meteor" || f.kind === "boom")) view.shake = Math.max(view.shake, .4);
		this.playQueue();
		if (sim.toast) {
			this.toastKey = sim.toast === "full" ? "full" : sim.toast === "needTwo" ? "needTwo" : "needLand";
			this.toastAt = 1.8;
			sim.toast = null;
		}
		this.emit();
	}
	playQueue() {
		const sim = this.sim;
		const view = this.view;
		if (!sim || !view) return;
		const queued = sim.sfxQ.splice(0, sim.sfxQ.length);
		for (const ev of queued) this.audio.play(ev.id, view.panOf(ev.x, ev.z));
	}
	clampFocus() {
		const sim = this.sim;
		const view = this.view;
		if (!sim || !view) return;
		view.focus.x = clamp(view.focus.x, 2, sim.span - 2);
		view.focus.z = clamp(view.focus.z, 2, sim.span - 2);
	}
	frame(now) {
		if (this.dead || !this.view || !this.sim) return;
		const raw = this.clock ? Math.min(.05, (now - this.clock) / 1e3) : .016;
		this.clock = now;
		this.marks.push(now);
		while (this.marks.length && now - (this.marks[0] ?? now) > 1e3) this.marks.shift();
		this.fps = this.marks.length;
		this.frameMs = this.frameMs * .9 + raw * 1e3 * .1;
		this.moveCamera(raw);
		const speed = this.phase === "play" ? this.paused ? 0 : this.speed : .4;
		if (speed > 0) {
			this.acc += raw * speed;
			let guard = 0;
			while (this.acc >= 1 / 30 && guard < 4) {
				this.sim.tick(1 / 30);
				this.acc -= 1 / 30;
				guard++;
			}
		}
		const fx = this.sim.fxQ.splice(0, this.sim.fxQ.length);
		if (fx.length) this.view.spawn(fx);
		this.playQueue();
		if (this.sim.toast) {
			this.toastKey = this.sim.toast;
			this.toastAt = this.sim.toast.startsWith("event_") ? 3.4 : 1.6;
			this.sim.toast = null;
		}
		this.toastAt = Math.max(0, this.toastAt - raw);
		if (this.toastAt <= 0) this.toastKey = null;
		this.ambience(raw);
		const night = this.sim.time < 5.6 || this.sim.time > 19.2 ? 1 : 0;
		this.audio.setScene(this.sim.weather, night);
		this.audio.update(raw);
		this.view.sync(raw);
		this.miniAt -= raw;
		if (this.miniAt <= 0 && this.minimap) {
			this.miniAt = .45;
			const ctx = this.minimap.getContext("2d");
			if (ctx) this.view.drawMinimap(ctx, this.minimap.width, this.minimap.height);
		}
		this.emitAt -= raw;
		if (this.emitAt <= 0) {
			this.emitAt = .25;
			this.emit();
		}
	}
	moveCamera(dt) {
		const view = this.view;
		const sim = this.sim;
		if (!view || !sim) return;
		const down = this.probeKeys ?? this.keys;
		let steer = 0;
		if (down.has("KeyA") || down.has("ArrowLeft")) steer += 1;
		if (down.has("KeyD") || down.has("ArrowRight")) steer -= 1;
		view.yaw += steer * 1.7 * dt;
		let throttle = 0;
		if (down.has("KeyW") || down.has("ArrowUp")) throttle += 1;
		if (down.has("KeyS") || down.has("ArrowDown")) throttle -= 1;
		const fx = -Math.sin(view.yaw);
		const fz = -Math.cos(view.yaw);
		const speed = throttle * 22;
		this.forwardSpeed = speed;
		view.focus.x += fx * speed * dt;
		view.focus.z += fz * speed * dt;
		if (this.phase === "menu" && steer === 0 && throttle === 0 && !this.panning && this.pointers.size === 0) view.yaw += dt * .06;
		this.clampFocus();
	}
	ambience(dt) {
		const sim = this.sim;
		const view = this.view;
		if (!sim || !view || this.phase === "menu") return;
		this.voiceAt -= dt;
		if (this.voiceAt <= 0) {
			this.voiceAt = 2.4 + Math.random() * 2.2;
			const animals = sim.units.filter((u) => u.alive && u.kind === "animal");
			const pick = animals[Math.floor(Math.random() * animals.length)];
			if (pick) {
				const id = pick.race === "chicken" ? "chicken" : pick.race === "sheep" ? "sheep" : pick.race === "cow" ? "cow" : pick.race === "deer" ? "deer" : pick.race === "wolf" ? "wolf" : pick.race === "tiger" ? "roar" : pick.race === "bear" ? "bear" : "dragon";
				this.audio.play(id, view.panOf(pick.x, pick.z));
			}
		}
		this.stepAt -= dt;
		if (this.stepAt <= 0) {
			this.stepAt = .36;
			let best = null;
			let d0 = 18;
			for (const u of sim.units) {
				if (!u.alive || !u.moving) continue;
				const d = Math.hypot(u.x - view.focus.x, u.z - view.focus.z);
				if (d > d0) continue;
				d0 = d;
				const id = u.race === "orc" || u.race === "bear" || u.race === "cow" ? "foot_heavy" : u.race === "deer" || u.race === "sheep" ? "foot_hoof" : u.kind === "animal" ? "foot_paw" : "foot";
				best = {
					x: u.x,
					z: u.z,
					id
				};
			}
			if (best) this.audio.play(best.id, view.panOf(best.x, best.z));
		}
		this.splashAt -= dt;
		if (this.splashAt <= 0) {
			this.splashAt = 3.5 + Math.random() * 3;
			const x = view.focus.x + (Math.random() - .5) * 16;
			const z = view.focus.z + (Math.random() - .5) * 16;
			if (sim.heightAt(x, z) < sim.waterLevel) {
				this.audio.play("splash", view.panOf(x, z));
				view.spawn([{
					kind: "splash",
					x,
					y: sim.waterLevel,
					z,
					life: .5,
					max: .5
				}]);
			} else if (sim.biomeAt(x, z) === 8) this.audio.play("lava", view.panOf(x, z));
		}
	}
	emit() {
		if (this.dead) return;
		this.onSnap(this.snapshot());
	}
	snapshot() {
		const sim = this.sim;
		const kingdoms = [];
		if (sim) for (const k of sim.kingdoms) {
			if (k.fallen) continue;
			const wars = k.wars.map((id) => sim.kingdoms.find((other) => other.id === id)?.name).filter((name) => !!name);
			kingdoms.push({
				id: k.id,
				race: k.race,
				name: k.name,
				color: k.color,
				pop: sim.units.filter((u) => u.alive && u.kingdom === k.id).length,
				food: Math.floor(k.food),
				wood: Math.floor(k.wood),
				stone: Math.floor(k.stone),
				wars,
				boost: k.boost > 0
			});
		}
		return {
			phase: this.phase,
			paused: this.paused,
			speed: this.speed,
			fps: this.fps,
			frameMs: this.frameMs,
			draws: this.view?.drawCalls ?? 0,
			day: sim?.day ?? 1,
			year: sim?.year ?? 1,
			hour: sim?.time ?? 8,
			season: Math.floor((sim?.day ?? 1) / 2) % 4,
			weather: sim?.weather ?? "clear",
			pop: sim?.popCount() ?? 0,
			animals: sim?.units.filter((u) => u.alive && u.kind === "animal").length ?? 0,
			births: sim?.births ?? 0,
			deaths: sim?.deaths ?? 0,
			tool: this.tool,
			cat: this.cat,
			brush: this.brush,
			worldName: sim?.name ?? "",
			size: sim?.sizeId ?? "medium",
			toast: this.toastKey,
			inspect: sim?.inspectSelected() ?? null,
			log: sim?.log ?? [],
			kingdoms,
			saves: readIndex(),
			settings: this.settings,
			webgl: this.webgl,
			shadows: this.settings.graphics.shadows
		};
	}
};
var tables = {
	id: {
		kicker: "Dunia hidup",
		title: "Singgasana",
		lede: "Jadilah dewa di pulau ini. Bangsa membangun, bertani, berkelahi, dan beranak sendiri. Ada candi, pasar, harimau, dan kejadian yang datang sendiri.",
		start: "Mulai",
		reroll: "Pulau baru",
		saved: "Tersimpan",
		settings: "Pengaturan",
		help: "Cara main",
		back: "Kembali",
		pause: "Jeda",
		resume: "Lanjut",
		menu: "Menu pulau",
		save: "Simpan dunia",
		savedOk: "Dunia tersimpan di perangkat ini",
		emptySaves: "Belum ada dunia tersimpan.",
		load: "Muat",
		delete: "Hapus",
		name: "Nama pulau",
		size: "Ukuran",
		small: "Kecil",
		medium: "Sedang",
		large: "Besar",
		lang: "Bahasa",
		graphics: "Grafik",
		audio: "Suara",
		shadows: "Bayangan",
		resolution: "Ketajaman",
		vegetation: "Tumbuhan",
		view: "Jarak pandang",
		fps: "Tampilkan FPS",
		perf: "Angka performa",
		master: "Utama",
		music: "Musik",
		sfx: "Efek",
		mute: "Bisukan",
		off: "Mati",
		low: "Rendah",
		high: "HD",
		ultra: "Ultra",
		preset: "Preset",
		brush: "Rombongan",
		brush1: "Satu",
		brush5: "Lima",
		kingdoms: "Kerajaan",
		noKingdom: "Belum ada kerajaan. Taruh sebuah bangsa.",
		pop: "Jiwa",
		food: "Pangan",
		wood: "Kayu",
		stone: "Batu",
		day: "Hari",
		year: "Tahun",
		fpsLabel: "FPS",
		speed: "Laju waktu",
		focus: "Lihat",
		atWar: "Perang",
		peaceState: "Damai",
		boost: "Diberkati",
		inspect: "Sorotan",
		hp: "Nyawa",
		hunger: "Lapar",
		close: "Tutup",
		helpBody: "Seret untuk menggeser pulau. Cubit atau roda mouse untuk zoom. A memutar pandangan ke kiri, D ke kanan, W dan S maju-mundur. Spasi menahan geser saat alat lain aktif. Ketuk untuk menaruh. Jari memilih makhluk. Mereka hidup sendiri. Candi mempercepat keturunan, pasar menambah pangan, harimau berburu. Sesekali pulau mengadakan pesta, gerhana, atau kemarau.",
		keys: "WASD putar dan gerak · spasi geser · ketuk menaruh",
		full: "Pulau ini sudah penuh",
		needLand: "Tidak bisa ditaruh di situ",
		needTwo: "Butuh dua kerajaan",
		webgl: "Grafik 3D tidak bisa dimulai di peramban ini.",
		season0: "Tumbuh",
		season1: "Kemarau",
		season2: "Embun",
		season3: "Dingin",
		weather_clear: "Cerah",
		weather_cloudy: "Berawan",
		weather_rain: "Hujan",
		weather_storm: "Badai",
		weather_blood: "Hujan darah",
		cat_bangsa: "Bangsa",
		cat_satwa: "Satwa",
		cat_alam: "Alam",
		cat_kota: "Kota",
		cat_bencana: "Bencana",
		cat_kuasa: "Kuasa",
		state_wander: "Mengembara",
		state_chop: "Menebang",
		state_mine: "Menambang",
		state_farm: "Bertani",
		state_build: "Membangun",
		state_fight: "Bertarung",
		state_sleep: "Tidur",
		state_flee: "Melarikan diri",
		state_eat: "Makan",
		state_dead: "Gugur",
		role_villager: "Warga",
		role_warrior: "Prajurit",
		role_king: "Raja",
		role_baby: "Anak",
		role_beast: "Satwa",
		race_human: "Manusia",
		race_elf: "Elf",
		race_orc: "Orc",
		race_dwarf: "Kurcaci",
		tool_finger: "Jari",
		tool_erase: "Hapus",
		tool_human: "Manusia",
		tool_elf: "Elf",
		tool_orc: "Orc",
		tool_dwarf: "Kurcaci",
		tool_warrior: "Prajurit",
		tool_king: "Raja",
		tool_chicken: "Ayam",
		tool_sheep: "Domba",
		tool_cow: "Sapi",
		tool_deer: "Rusa",
		tool_wolf: "Serigala",
		tool_bear: "Beruang",
		tool_tiger: "Harimau",
		tool_dragon: "Naga",
		tool_tree: "Pohon",
		tool_pine: "Pinus",
		tool_palm: "Palem",
		tool_rock: "Batu",
		tool_bush: "Semak",
		tool_flower: "Bunga",
		tool_house: "Rumah",
		tool_farm: "Ladang",
		tool_tower: "Menara",
		tool_castle: "Kastil",
		tool_shrine: "Candi",
		tool_market: "Pasar",
		tool_wall: "Tembok",
		tool_boat: "Perahu",
		tool_firepit: "Api unggun",
		tool_grass: "Rumput",
		tool_sand: "Pasir",
		tool_forest: "Hutan",
		tool_snow: "Salju",
		tool_swamp: "Rawa",
		tool_road: "Jalan",
		tool_lava: "Lava",
		tool_lightning: "Petir",
		tool_meteor: "Meteorit",
		tool_fire: "Kebakaran",
		tool_rain: "Hujan",
		tool_blood: "Hujan darah",
		tool_quake: "Gempa",
		tool_tornado: "Angin puyuh",
		tool_tsunami: "Tsunami",
		tool_plague: "Wabah",
		tool_freeze: "Bekukan",
		tool_heal: "Sembuhkan",
		tool_bless: "Berkah",
		tool_peace: "Damai",
		tool_warhorn: "Sangkakala perang",
		hint_finger: "Ketuk makhluk atau bangunan untuk melihatnya. Seret untuk menggeser.",
		hint_erase: "Hapus makhluk, pohon, dan bangunan di sekitar ketukan.",
		hint_human: "Taruh warga. Kerajaan baru muncul jika jauh dari yang lama.",
		hint_warrior: "Prajurit menjaga dan menyerang musuh serta binatang buas.",
		hint_king: "Raja memimpin kerajaan. Satu raja tiap takhta.",
		hint_dragon: "Naga terbang, mengaum, dan menghembuskan api.",
		hint_tiger: "Harimau berburu rusa, ternak, dan orang yang lengah.",
		hint_shrine: "Candi mempercepat kelahiran dan menyalakan api suci.",
		hint_market: "Pasar menambah pangan kerajaan pelan-pelan.",
		hint_lightning: "Sambar petir. Merusak dan menyalakan api.",
		hint_meteor: "Jatuhkan batu langit. Kawah, api, dan guncangan.",
		hint_rain: "Hujan memadamkan api dan mengisi suasana.",
		hint_blood: "Hujan merah menyakiti semua yang hidup.",
		hint_quake: "Guncang tanah dan yang berdiri di atasnya.",
		hint_tornado: "Pusaran menarik dan melempar makhluk.",
		hint_tsunami: "Air laut naik dan menelan pantai.",
		hint_plague: "Wabah menular di antara yang berdekatan.",
		hint_freeze: "Hentikan gerak di dalam lingkaran.",
		hint_heal: "Pulihkan nyawa dan hilangkan wabah.",
		hint_bless: "Kerajaan terdekat bekerja lebih cepat dan dapat bekal.",
		hint_peace: "Hentikan perang dua kerajaan terdekat.",
		hint_warhorn: "Paksa dua kerajaan terdekat saling perang.",
		hint_house: "Rumah memberi tempat tidur dan ruang untuk anak.",
		hint_farm: "Ladang menghasilkan pangan pelan-pelan.",
		hint_tower: "Menara memanah musuh yang mendekat.",
		hint_castle: "Kastil menjadi pusat takhta.",
		hint_boat: "Perahu hanya bisa di air.",
		hint_lava: "Lava membakar siapa pun yang menginjaknya.",
		event_festival: "Pesta panen — kerajaan terdekat mendapat bekal",
		event_eclipse: "Gerhana meredupkan langit",
		event_bounty: "Kawanan rusa muncul di pulau",
		event_pilgrim: "Seorang peziarah bergabung dengan kerajaan",
		event_drought: "Kemarau mengurangi pangan",
		event_aurora: "Cahaya utara menyembuhkan yang hidup",
		apk: "Unduh APK Android",
		apkNote: "Pasang berkasnya, izinkan sumber tidak dikenal. Dunia tersimpan di HP, tanpa internet.",
		goals: "Jejak dewa",
		goal_pop: "Empat puluh jiwa hidup di pulau",
		goal_kings: "Dua kerajaan berdiri bersamaan",
		goal_war: "Perang pecah di antara takhta",
		goal_storm: "Badai atau hujan darah menyapu pulau",
		goal_year: "Pulau melewati tahun kedua",
		medal: "Jejak baru",
		log_war: "{a} menyatakan perang pada {b}",
		log_peace: "{a} berdamai dengan {b}",
		log_born: "Seorang anak lahir di {a}",
		log_fall: "{a} kehilangan rakyatnya",
		log_build: "{a} selesai membangun {what}",
		log_dawn: "Fajar menyingsing",
		log_storm: "Cuaca berubah",
		log_dragon: "Naga menghembuskan api",
		log_meteor: "Meteorit menghantam pulau",
		log_wipe: "{a} runtuh"
	},
	en: {
		kicker: "Living world",
		title: "Singgasana",
		lede: "Be a god on this island. Peoples build, farm, fight, and have children on their own. Temples, markets, tigers, and random omens now stir the world.",
		start: "Mulai",
		reroll: "New island",
		saved: "Saved",
		settings: "Settings",
		help: "How to play",
		back: "Back",
		pause: "Pause",
		resume: "Resume",
		menu: "Island menu",
		save: "Save world",
		savedOk: "World saved on this device",
		emptySaves: "No saved worlds yet.",
		load: "Load",
		delete: "Delete",
		name: "Island name",
		size: "Size",
		small: "Small",
		medium: "Medium",
		large: "Large",
		lang: "Language",
		graphics: "Graphics",
		audio: "Audio",
		shadows: "Shadows",
		resolution: "Sharpness",
		vegetation: "Plants",
		view: "View distance",
		fps: "Show FPS",
		perf: "Performance numbers",
		master: "Master",
		music: "Music",
		sfx: "Effects",
		mute: "Mute",
		off: "Off",
		low: "Low",
		high: "HD",
		ultra: "Ultra",
		preset: "Preset",
		brush: "Brush",
		brush1: "One",
		brush5: "Five",
		kingdoms: "Kingdoms",
		noKingdom: "No kingdoms yet. Place a people.",
		pop: "Souls",
		food: "Food",
		wood: "Wood",
		stone: "Stone",
		day: "Day",
		year: "Year",
		fpsLabel: "FPS",
		speed: "Time",
		focus: "Look",
		atWar: "War",
		peaceState: "Peace",
		boost: "Blessed",
		inspect: "Inspect",
		hp: "Health",
		hunger: "Hunger",
		close: "Close",
		helpBody: "Drag to pan. Pinch or scroll to zoom. A turns the view left, D turns it right, W and S move forward and back. Hold Space to pan while another tool is active. Tap to place. The finger selects a creature. They live on their own: chop, farm, build, sleep at night, and go to war.",
		keys: "WASD turn and move · space pan · tap to place",
		full: "This island is full",
		needLand: "Cannot place that here",
		needTwo: "Need two kingdoms",
		webgl: "3D graphics could not start in this browser.",
		season0: "Growth",
		season1: "Dry",
		season2: "Mist",
		season3: "Cold",
		weather_clear: "Clear",
		weather_cloudy: "Cloudy",
		weather_rain: "Rain",
		weather_storm: "Storm",
		weather_blood: "Blood rain",
		cat_bangsa: "People",
		cat_satwa: "Beasts",
		cat_alam: "Land",
		cat_kota: "Town",
		cat_bencana: "Disaster",
		cat_kuasa: "Powers",
		state_wander: "Wandering",
		state_chop: "Chopping",
		state_mine: "Mining",
		state_farm: "Farming",
		state_build: "Building",
		state_fight: "Fighting",
		state_sleep: "Sleeping",
		state_flee: "Fleeing",
		state_eat: "Eating",
		state_dead: "Fallen",
		role_villager: "Villager",
		role_warrior: "Warrior",
		role_king: "King",
		role_baby: "Child",
		role_beast: "Beast",
		race_human: "Human",
		race_elf: "Elf",
		race_orc: "Orc",
		race_dwarf: "Dwarf",
		tool_finger: "Finger",
		tool_erase: "Erase",
		tool_human: "Human",
		tool_elf: "Elf",
		tool_orc: "Orc",
		tool_dwarf: "Dwarf",
		tool_warrior: "Warrior",
		tool_king: "King",
		tool_chicken: "Chicken",
		tool_sheep: "Sheep",
		tool_cow: "Cow",
		tool_deer: "Deer",
		tool_wolf: "Wolf",
		tool_bear: "Bear",
		tool_tiger: "Tiger",
		tool_dragon: "Dragon",
		tool_tree: "Tree",
		tool_pine: "Pine",
		tool_palm: "Palm",
		tool_rock: "Rock",
		tool_bush: "Bush",
		tool_flower: "Flower",
		tool_house: "House",
		tool_farm: "Farm",
		tool_tower: "Tower",
		tool_castle: "Castle",
		tool_shrine: "Temple",
		tool_market: "Market",
		tool_wall: "Wall",
		tool_boat: "Boat",
		tool_firepit: "Campfire",
		tool_grass: "Grass",
		tool_sand: "Sand",
		tool_forest: "Forest",
		tool_snow: "Snow",
		tool_swamp: "Swamp",
		tool_road: "Road",
		tool_lava: "Lava",
		tool_lightning: "Lightning",
		tool_meteor: "Meteor",
		tool_fire: "Fire",
		tool_rain: "Rain",
		tool_blood: "Blood rain",
		tool_quake: "Quake",
		tool_tornado: "Tornado",
		tool_tsunami: "Tsunami",
		tool_plague: "Plague",
		tool_freeze: "Freeze",
		tool_heal: "Heal",
		tool_bless: "Bless",
		tool_peace: "Peace",
		tool_warhorn: "War horn",
		hint_finger: "Tap a creature or building to inspect it. Drag to pan.",
		hint_erase: "Remove creatures, trees, and buildings around the tap.",
		hint_human: "Place a villager. A new kingdom appears if they are far from home.",
		hint_warrior: "Warriors guard, hunt beasts, and fight enemies.",
		hint_king: "A king leads a kingdom. One king to a throne.",
		hint_dragon: "Dragons fly, roar, and breathe fire.",
		hint_tiger: "Tigers hunt deer, livestock, and careless people.",
		hint_shrine: "A temple speeds births and lights a sacred flame.",
		hint_market: "A market slowly grows the kingdom's food.",
		hint_lightning: "Call a bolt. It damages and starts fires.",
		hint_meteor: "Drop a sky stone. Crater, fire, and shake.",
		hint_rain: "Rain puts fires out.",
		hint_blood: "Red rain hurts everything alive.",
		hint_quake: "Shake the ground and whoever stands on it.",
		hint_tornado: "A vortex pulls and throws creatures.",
		hint_tsunami: "The sea rises and swallows the shore.",
		hint_plague: "Sickness spreads between neighbors.",
		hint_freeze: "Stop movement inside the circle.",
		hint_heal: "Restore health and cure plague.",
		hint_bless: "The nearest kingdom works faster and gains supplies.",
		hint_peace: "End the war between the two nearest kingdoms.",
		hint_warhorn: "Force the two nearest kingdoms to war.",
		hint_house: "Houses give sleep and room for children.",
		hint_farm: "Farms slowly grow food.",
		hint_tower: "Towers shoot enemies that come close.",
		hint_castle: "A castle becomes the throne.",
		hint_boat: "Boats can only sit on water.",
		hint_lava: "Lava burns anyone who steps on it.",
		event_festival: "Harvest feast — the nearest kingdom gains supplies",
		event_eclipse: "An eclipse dims the sky",
		event_bounty: "A herd of deer appears",
		event_pilgrim: "A pilgrim joins a kingdom",
		event_drought: "Drought cuts into the food stores",
		event_aurora: "A northern light heals the living",
		apk: "Download Android APK",
		apkNote: "Install the file and allow unknown sources. The world is saved on the phone, offline.",
		goals: "God's marks",
		goal_pop: "Forty souls live on the island",
		goal_kings: "Two kingdoms stand at once",
		goal_war: "War breaks between thrones",
		goal_storm: "A storm or blood rain sweeps the island",
		goal_year: "The island passes its second year",
		medal: "New mark",
		log_war: "{a} declares war on {b}",
		log_peace: "{a} makes peace with {b}",
		log_born: "A child is born in {a}",
		log_fall: "{a} has lost its people",
		log_build: "{a} finished a {what}",
		log_dawn: "Dawn breaks",
		log_storm: "The weather turns",
		log_dragon: "A dragon breathes fire",
		log_meteor: "A meteor hits the island",
		log_wipe: "{a} has fallen"
	}
};
function tr(lang, key) {
	return tables[lang][key] ?? tables.id[key] ?? key;
}
function toolLabel(lang, tool) {
	return tr(lang, `tool_${tool}`);
}
function catLabel(lang, cat) {
	return tr(lang, `cat_${cat}`);
}
function toolHint(lang, tool) {
	const specific = tables[lang][`hint_${tool}`] ?? tables.id[`hint_${tool}`];
	if (specific) return specific;
	return toolLabel(lang, tool);
}
function formatLog(lang, item) {
	const what = item.what ? tr(lang, `tool_${item.what}`) : "";
	return tr(lang, `log_${item.t}`).replace("{a}", item.a ?? "").replace("{b}", item.b ?? "").replace("{what}", what);
}
var ICONS = {
	finger: MousePointer2,
	erase: Eraser,
	human: Users,
	elf: Sprout,
	orc: Axe,
	dwarf: Axe,
	warrior: Swords,
	king: Crown,
	chicken: Bird,
	sheep: Rabbit,
	cow: PawPrint,
	deer: PawPrint,
	wolf: PawPrint,
	bear: PawPrint,
	tiger: Cat,
	dragon: Flame,
	tree: Trees,
	pine: TreePine,
	palm: TreePine,
	rock: Mountain,
	bush: Trees,
	flower: Flower2,
	house: House,
	farm: Wheat,
	tower: Castle,
	castle: Castle,
	shrine: Landmark,
	market: Store,
	wall: Fence,
	boat: Ship,
	firepit: Flame,
	grass: Sprout,
	sand: SunMedium,
	forest: Trees,
	snow: Snowflake,
	swamp: Droplets,
	road: Fence,
	lava: Flame,
	lightning: CloudLightning,
	meteor: Bomb,
	fire: Flame,
	rain: CloudRain,
	blood: Droplets,
	quake: Mountain,
	tornado: Wind,
	tsunami: Waves,
	plague: Skull,
	freeze: Snowflake,
	heal: HeartPulse,
	bless: SunMedium,
	peace: Shield,
	warhorn: Swords
};
function clock(hours) {
	const h = Math.floor(hours) % 24;
	const m = Math.floor((hours - Math.floor(hours)) * 60);
	return `${String(h).padStart(2, "0")}:${String(m).padStart(2, "0")}`;
}
var GOALS = [
	{
		id: "pop40",
		key: "goal_pop",
		test: (s) => s.pop >= 40
	},
	{
		id: "two",
		key: "goal_kings",
		test: (s) => s.kingdoms.length >= 2
	},
	{
		id: "war",
		key: "goal_war",
		test: (s) => s.log.some((item) => item.t === "war")
	},
	{
		id: "storm",
		key: "goal_storm",
		test: (s) => s.weather === "storm" || s.weather === "blood"
	},
	{
		id: "year",
		key: "goal_year",
		test: (s) => s.year >= 2
	}
];
var GOAL_KEY = "singgasana-goals-v1";
function readGoals() {
	try {
		const raw = localStorage.getItem(GOAL_KEY);
		const list = raw ? JSON.parse(raw) : [];
		return new Set(Array.isArray(list) ? list : []);
	} catch {
		return /* @__PURE__ */ new Set();
	}
}
function ThroneApp() {
	const canvasRef = (0, import_react.useRef)(null);
	const miniRef = (0, import_react.useRef)(null);
	const engineRef = (0, import_react.useRef)(null);
	const [snap, setSnap] = (0, import_react.useState)(null);
	const [panel, setPanel] = (0, import_react.useState)("none");
	const [kingsOpen, setKingsOpen] = (0, import_react.useState)(false);
	const [name, setName] = (0, import_react.useState)("Pulau Fajar");
	const [size, setSize] = (0, import_react.useState)("medium");
	const [goals, setGoals] = (0, import_react.useState)(() => /* @__PURE__ */ new Set());
	const [medal, setMedal] = (0, import_react.useState)(null);
	(0, import_react.useEffect)(() => {
		setGoals(readGoals());
	}, []);
	(0, import_react.useEffect)(() => {
		if (!snap || snap.phase !== "play") return;
		const have = readGoals();
		let fresh = null;
		for (const goal of GOALS) if (!have.has(goal.id) && goal.test(snap)) {
			have.add(goal.id);
			fresh = goal.key;
		}
		if (!fresh) return;
		localStorage.setItem(GOAL_KEY, JSON.stringify([...have]));
		setGoals(new Set(have));
		setMedal(fresh);
		const timer = window.setTimeout(() => setMedal(null), 3200);
		return () => window.clearTimeout(timer);
	}, [snap]);
	(0, import_react.useEffect)(() => {
		const canvas = canvasRef.current;
		if (!canvas) return;
		const engine = new IslandEngine(canvas, setSnap);
		engineRef.current = engine;
		engine.attachMinimap(miniRef.current);
		engine.start();
		const scoped = window;
		scoped.__singgasana = engine;
		return () => {
			engine.dispose();
			if (scoped.__singgasana === engine) delete scoped.__singgasana;
		};
	}, []);
	const lang = snap?.settings.lang ?? "id";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "app",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("canvas", {
				ref: canvasRef,
				className: "world-canvas"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "vignette" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("canvas", {
				ref: miniRef,
				className: "minimap",
				width: 160,
				height: 160,
				onClick: (e) => {
					const rect = e.currentTarget.getBoundingClientRect();
					engineRef.current?.focusNorm((e.clientX - rect.left) / rect.width, (e.clientY - rect.top) / rect.height);
				}
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "hud",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
						className: "topbar",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "brand",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "brand-kicker",
									children: tr(lang, "kicker")
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", { children: snap?.worldName || tr(lang, "title") })]
							}),
							snap && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "top-stats",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
										tr(lang, "day"),
										" ",
										snap.day
									] }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "num",
										children: clock(snap.hour)
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: tr(lang, `season${snap.season}`) }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: tr(lang, `weather_${snap.weather}`) }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
										tr(lang, "pop"),
										" ",
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", {
											className: "num",
											children: snap.pop
										})
									] })
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "top-actions",
								children: [snap?.settings.graphics.showFps !== false && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: `fps fps-${(snap?.fps ?? 0) >= 50 ? "good" : (snap?.fps ?? 0) >= 30 ? "ok" : "bad"}`,
									title: snap?.settings.graphics.showPerf ? `${snap.frameMs.toFixed(1)} ms · ${snap.draws} draw` : "FPS",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "num",
										children: snap?.fps ?? 0
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("small", { children: ["FPS", snap?.shadows === "high" ? " HD" : ""] })]
								}), snap?.phase === "play" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "speeds",
										role: "group",
										"aria-label": tr(lang, "speed"),
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
												type: "button",
												className: snap.paused ? "on" : "",
												onClick: () => engineRef.current?.setSpeed(0),
												children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pause, { size: 16 })
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
												type: "button",
												className: !snap.paused && snap.speed === 1 ? "on" : "",
												onClick: () => engineRef.current?.setSpeed(1),
												children: "1×"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
												type: "button",
												className: snap.speed === 3 ? "on" : "",
												onClick: () => engineRef.current?.setSpeed(3),
												children: "3×"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
												type: "button",
												className: snap.speed === 8 ? "on" : "",
												onClick: () => engineRef.current?.setSpeed(8),
												children: "8×"
											})
										]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										type: "button",
										className: "icon-btn",
										onClick: () => setKingsOpen((v) => !v),
										children: tr(lang, "kingdoms")
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										type: "button",
										className: "icon-btn",
										onClick: () => setPanel("pause"),
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Settings, { size: 16 })
									})
								] })]
							})
						]
					}),
					snap?.phase === "menu" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "menu-wrap",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
							className: "panel menu-card",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "eyebrow",
									children: tr(lang, "kicker")
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", { children: tr(lang, "title") }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "lede",
									children: tr(lang, "lede")
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
									className: "field",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: tr(lang, "name") }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
										value: name,
										maxLength: 32,
										onChange: (e) => setName(e.target.value)
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "choice",
									children: [
										"small",
										"medium",
										"large"
									].map((id) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										type: "button",
										className: size === id ? "on" : "",
										onClick: () => setSize(id),
										children: tr(lang, id)
									}, id))
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "menu-actions",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
											type: "button",
											className: "primary",
											onClick: () => engineRef.current?.enter(),
											children: tr(lang, "start")
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
											type: "button",
											onClick: () => engineRef.current?.reroll({
												name: name.trim() || "Pulau Fajar",
												size,
												seed: Math.random() * 1e9 >>> 0
											}, false),
											children: tr(lang, "reroll")
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
											type: "button",
											onClick: () => setPanel("saves"),
											children: tr(lang, "saved")
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
											type: "button",
											onClick: () => setPanel("settings"),
											children: tr(lang, "settings")
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
											type: "button",
											onClick: () => setPanel("help"),
											children: tr(lang, "help")
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
											className: "apk",
											href: "/singgasana.apk",
											download: "Singgasana.apk",
											children: tr(lang, "apk")
										})
									]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "fine",
									children: tr(lang, "apkNote")
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "fine",
									children: tr(lang, "keys")
								})
							]
						})
					}),
					snap?.phase === "play" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("aside", {
						className: `kings ${kingsOpen ? "open" : ""}`,
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "panel kings-card",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", { children: tr(lang, "kingdoms") }),
								snap.kingdoms.length === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "fine",
									children: tr(lang, "noKingdom")
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", { children: snap.kingdoms.map((k) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
										type: "button",
										className: "king",
										onClick: () => engineRef.current?.focusKingdom(k.id),
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("i", { style: { background: k.color } }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: k.name }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("em", { children: [
											tr(lang, `race_${k.race}`),
											" · ",
											k.pop,
											" ",
											tr(lang, "pop")
										] })] })]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
										className: "res num",
										children: [
											k.food,
											" ",
											tr(lang, "food"),
											" · ",
											k.wood,
											" ",
											tr(lang, "wood"),
											" · ",
											k.stone,
											" ",
											tr(lang, "stone")
										]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
										className: "fine",
										children: [k.wars.length ? `${tr(lang, "atWar")}: ${k.wars.join(", ")}` : tr(lang, "peaceState"), k.boost ? ` · ${tr(lang, "boost")}` : ""]
									})
								] }, k.id)) }),
								snap.log.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ol", {
									className: "log",
									children: snap.log.slice(0, 4).map((item, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: formatLog(lang, item) }, `${item.t}-${i}`))
								})
							]
						})
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "dock",
						children: [snap.inspect && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
							className: "panel inspect",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "eyebrow",
									children: tr(lang, "inspect")
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", { children: inspectName(lang, snap.inspect.kind, snap.inspect.title, snap.inspect.subtitle) })] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									onClick: () => engineRef.current?.clearInspect(),
									children: tr(lang, "close")
								})] }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "fine",
									children: [inspectSub(lang, snap.inspect.kind, snap.inspect.subtitle), snap.inspect.kingdom ? ` · ${snap.inspect.kingdom}` : ""]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "bar",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { style: { width: `${Math.max(0, Math.min(100, snap.inspect.hp / snap.inspect.maxHp * 100))}%` } })
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "fine",
									children: [
										tr(lang, "hp"),
										" ",
										Math.ceil(snap.inspect.hp),
										"/",
										snap.inspect.maxHp,
										" · ",
										tr(lang, `state_${snap.inspect.state}`),
										snap.inspect.hunger != null ? ` · ${tr(lang, "hunger")} ${Math.round(snap.inspect.hunger * 100)}%` : ""
									]
								})
							]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "panel tool-dock",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "cats",
									children: CATS.map((c) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										type: "button",
										className: snap.cat === c.id ? "on" : "",
										onClick: () => engineRef.current?.setCat(c.id),
										children: catLabel(lang, c.id)
									}, c.id))
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "tools",
									children: CATS.find((c) => c.id === snap.cat)?.tools.map((tool) => {
										const Icon = ICONS[tool];
										return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
											type: "button",
											className: snap.tool === tool ? "tool on" : "tool",
											onClick: () => engineRef.current?.setTool(tool),
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { size: 18 }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: toolLabel(lang, tool) })]
										}, tool);
									})
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "tool-meta",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: toolHint(lang, snap.tool) }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "choice slim",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: tr(lang, "brush") }),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
												type: "button",
												className: snap.brush === 1 ? "on" : "",
												onClick: () => engineRef.current?.setBrush(1),
												children: tr(lang, "brush1")
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
												type: "button",
												className: snap.brush === 5 ? "on" : "",
												onClick: () => engineRef.current?.setBrush(5),
												children: tr(lang, "brush5")
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
												type: "button",
												className: "icon-btn",
												onClick: () => engineRef.current?.nudgeZoom(-1),
												children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Minus, { size: 16 })
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
												type: "button",
												className: "icon-btn",
												onClick: () => engineRef.current?.nudgeZoom(1),
												children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { size: 16 })
											})
										]
									})]
								})
							]
						})]
					})] }),
					snap?.toast && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "toast",
						children: tr(lang, snap.toast)
					}),
					medal && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "toast medal",
						children: [
							tr(lang, "medal"),
							": ",
							tr(lang, medal)
						]
					}),
					snap?.webgl && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "toast",
						children: tr(lang, "webgl")
					}),
					panel !== "none" && snap && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "modal-back",
						onClick: () => setPanel("none"),
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
							className: "panel modal",
							onClick: (e) => e.stopPropagation(),
							children: [
								panel === "pause" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", { children: tr(lang, "pause") }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "menu-actions",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
												type: "button",
												className: "primary",
												onClick: () => {
													engineRef.current?.togglePause();
													setPanel("none");
												},
												children: [
													snap.paused ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Play, { size: 16 }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pause, { size: 16 }),
													" ",
													snap.paused ? tr(lang, "resume") : tr(lang, "pause")
												]
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
												type: "button",
												onClick: () => engineRef.current?.save(),
												children: [
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Save, { size: 16 }),
													" ",
													tr(lang, "save")
												]
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
												type: "button",
												onClick: () => setPanel("settings"),
												children: [
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Settings, { size: 16 }),
													" ",
													tr(lang, "settings")
												]
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
												type: "button",
												onClick: () => setPanel("help"),
												children: tr(lang, "help")
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
												type: "button",
												onClick: () => {
													engineRef.current?.goMenu();
													setPanel("none");
												},
												children: tr(lang, "menu")
											})
										]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
										className: "fine num",
										children: [
											tr(lang, "year"),
											" ",
											snap.year,
											" · ",
											snap.births,
											" / ",
											snap.deaths
										]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", { children: tr(lang, "goals") }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
										className: "goals",
										children: GOALS.map((goal) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
											className: goals.has(goal.id) ? "done" : "",
											children: tr(lang, goal.key)
										}, goal.id))
									})
								] }),
								panel === "settings" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SettingsPanel, { snap }),
								panel === "help" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", { children: tr(lang, "help") }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "lede",
										children: tr(lang, "helpBody")
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										type: "button",
										className: "primary",
										onClick: () => setPanel("none"),
										children: tr(lang, "back")
									})
								] }),
								panel === "saves" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", { children: tr(lang, "saved") }),
									snap.saves.length === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "fine",
										children: tr(lang, "emptySaves")
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
										className: "saves",
										children: snap.saves.map((w) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: w.name }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
												className: "fine",
												children: [
													tr(lang, "day"),
													" ",
													w.day,
													" · ",
													w.pop,
													" ",
													tr(lang, "pop")
												]
											})] }),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
												type: "button",
												onClick: () => {
													engineRef.current?.load(w.id);
													setPanel("none");
												},
												children: tr(lang, "load")
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
												type: "button",
												onClick: () => engineRef.current?.remove(w.id),
												children: tr(lang, "delete")
											})
										] }, w.id))
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										type: "button",
										onClick: () => setPanel("none"),
										children: tr(lang, "back")
									})
								] })
							]
						})
					})
				]
			})
		]
	});
}
function inspectName(lang, kind, title, subtitle) {
	if (kind === "building") return tr(lang, `tool_${title}`);
	if (!subtitle.includes(":")) return tr(lang, `tool_${title}`);
	return title;
}
function inspectSub(lang, kind, subtitle) {
	if (kind === "building") return tr(lang, `tool_${subtitle}`);
	if (!subtitle.includes(":")) return tr(lang, "role_beast");
	const [role, race] = subtitle.split(":");
	return `${tr(lang, `role_${role}`)} · ${tr(lang, `race_${race}`)}`;
}
function SettingsPanel({ snap }) {
	const lang = snap.settings.lang;
	const g = snap.settings.graphics;
	const a = snap.settings.audio;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", { children: tr(lang, "settings") }),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "choice",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				className: lang === "id" ? "on" : "",
				onClick: () => active()?.setLang("id"),
				children: "Indonesia"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				className: lang === "en" ? "on" : "",
				onClick: () => active()?.setLang("en"),
				children: "English"
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", { children: tr(lang, "graphics") }),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "choice",
			children: [
				"low",
				"medium",
				"high",
				"ultra"
			].map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				className: g.preset === p ? "on" : "",
				onClick: () => active()?.setGraphics({ preset: p }, true),
				children: tr(lang, p === "high" ? "high" : p)
			}, p))
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
			className: "field",
			children: [tr(lang, "shadows"), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "choice",
				children: [
					"off",
					"low",
					"medium",
					"high"
				].map((s) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: g.shadows === s ? "on" : "",
					onClick: () => active()?.setGraphics({ shadows: s }),
					children: tr(lang, s === "off" ? "off" : s === "low" ? "low" : s === "medium" ? "medium" : "high")
				}, s))
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Slider, {
			label: tr(lang, "resolution"),
			value: g.resolution,
			min: 50,
			max: 100,
			onChange: (resolution) => active()?.setGraphics({ resolution })
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Slider, {
			label: tr(lang, "vegetation"),
			value: g.vegetation,
			min: 20,
			max: 100,
			onChange: (vegetation) => active()?.setGraphics({ vegetation })
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Slider, {
			label: tr(lang, "view"),
			value: g.viewDistance,
			min: 70,
			max: 180,
			onChange: (viewDistance) => active()?.setGraphics({ viewDistance })
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Toggle, {
			label: tr(lang, "fps"),
			checked: g.showFps,
			onChange: (showFps) => active()?.setGraphics({ showFps })
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Toggle, {
			label: tr(lang, "perf"),
			checked: g.showPerf,
			onChange: (showPerf) => active()?.setGraphics({ showPerf })
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h3", { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Volume2, { size: 16 }),
			" ",
			tr(lang, "audio")
		] }),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Slider, {
			label: tr(lang, "master"),
			value: a.master,
			min: 0,
			max: 100,
			onChange: (master) => active()?.setAudio({ master })
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Slider, {
			label: tr(lang, "music"),
			value: a.music,
			min: 0,
			max: 100,
			onChange: (music) => active()?.setAudio({ music })
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Slider, {
			label: tr(lang, "sfx"),
			value: a.sfx,
			min: 0,
			max: 100,
			onChange: (sfx) => active()?.setAudio({ sfx })
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Toggle, {
			label: tr(lang, "mute"),
			checked: a.mute,
			onChange: (mute) => active()?.setAudio({ mute })
		})
	] });
}
function active() {
	return window.__singgasana ?? null;
}
function Slider({ label, value, min, max, onChange }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
		className: "field",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
			label,
			" ",
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", {
				className: "num",
				children: Math.round(value)
			})
		] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
			type: "range",
			min,
			max,
			value,
			onChange: (e) => onChange(Number(e.target.value))
		})]
	});
}
function Toggle({ label, checked, onChange }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
		className: "toggle",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: label }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
			type: "checkbox",
			checked,
			onChange: (e) => onChange(e.target.checked)
		})]
	});
}
//#endregion
export { ThroneApp };

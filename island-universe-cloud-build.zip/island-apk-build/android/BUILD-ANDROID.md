# Android build troubleshooting

The original log (`Could not read message` / `Unexpected type tag 71 found`) points to Gradle daemon communication or stale Gradle state, not a JavaScript compiler error.

This project copy removes generated Gradle caches and disables parallel/configuration-cache features to make sandbox builds more conservative. Game source and existing Android wrapper assets are preserved.

From the Android project directory, run `gradle --stop` (if available), then `gradle assembleDebug --no-daemon --stacktrace`. If the environment has no `gradle` command, use the platform's configured Android build task. This archive does not include a prebuilt APK.

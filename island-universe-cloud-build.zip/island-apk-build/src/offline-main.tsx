import { createRoot } from "react-dom/client";
import { ThroneApp } from "@/components/throne-app";
import "@/styles.css";

const root = document.getElementById("root");
if (root) createRoot(root).render(<ThroneApp />);

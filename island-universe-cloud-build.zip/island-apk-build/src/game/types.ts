export const GAME_VERSION = "3.0.0";

export type Lang = "id" | "en";
export type SizeId = "small" | "medium" | "large";
export type ShadowQ = "off" | "low" | "medium" | "high";
export type GraphicsPreset = "low" | "medium" | "high" | "ultra";
export type Weather = "clear" | "cloudy" | "rain" | "storm" | "blood";
export type Race = "human" | "elf" | "orc" | "dwarf";
export type AnimalKind = "chicken" | "sheep" | "cow" | "deer" | "wolf" | "bear" | "tiger" | "dragon";
export type Role = "villager" | "warrior" | "king" | "baby" | "beast";
export type Intent =
  | "wander"
  | "chop"
  | "mine"
  | "farm"
  | "build"
  | "fight"
  | "sleep"
  | "flee"
  | "eat";
export type BuildType = "house" | "farm" | "tower" | "castle" | "shrine" | "market" | "wall" | "boat" | "firepit";
export type TreeKind = "oak" | "pine" | "palm";
export type PropKind = "bush" | "flower";
export type Tool =
  | "finger"
  | "erase"
  | "human"
  | "elf"
  | "orc"
  | "dwarf"
  | "warrior"
  | "king"
  | "chicken"
  | "sheep"
  | "cow"
  | "deer"
  | "wolf"
  | "bear"
  | "tiger"
  | "dragon"
  | "tree"
  | "pine"
  | "palm"
  | "rock"
  | "bush"
  | "flower"
  | "house"
  | "farm"
  | "tower"
  | "castle"
  | "shrine"
  | "market"
  | "wall"
  | "boat"
  | "firepit"
  | "grass"
  | "sand"
  | "forest"
  | "snow"
  | "swamp"
  | "road"
  | "lava"
  | "lightning"
  | "meteor"
  | "fire"
  | "rain"
  | "blood"
  | "quake"
  | "tornado"
  | "tsunami"
  | "plague"
  | "freeze"
  | "heal"
  | "bless"
  | "peace"
  | "warhorn";

export type Category = "bangsa" | "satwa" | "alam" | "kota" | "bencana" | "kuasa";

export type SoundId =
  | "ui_tap"
  | "ui_open"
  | "ui_close"
  | "ui_error"
  | "ui_save"
  | "select"
  | "place_human"
  | "place_elf"
  | "place_orc"
  | "place_dwarf"
  | "place_warrior"
  | "place_king"
  | "place_baby"
  | "place_house"
  | "place_farm"
  | "place_tower"
  | "place_castle"
  | "place_wall"
  | "place_boat"
  | "place_fire"
  | "place_tree"
  | "place_rock"
  | "place_bush"
  | "place_flower"
  | "chop"
  | "mine"
  | "hammer"
  | "build_done"
  | "eat"
  | "sword"
  | "bite"
  | "bow"
  | "hurt"
  | "death"
  | "death_beast"
  | "birth"
  | "chicken"
  | "sheep"
  | "cow"
  | "deer"
  | "wolf"
  | "bear"
  | "dragon"
  | "dragon_fire"
  | "lightning"
  | "meteor"
  | "fire"
  | "rain"
  | "blood"
  | "quake"
  | "tornado"
  | "tsunami"
  | "plague"
  | "freeze"
  | "heal"
  | "bless"
  | "erase"
  | "war"
  | "peace"
  | "splash"
  | "dawn"
  | "night"
  | "tower"
  | "lava"
  | "foot"
  | "foot_heavy"
  | "foot_hoof"
  | "foot_paw"
  | "roar";

export interface GraphicsSettings {
  preset: GraphicsPreset;
  resolution: number;
  shadows: ShadowQ;
  vegetation: number;
  viewDistance: number;
  showFps: boolean;
  showPerf: boolean;
}

export interface AudioSettings {
  master: number;
  music: number;
  sfx: number;
  mute: boolean;
}

export interface Settings {
  version: 1;
  lang: Lang;
  graphics: GraphicsSettings;
  audio: AudioSettings;
}

export interface WorldOptions {
  name: string;
  size: SizeId;
  seed: number;
}

export interface LogItem {
  t: "war" | "peace" | "born" | "fall" | "build" | "dawn" | "storm" | "dragon" | "meteor" | "wipe";
  a?: string;
  b?: string;
  what?: string;
}

export interface Inspect {
  id: number;
  kind: "unit" | "building";
  title: string;
  subtitle: string;
  hp: number;
  maxHp: number;
  hunger: number | null;
  state: string;
  kingdom: string | null;
  color: string | null;
}

export interface KingdomView {
  id: number;
  race: Race;
  name: string;
  color: string;
  pop: number;
  food: number;
  wood: number;
  stone: number;
  wars: string[];
  boost: boolean;
}

export interface WorldMeta {
  id: string;
  name: string;
  savedAt: number;
  size: SizeId;
  day: number;
  pop: number;
}

export interface Fx {
  kind: "lightning" | "meteor" | "bolt" | "heal" | "boom" | "splash";
  x: number;
  y: number;
  z: number;
  x2?: number;
  y2?: number;
  z2?: number;
  life: number;
  max: number;
}

export interface SfxEvent {
  id: SoundId;
  x: number;
  z: number;
}

export const SIZE_SPAN: Record<SizeId, number> = {
  small: 48,
  medium: 72,
  large: 96,
};

export const CATS: { id: Category; tools: Tool[] }[] = [
  { id: "bangsa", tools: ["human", "elf", "orc", "dwarf", "warrior", "king"] },
  { id: "satwa", tools: ["chicken", "sheep", "cow", "deer", "wolf", "bear", "tiger", "dragon"] },
  { id: "alam", tools: ["tree", "pine", "palm", "rock", "bush", "flower", "grass", "sand", "forest", "snow", "swamp", "road", "lava"] },
  { id: "kota", tools: ["house", "farm", "tower", "castle", "shrine", "market", "wall", "boat", "firepit"] },
  { id: "bencana", tools: ["lightning", "meteor", "fire", "rain", "blood", "quake", "tornado", "tsunami", "plague"] },
  { id: "kuasa", tools: ["finger", "heal", "bless", "freeze", "peace", "warhorn", "erase"] },
];

export const RACE_OF_TOOL: Partial<Record<Tool, Race>> = {
  human: "human",
  elf: "elf",
  orc: "orc",
  dwarf: "dwarf",
};

export function clamp(v: number, a: number, b: number): number {
  return Math.max(a, Math.min(b, v));
}

export function applyPreset(preset: GraphicsPreset): GraphicsSettings {
  if (preset === "low") {
    return { preset, resolution: 70, shadows: "low", vegetation: 55, viewDistance: 90, showFps: true, showPerf: false };
  }
  if (preset === "medium") {
    return { preset, resolution: 85, shadows: "medium", vegetation: 80, viewDistance: 120, showFps: true, showPerf: false };
  }
  if (preset === "ultra") {
    return { preset, resolution: 100, shadows: "high", vegetation: 100, viewDistance: 170, showFps: true, showPerf: false };
  }
  return { preset: "high", resolution: 100, shadows: "high", vegetation: 100, viewDistance: 145, showFps: true, showPerf: false };
}

export function defaultSettings(): Settings {
  return {
    version: 1,
    lang: "id",
    graphics: applyPreset("high"),
    audio: { master: 80, music: 55, sfx: 85, mute: false },
  };
}

import * as THREE from "three";

interface Part {
  geo: THREE.BufferGeometry;
  x: number;
  y: number;
  z: number;
  rx?: number;
  ry?: number;
  rz?: number;
  sx?: number;
  sy?: number;
  sz?: number;
  color: number;
  limb: number;
}

const cache = new Map<string, THREE.BufferGeometry>();

function geo(key: string, make: () => THREE.BufferGeometry): THREE.BufferGeometry {
  let g = cache.get(key);
  if (!g) {
    g = make();
    cache.set(key, g);
  }
  return g;
}

function capsule(r: number, len: number): THREE.BufferGeometry {
  return geo(`cap-${r}-${len}`, () => new THREE.CapsuleGeometry(r, len, 4, 8));
}

function sphere(r: number): THREE.BufferGeometry {
  return geo(`sph-${r}`, () => new THREE.SphereGeometry(r, 10, 8));
}

function box(w: number, h: number, d: number): THREE.BufferGeometry {
  return geo(`box-${w}-${h}-${d}`, () => new THREE.BoxGeometry(w, h, d));
}

function cyl(rt: number, rb: number, h: number, s = 8): THREE.BufferGeometry {
  return geo(`cyl-${rt}-${rb}-${h}-${s}`, () => new THREE.CylinderGeometry(rt, rb, h, s));
}

function cone(r: number, h: number, s = 8): THREE.BufferGeometry {
  return geo(`cone-${r}-${h}-${s}`, () => new THREE.ConeGeometry(r, h, s));
}

function bake(parts: Part[], sx = 1, sy = 1, sz = 1): THREE.BufferGeometry {
  const positions: number[] = [];
  const normals: number[] = [];
  const colors: number[] = [];
  const v = new THREE.Vector3();
  const nrm = new THREE.Vector3();
  const color = new THREE.Color();
  for (const part of parts) {
    const source = part.geo.index ? part.geo.toNonIndexed() : part.geo;
    const pos = source.attributes.position;
    const nor = source.attributes.normal;
    if (!pos || !nor) continue;
    const m = new THREE.Matrix4().compose(
      new THREE.Vector3(part.x, part.y, part.z),
      new THREE.Quaternion().setFromEuler(new THREE.Euler(part.rx ?? 0, part.ry ?? 0, part.rz ?? 0)),
      new THREE.Vector3(part.sx ?? 1, part.sy ?? 1, part.sz ?? 1),
    );
    const nm = new THREE.Matrix3().getNormalMatrix(m);
    color.set(part.color);
    for (let i = 0; i < pos.count; i++) {
      v.fromBufferAttribute(pos as THREE.BufferAttribute, i).applyMatrix4(m);
      nrm.fromBufferAttribute(nor as THREE.BufferAttribute, i).applyMatrix3(nm).normalize();
      positions.push(v.x * sx, v.y * sy, v.z * sz);
      normals.push(nrm.x, nrm.y, nrm.z);
      colors.push(color.r, color.g, color.b);
    }
  }
  const out = new THREE.BufferGeometry();
  out.setAttribute("position", new THREE.Float32BufferAttribute(positions, 3));
  out.setAttribute("normal", new THREE.Float32BufferAttribute(normals, 3));
  out.setAttribute("color", new THREE.Float32BufferAttribute(colors, 3));
  out.computeBoundingSphere();
  return out;
}

interface PersonOpts {
  skin: number;
  cloth: number;
  trim: number;
  hair: number;
  pants: number;
  boot: number;
  bulk: number;
  tall: number;
  hat: "none" | "cap" | "hood" | "helmet" | "crown";
  beard?: boolean;
  tusks?: boolean;
  ears?: boolean;
  sword?: boolean;
  shield?: boolean;
  cape?: boolean;
  baby?: boolean;
}

function person(o: PersonOpts): THREE.BufferGeometry {
  const skin = o.skin;
  const b = o.bulk;
  const headR = o.baby ? 0.2 : 0.155;
  const legR = 0.075 * b;
  const legLen = o.baby ? 0.22 : 0.4;
  const legY = legLen * 0.5 + legR;
  const hip = legY + legLen * 0.5 + legR * 0.2;
  const torsoR = (o.baby ? 0.16 : 0.175) * b;
  const torsoLen = o.baby ? 0.22 : 0.38;
  const torsoY = hip + torsoLen * 0.35;
  const shoulder = torsoY + torsoLen * 0.32;
  const headY = shoulder + headR * 0.85;
  const armX = torsoR + 0.08 * b;
  const parts: Part[] = [
    { geo: capsule(legR, legLen), x: -0.1 * b, y: legY, z: 0, color: o.pants, limb: 1 },
    { geo: capsule(legR, legLen), x: 0.1 * b, y: legY, z: 0, color: o.pants, limb: 2 },
    { geo: sphere(0.09 * b), x: -0.1 * b, y: 0.06, z: 0.03, color: o.boot, limb: 1, sx: 1.1, sz: 1.4 },
    { geo: sphere(0.09 * b), x: 0.1 * b, y: 0.06, z: 0.03, color: o.boot, limb: 2, sx: 1.1, sz: 1.4 },
    { geo: capsule(torsoR, torsoLen), x: 0, y: torsoY, z: 0, color: o.cloth, limb: 0, sz: 0.82 },
    { geo: box(torsoR * 1.7, 0.08, torsoR * 0.5), x: 0, y: shoulder - 0.02, z: 0, color: o.trim, limb: 0 },
    { geo: capsule(0.055 * b, 0.32), x: -armX, y: shoulder - 0.12, z: 0, color: o.cloth, limb: 3 },
    { geo: capsule(0.055 * b, 0.32), x: armX, y: shoulder - 0.12, z: 0, color: o.cloth, limb: 4 },
    { geo: sphere(0.055 * b), x: -armX, y: shoulder - 0.34, z: 0.02, color: skin, limb: 3 },
    { geo: sphere(0.055 * b), x: armX, y: shoulder - 0.34, z: 0.02, color: skin, limb: 4 },
    { geo: sphere(headR), x: 0, y: headY, z: 0, color: skin, limb: 0 },
    { geo: sphere(headR * 1.02), x: 0, y: headY + headR * 0.28, z: -0.02, color: o.hair, limb: 0, sy: 0.62 },
    { geo: sphere(0.028), x: -0.055, y: headY + 0.02, z: headR * 0.82, color: 0x1c1916, limb: 0 },
    { geo: sphere(0.028), x: 0.055, y: headY + 0.02, z: headR * 0.82, color: 0x1c1916, limb: 0 },
    { geo: sphere(0.03), x: 0, y: headY - 0.02, z: headR * 0.92, color: skin, limb: 0, sx: 0.8, sy: 0.7 },
    { geo: box(0.07, 0.012, 0.02), x: 0, y: headY - 0.07, z: headR * 0.86, color: 0x8a5348, limb: 0 },
  ];
  if (o.ears) {
    parts.push(
      { geo: cone(0.04, 0.12, 5), x: -headR * 0.95, y: headY, z: 0, rz: Math.PI / 2.2, color: skin, limb: 0 },
      { geo: cone(0.04, 0.12, 5), x: headR * 0.95, y: headY, z: 0, rz: -Math.PI / 2.2, color: skin, limb: 0 },
    );
  }
  if (o.tusks) {
    parts.push(
      { geo: cone(0.02, 0.09, 5), x: -0.05, y: headY - 0.08, z: headR * 0.75, rx: Math.PI / 2.4, color: 0xf3ead7, limb: 0 },
      { geo: cone(0.02, 0.09, 5), x: 0.05, y: headY - 0.08, z: headR * 0.75, rx: Math.PI / 2.4, color: 0xf3ead7, limb: 0 },
    );
  }
  if (o.beard) {
    parts.push({ geo: cone(0.11, 0.28, 7), x: 0, y: headY - 0.22, z: 0.04, color: o.hair, limb: 0 });
  }
  if (o.hat === "cap") {
    parts.push({ geo: cyl(headR * 1.05, headR * 1.05, 0.06, 10), x: 0, y: headY + headR * 0.72, z: 0, color: o.trim, limb: 0 });
  } else if (o.hat === "hood") {
    parts.push({ geo: sphere(headR * 1.12), x: 0, y: headY + 0.04, z: -0.02, color: o.trim, limb: 0, sy: 0.85 });
  } else if (o.hat === "helmet") {
    parts.push(
      { geo: sphere(headR * 1.08), x: 0, y: headY + 0.04, z: 0, color: 0x8d9398, limb: 0, sy: 0.72 },
      { geo: box(0.16, 0.06, 0.04), x: 0, y: headY + 0.02, z: headR, color: 0x6e7478, limb: 0 },
    );
  } else if (o.hat === "crown") {
    parts.push(
      { geo: cyl(headR * 0.85, headR * 0.9, 0.08, 8), x: 0, y: headY + headR * 0.85, z: 0, color: 0xd4a15a, limb: 0 },
      { geo: cone(0.04, 0.14, 5), x: -0.08, y: headY + headR * 1.05, z: 0, color: 0xd4a15a, limb: 0 },
      { geo: cone(0.04, 0.18, 5), x: 0, y: headY + headR * 1.1, z: 0, color: 0xd4a15a, limb: 0 },
      { geo: cone(0.04, 0.14, 5), x: 0.08, y: headY + headR * 1.05, z: 0, color: 0xd4a15a, limb: 0 },
    );
  }
  if (o.cape) {
    parts.push({ geo: box(0.34, 0.55, 0.04), x: 0, y: torsoY, z: -torsoR * 0.7, color: o.trim, limb: 0 });
  }
  if (o.shield) {
    parts.push({ geo: box(0.06, 0.36, 0.28), x: -armX - 0.06, y: shoulder - 0.28, z: 0.04, color: o.trim, limb: 3 });
  }
  if (o.sword) {
    parts.push(
      { geo: box(0.03, 0.46, 0.05), x: armX + 0.02, y: shoulder - 0.55, z: 0.08, color: 0xd9dde2, limb: 4 },
      { geo: box(0.1, 0.04, 0.06), x: armX + 0.02, y: shoulder - 0.32, z: 0.08, color: 0x6b4226, limb: 4 },
    );
  }
  const tall = o.baby ? 1.15 : 1.28 * o.tall;
  return bake(parts, tall, tall, tall);
}

function oak(): THREE.BufferGeometry {
  return bake([
    { geo: cyl(0.11, 0.16, 1.15, 7), x: 0, y: 0.58, z: 0, color: 0x6b4630, limb: 0 },
    { geo: sphere(0.62), x: 0, y: 1.55, z: 0, color: 0x3f7a3a, limb: 0 },
    { geo: sphere(0.48), x: 0.32, y: 1.35, z: 0.12, color: 0x4e8c45, limb: 0 },
    { geo: sphere(0.42), x: -0.28, y: 1.42, z: -0.1, color: 0x2f6834, limb: 0 },
    { geo: sphere(0.28), x: 0.05, y: 2.0, z: -0.05, color: 0x67a35a, limb: 0 },
  ]);
}

function pine(): THREE.BufferGeometry {
  return bake([
    { geo: cyl(0.08, 0.12, 0.7, 6), x: 0, y: 0.35, z: 0, color: 0x5c4030, limb: 0 },
    { geo: cone(0.7, 1.05, 8), x: 0, y: 1.05, z: 0, color: 0x1f5a3a, limb: 0 },
    { geo: cone(0.52, 0.9, 8), x: 0, y: 1.6, z: 0, color: 0x2a7050, limb: 0 },
    { geo: cone(0.32, 0.7, 7), x: 0, y: 2.1, z: 0, color: 0x34825c, limb: 0 },
  ]);
}

function palm(): THREE.BufferGeometry {
  const parts: Part[] = [
    { geo: cyl(0.07, 0.1, 0.45, 6), x: 0, y: 0.22, z: 0, color: 0x8a6244, limb: 0 },
    { geo: cyl(0.06, 0.08, 0.45, 6), x: 0.05, y: 0.62, z: 0, rz: -0.18, color: 0x9a704c, limb: 0 },
    { geo: cyl(0.055, 0.07, 0.4, 6), x: 0.12, y: 0.98, z: 0, rz: -0.28, color: 0xa67b52, limb: 0 },
  ];
  for (let i = 0; i < 6; i++) {
    const a = (i / 6) * Math.PI * 2;
    parts.push({
      geo: cone(0.08, 0.85, 4),
      x: 0.16 + Math.cos(a) * 0.15,
      y: 1.22,
      z: Math.sin(a) * 0.15,
      rx: 1.15,
      ry: a,
      color: i % 2 ? 0x2f8a48 : 0x3ea25a,
      limb: 0,
    });
  }
  parts.push({ geo: sphere(0.1), x: 0.16, y: 1.22, z: 0, color: 0x246b38, limb: 0 });
  return bake(parts);
}

function chicken(): THREE.BufferGeometry {
  return bake(
    [
      { geo: sphere(0.16), x: 0, y: 0.28, z: 0, color: 0xf4f1ea, limb: 0, sx: 1.25, sy: 0.9, sz: 1.05 },
      { geo: sphere(0.1), x: 0, y: 0.42, z: 0.14, color: 0xfffaf4, limb: 0 },
      { geo: cone(0.035, 0.1, 5), x: 0, y: 0.4, z: 0.24, rx: Math.PI / 2, color: 0xe2a23a, limb: 0 },
      { geo: sphere(0.045), x: 0, y: 0.5, z: 0.1, color: 0xc4493a, limb: 0 },
      { geo: sphere(0.018), x: -0.035, y: 0.45, z: 0.2, color: 0x1c1916, limb: 0 },
      { geo: sphere(0.018), x: 0.035, y: 0.45, z: 0.2, color: 0x1c1916, limb: 0 },
      { geo: sphere(0.08), x: -0.12, y: 0.3, z: 0, color: 0xe7e2d8, limb: 3, sy: 0.45 },
      { geo: sphere(0.08), x: 0.12, y: 0.3, z: 0, color: 0xe7e2d8, limb: 4, sy: 0.45 },
      { geo: cyl(0.015, 0.02, 0.16, 4), x: -0.05, y: 0.08, z: 0.02, color: 0xe2a23a, limb: 1 },
      { geo: cyl(0.015, 0.02, 0.16, 4), x: 0.05, y: 0.08, z: 0.02, color: 0xe2a23a, limb: 2 },
    ],
    1.7,
    1.7,
    1.7,
  );
}

function sheep(): THREE.BufferGeometry {
  return bake(
    [
      { geo: sphere(0.28), x: 0, y: 0.42, z: 0, color: 0xf7f4ee, limb: 0, sx: 1.3, sy: 0.9, sz: 1.05 },
      { geo: sphere(0.16), x: 0, y: 0.48, z: 0.28, color: 0xf7f4ee, limb: 0 },
      { geo: sphere(0.1), x: 0, y: 0.5, z: 0.38, color: 0x2a241f, limb: 0, sz: 1.15 },
      { geo: sphere(0.02), x: -0.04, y: 0.54, z: 0.46, color: 0x111, limb: 0 },
      { geo: sphere(0.02), x: 0.04, y: 0.54, z: 0.46, color: 0x111, limb: 0 },
      { geo: cyl(0.04, 0.045, 0.28, 5), x: -0.14, y: 0.16, z: 0.12, color: 0x2a241f, limb: 1 },
      { geo: cyl(0.04, 0.045, 0.28, 5), x: 0.14, y: 0.16, z: 0.12, color: 0x2a241f, limb: 2 },
      { geo: cyl(0.04, 0.045, 0.28, 5), x: -0.14, y: 0.16, z: -0.12, color: 0x2a241f, limb: 1 },
      { geo: cyl(0.04, 0.045, 0.28, 5), x: 0.14, y: 0.16, z: -0.12, color: 0x2a241f, limb: 2 },
    ],
    1.45,
    1.45,
    1.45,
  );
}

function cow(): THREE.BufferGeometry {
  return bake(
    [
      { geo: box(0.72, 0.38, 0.36), x: 0, y: 0.52, z: 0, color: 0xf3efe6, limb: 0 },
      { geo: box(0.22, 0.16, 0.22), x: -0.16, y: 0.62, z: 0.02, color: 0x3a342f, limb: 0 },
      { geo: box(0.16, 0.14, 0.18), x: 0.18, y: 0.58, z: 0.04, color: 0x3a342f, limb: 0 },
      { geo: box(0.22, 0.2, 0.2), x: 0, y: 0.62, z: 0.38, color: 0xf7f3ea, limb: 0 },
      { geo: sphere(0.06), x: -0.08, y: 0.78, z: 0.36, color: 0xe8d7b0, limb: 0, sx: 0.4, sy: 1 },
      { geo: sphere(0.06), x: 0.08, y: 0.78, z: 0.36, color: 0xe8d7b0, limb: 0, sx: 0.4, sy: 1 },
      { geo: sphere(0.018), x: -0.06, y: 0.66, z: 0.48, color: 0x111, limb: 0 },
      { geo: sphere(0.018), x: 0.06, y: 0.66, z: 0.48, color: 0x111, limb: 0 },
      { geo: cyl(0.05, 0.055, 0.36, 5), x: -0.22, y: 0.2, z: 0.12, color: 0x3a342f, limb: 1 },
      { geo: cyl(0.05, 0.055, 0.36, 5), x: 0.22, y: 0.2, z: 0.12, color: 0x3a342f, limb: 2 },
      { geo: cyl(0.05, 0.055, 0.36, 5), x: -0.22, y: 0.2, z: -0.12, color: 0x3a342f, limb: 1 },
      { geo: cyl(0.05, 0.055, 0.36, 5), x: 0.22, y: 0.2, z: -0.12, color: 0x3a342f, limb: 2 },
      { geo: cyl(0.03, 0.02, 0.22, 4), x: 0, y: 0.48, z: -0.28, rx: Math.PI / 2.4, color: 0x3a342f, limb: 0 },
    ],
    1.35,
    1.35,
    1.35,
  );
}

function deer(): THREE.BufferGeometry {
  return bake(
    [
      { geo: capsule(0.14, 0.55), x: 0, y: 0.78, z: 0, rz: Math.PI / 2, color: 0x8a5a32, limb: 0 },
      { geo: capsule(0.08, 0.22), x: 0, y: 1.02, z: 0.38, rx: -0.9, color: 0x8a5a32, limb: 0 },
      { geo: sphere(0.11), x: 0, y: 1.22, z: 0.58, color: 0x9a6840, limb: 0 },
      { geo: sphere(0.02), x: -0.04, y: 1.26, z: 0.66, color: 0x1c1916, limb: 0 },
      { geo: sphere(0.02), x: 0.04, y: 1.26, z: 0.66, color: 0x1c1916, limb: 0 },
      { geo: cyl(0.012, 0.012, 0.28, 4), x: -0.04, y: 1.38, z: 0.52, rz: 0.5, color: 0xe6d7b8, limb: 0 },
      { geo: cyl(0.012, 0.012, 0.22, 4), x: -0.08, y: 1.48, z: 0.46, rz: 1.1, color: 0xe6d7b8, limb: 0 },
      { geo: cyl(0.012, 0.012, 0.28, 4), x: 0.04, y: 1.38, z: 0.52, rz: -0.5, color: 0xe6d7b8, limb: 0 },
      { geo: cyl(0.012, 0.012, 0.22, 4), x: 0.08, y: 1.48, z: 0.46, rz: -1.1, color: 0xe6d7b8, limb: 0 },
      { geo: cyl(0.035, 0.04, 0.48, 5), x: -0.12, y: 0.32, z: 0.16, color: 0x6b4226, limb: 1 },
      { geo: cyl(0.035, 0.04, 0.48, 5), x: 0.12, y: 0.32, z: 0.16, color: 0x6b4226, limb: 2 },
      { geo: cyl(0.035, 0.04, 0.48, 5), x: -0.12, y: 0.32, z: -0.18, color: 0x6b4226, limb: 1 },
      { geo: cyl(0.035, 0.04, 0.48, 5), x: 0.12, y: 0.32, z: -0.18, color: 0x6b4226, limb: 2 },
    ],
    1.25,
    1.25,
    1.25,
  );
}

function wolf(): THREE.BufferGeometry {
  return bake(
    [
      { geo: capsule(0.14, 0.55), x: 0, y: 0.48, z: 0, rz: Math.PI / 2, color: 0x6d7278, limb: 0 },
      { geo: cone(0.1, 0.28, 6), x: 0, y: 0.52, z: 0.42, rx: Math.PI / 2, color: 0x5c6166, limb: 0 },
      { geo: sphere(0.045), x: -0.06, y: 0.66, z: 0.22, color: 0x4e5358, limb: 0 },
      { geo: sphere(0.045), x: 0.06, y: 0.66, z: 0.22, color: 0x4e5358, limb: 0 },
      { geo: sphere(0.02), x: -0.035, y: 0.56, z: 0.52, color: 0xf2c14e, limb: 0 },
      { geo: sphere(0.02), x: 0.035, y: 0.56, z: 0.52, color: 0xf2c14e, limb: 0 },
      { geo: cone(0.035, 0.22, 5), x: 0, y: 0.58, z: -0.4, rx: -1.2, color: 0x5a5f64, limb: 0 },
      { geo: cyl(0.035, 0.04, 0.34, 5), x: -0.12, y: 0.2, z: 0.16, color: 0x3e4348, limb: 1 },
      { geo: cyl(0.035, 0.04, 0.34, 5), x: 0.12, y: 0.2, z: 0.16, color: 0x3e4348, limb: 2 },
      { geo: cyl(0.035, 0.04, 0.34, 5), x: -0.12, y: 0.2, z: -0.16, color: 0x3e4348, limb: 1 },
      { geo: cyl(0.035, 0.04, 0.34, 5), x: 0.12, y: 0.2, z: -0.16, color: 0x3e4348, limb: 2 },
    ],
    1.45,
    1.45,
    1.45,
  );
}

function bear(): THREE.BufferGeometry {
  return bake(
    [
      { geo: sphere(0.34), x: 0, y: 0.55, z: 0, color: 0x5c4638, limb: 0, sx: 1.25, sy: 0.85, sz: 0.95 },
      { geo: sphere(0.2), x: 0, y: 0.62, z: 0.32, color: 0x6a5344, limb: 0 },
      { geo: sphere(0.08), x: 0, y: 0.52, z: 0.48, color: 0xc4a48a, limb: 0, sz: 1.2 },
      { geo: sphere(0.07), x: -0.12, y: 0.78, z: 0.22, color: 0x4a382c, limb: 0 },
      { geo: sphere(0.07), x: 0.12, y: 0.78, z: 0.22, color: 0x4a382c, limb: 0 },
      { geo: sphere(0.025), x: -0.06, y: 0.66, z: 0.46, color: 0x1c1916, limb: 0 },
      { geo: sphere(0.025), x: 0.06, y: 0.66, z: 0.46, color: 0x1c1916, limb: 0 },
      { geo: cyl(0.07, 0.08, 0.32, 6), x: -0.22, y: 0.22, z: 0.14, color: 0x4a382c, limb: 1 },
      { geo: cyl(0.07, 0.08, 0.32, 6), x: 0.22, y: 0.22, z: 0.14, color: 0x4a382c, limb: 2 },
      { geo: cyl(0.08, 0.09, 0.28, 6), x: -0.2, y: 0.2, z: -0.16, color: 0x3e2e24, limb: 1 },
      { geo: cyl(0.08, 0.09, 0.28, 6), x: 0.2, y: 0.2, z: -0.16, color: 0x3e2e24, limb: 2 },
    ],
    1.4,
    1.4,
    1.4,
  );
}

function dragon(): THREE.BufferGeometry {
  return bake([
    { geo: capsule(0.28, 1.1), x: 0, y: 0.85, z: 0, rz: Math.PI / 2, color: 0x2f6d62, limb: 0 },
    { geo: capsule(0.16, 0.4), x: 0, y: 1.15, z: 0.7, rx: -0.7, color: 0x348074, limb: 0 },
    { geo: sphere(0.22), x: 0, y: 1.4, z: 1.05, color: 0x3c8f82, limb: 0, sz: 1.25 },
    { geo: cone(0.1, 0.32, 6), x: 0, y: 1.32, z: 1.32, rx: Math.PI / 2, color: 0x2a5e56, limb: 0 },
    { geo: cone(0.04, 0.22, 5), x: -0.08, y: 1.62, z: 0.98, rz: 0.4, color: 0xd4a15a, limb: 0 },
    { geo: cone(0.04, 0.22, 5), x: 0.08, y: 1.62, z: 0.98, rz: -0.4, color: 0xd4a15a, limb: 0 },
    { geo: sphere(0.035), x: -0.08, y: 1.46, z: 1.2, color: 0xf2c14e, limb: 0 },
    { geo: sphere(0.035), x: 0.08, y: 1.46, z: 1.2, color: 0xf2c14e, limb: 0 },
    { geo: sphere(0.22), x: 0, y: 0.78, z: 0.05, color: 0xc45c38, limb: 0, sx: 0.7, sy: 0.55, sz: 1.1 },
    { geo: capsule(0.12, 0.55), x: 0, y: 0.7, z: -0.85, rz: Math.PI / 2, color: 0x276258, limb: 0, sx: 0.7 },
    { geo: cone(0.08, 0.4, 5), x: 0, y: 0.62, z: -1.3, rx: -Math.PI / 2, color: 0x1f5148, limb: 0 },
    { geo: box(0.9, 0.05, 0.55), x: -0.7, y: 1.15, z: -0.05, color: 0x1c4a44, limb: 3, rz: 0.35 },
    { geo: box(0.9, 0.05, 0.55), x: 0.7, y: 1.15, z: -0.05, color: 0x1c4a44, limb: 4, rz: -0.35 },
    { geo: box(0.55, 0.04, 0.28), x: -0.55, y: 1.18, z: 0.05, color: 0xc45c38, limb: 3 },
    { geo: box(0.55, 0.04, 0.28), x: 0.55, y: 1.18, z: 0.05, color: 0xc45c38, limb: 4 },
    { geo: cyl(0.06, 0.07, 0.4, 5), x: -0.22, y: 0.35, z: 0.28, color: 0x24574f, limb: 1 },
    { geo: cyl(0.06, 0.07, 0.4, 5), x: 0.22, y: 0.35, z: 0.28, color: 0x24574f, limb: 2 },
    { geo: cyl(0.07, 0.08, 0.36, 5), x: -0.24, y: 0.32, z: -0.28, color: 0x1d4742, limb: 1 },
    { geo: cyl(0.07, 0.08, 0.36, 5), x: 0.24, y: 0.32, z: -0.28, color: 0x1d4742, limb: 2 },
  ]);
}

function tiger(): THREE.BufferGeometry {
  return bake(
    [
      { geo: capsule(0.16, 0.7), x: 0, y: 0.52, z: 0, rz: Math.PI / 2, color: 0xe08a2e, limb: 0 },
      { geo: box(0.08, 0.04, 0.22), x: 0, y: 0.66, z: 0.05, color: 0x1c1916, limb: 0 },
      { geo: box(0.08, 0.04, 0.18), x: 0, y: 0.62, z: -0.18, color: 0x1c1916, limb: 0 },
      { geo: cone(0.12, 0.32, 6), x: 0, y: 0.55, z: 0.5, rx: Math.PI / 2, color: 0xd47822, limb: 0 },
      { geo: sphere(0.05), x: -0.07, y: 0.72, z: 0.28, color: 0xf2efe8, limb: 0 },
      { geo: sphere(0.05), x: 0.07, y: 0.72, z: 0.28, color: 0xf2efe8, limb: 0 },
      { geo: sphere(0.018), x: -0.04, y: 0.58, z: 0.62, color: 0xf2c14e, limb: 0 },
      { geo: sphere(0.018), x: 0.04, y: 0.58, z: 0.62, color: 0xf2c14e, limb: 0 },
      { geo: cone(0.04, 0.42, 5), x: 0, y: 0.62, z: -0.52, rx: -1.15, color: 0xc46a28, limb: 0 },
      { geo: cyl(0.045, 0.05, 0.38, 5), x: -0.14, y: 0.22, z: 0.18, color: 0xc46a28, limb: 1 },
      { geo: cyl(0.045, 0.05, 0.38, 5), x: 0.14, y: 0.22, z: 0.18, color: 0xc46a28, limb: 2 },
      { geo: cyl(0.05, 0.055, 0.36, 5), x: -0.14, y: 0.22, z: -0.2, color: 0xb05e22, limb: 1 },
      { geo: cyl(0.05, 0.055, 0.36, 5), x: 0.14, y: 0.22, z: -0.2, color: 0xb05e22, limb: 2 },
    ],
    1.55,
    1.55,
    1.55,
  );
}

function shrine(): THREE.BufferGeometry {
  const stone = 0xcbb896;
  const dark = 0x8d6b42;
  const gold = 0xd4a15a;
  return bake([
    { geo: box(2.6, 0.32, 2.6), x: 0, y: 0.16, z: 0, color: 0xb7a48a, limb: 0 },
    { geo: box(1.9, 0.36, 1.9), x: 0, y: 0.48, z: 0, color: stone, limb: 0 },
    { geo: box(1.25, 0.4, 1.25), x: 0, y: 0.84, z: 0, color: 0xdfcba8, limb: 0 },
    { geo: box(0.72, 0.58, 0.72), x: 0, y: 1.3, z: 0, color: dark, limb: 0 },
    { geo: cone(0.32, 0.48, 4), x: 0, y: 1.78, z: 0, color: gold, limb: 0 },
    { geo: sphere(0.1), x: 0, y: 2.05, z: 0, color: 0xffe7a8, limb: 0 },
    { geo: cyl(0.06, 0.06, 0.7, 5), x: -1.05, y: 0.5, z: -1.05, color: dark, limb: 0 },
    { geo: cyl(0.06, 0.06, 0.7, 5), x: 1.05, y: 0.5, z: -1.05, color: dark, limb: 0 },
    { geo: cyl(0.06, 0.06, 0.7, 5), x: -1.05, y: 0.5, z: 1.05, color: dark, limb: 0 },
    { geo: cyl(0.06, 0.06, 0.7, 5), x: 1.05, y: 0.5, z: 1.05, color: dark, limb: 0 },
  ]);
}

function market(): THREE.BufferGeometry {
  return bake([
    { geo: box(2.3, 0.12, 1.7), x: 0, y: 0.06, z: 0, color: 0x6e6258, limb: 0 },
    { geo: cyl(0.05, 0.05, 1.35, 5), x: -1, y: 0.72, z: -0.7, color: 0x6b4226, limb: 0 },
    { geo: cyl(0.05, 0.05, 1.35, 5), x: 1, y: 0.72, z: -0.7, color: 0x6b4226, limb: 0 },
    { geo: cyl(0.05, 0.05, 1.35, 5), x: -1, y: 0.72, z: 0.7, color: 0x6b4226, limb: 0 },
    { geo: cyl(0.05, 0.05, 1.35, 5), x: 1, y: 0.72, z: 0.7, color: 0x6b4226, limb: 0 },
    { geo: box(2.6, 0.08, 2.0), x: 0, y: 1.42, z: 0, color: 0xc45c38, limb: 0 },
    { geo: box(2.2, 0.06, 0.16), x: 0, y: 1.2, z: 0.85, color: 0xe7d3a8, limb: 0 },
    { geo: box(1.5, 0.32, 0.7), x: 0, y: 0.5, z: 0, color: 0xe7d3a8, limb: 0 },
    { geo: sphere(0.12), x: -0.45, y: 0.78, z: 0.2, color: 0xd86b7a, limb: 0 },
    { geo: sphere(0.11), x: 0.4, y: 0.76, z: -0.12, color: 0x3e8a45, limb: 0 },
    { geo: sphere(0.1), x: 0.05, y: 0.8, z: 0.25, color: 0xf2d36b, limb: 0 },
  ]);
}

function bird(): THREE.BufferGeometry {
  return bake([
    { geo: sphere(0.08), x: 0, y: 0.08, z: 0, color: 0x2c3338, limb: 0, sx: 1.5, sy: 0.65, sz: 0.85 },
    { geo: box(0.28, 0.015, 0.1), x: -0.16, y: 0.1, z: 0, color: 0x5c6770, limb: 3, rz: 0.45 },
    { geo: box(0.28, 0.015, 0.1), x: 0.16, y: 0.1, z: 0, color: 0x5c6770, limb: 4, rz: -0.45 },
    { geo: cone(0.03, 0.09, 4), x: 0, y: 0.08, z: 0.1, rx: Math.PI / 2, color: 0xe8b15a, limb: 0 },
  ]);
}

function house(): THREE.BufferGeometry {
  const wall = 0xc4a27a;
  const roof = 0x8e3d32;
  const wood = 0x5c3a28;
  const win = 0xd5e9f6;
  return bake([
    { geo: box(2.35, 0.18, 1.9), x: 0, y: 0.09, z: 0, color: 0x8d8680, limb: 0 },
    { geo: box(2.1, 1.05, 1.6), x: 0, y: 0.7, z: 0, color: wall, limb: 0 },
    { geo: cone(1.55, 0.85, 4), x: 0, y: 1.55, z: 0, ry: Math.PI / 4, color: roof, limb: 0 },
    { geo: box(0.38, 0.72, 0.08), x: 0, y: 0.52, z: 0.84, color: wood, limb: 0 },
    { geo: box(0.32, 0.28, 0.06), x: -0.55, y: 0.9, z: 0.83, color: win, limb: 0 },
    { geo: box(0.32, 0.28, 0.06), x: 0.55, y: 0.9, z: 0.83, color: win, limb: 0 },
    { geo: box(0.22, 0.4, 0.22), x: 0.7, y: 1.35, z: -0.35, color: 0x7a6558, limb: 0 },
    { geo: box(0.16, 0.08, 0.55), x: 0, y: 0.08, z: 1.05, color: 0x6e6258, limb: 0 },
  ]);
}

function farm(): THREE.BufferGeometry {
  return bake([
    { geo: box(2.3, 0.12, 1.7), x: 0, y: 0.06, z: 0, color: 0x6a4a32, limb: 0 },
    { geo: box(1.9, 0.1, 0.22), x: 0, y: 0.16, z: -0.45, color: 0x3e8a45, limb: 0 },
    { geo: box(1.9, 0.1, 0.22), x: 0, y: 0.16, z: 0, color: 0x4e9a4c, limb: 0 },
    { geo: box(1.9, 0.1, 0.22), x: 0, y: 0.16, z: 0.45, color: 0x2f6e38, limb: 0 },
    { geo: cyl(0.04, 0.04, 0.55, 5), x: -1.05, y: 0.32, z: -0.75, color: 0x6b4226, limb: 0 },
    { geo: cyl(0.04, 0.04, 0.55, 5), x: 1.05, y: 0.32, z: -0.75, color: 0x6b4226, limb: 0 },
    { geo: cyl(0.04, 0.04, 0.55, 5), x: -1.05, y: 0.32, z: 0.75, color: 0x6b4226, limb: 0 },
    { geo: cyl(0.04, 0.04, 0.55, 5), x: 1.05, y: 0.32, z: 0.75, color: 0x6b4226, limb: 0 },
  ]);
}

function tower(): THREE.BufferGeometry {
  return bake([
    { geo: cyl(0.7, 0.85, 2.4, 8), x: 0, y: 1.2, z: 0, color: 0x8d8a84, limb: 0 },
    { geo: cone(1.05, 0.9, 8), x: 0, y: 2.7, z: 0, color: 0x8e3d32, limb: 0 },
    { geo: box(0.28, 0.42, 0.08), x: 0, y: 0.5, z: 0.8, color: 0x4a2e22, limb: 0 },
    { geo: box(0.28, 0.32, 0.06), x: 0, y: 1.5, z: 0.78, color: 0xd5e9f6, limb: 0 },
    { geo: box(0.22, 0.22, 0.06), x: 0.55, y: 1.7, z: 0.35, color: 0xd5e9f6, limb: 0 },
  ]);
}

function castle(): THREE.BufferGeometry {
  const stone = 0x9a958e;
  const roof = 0x6e3430;
  return bake([
    { geo: box(3.4, 1.3, 2.6), x: 0, y: 0.7, z: 0, color: stone, limb: 0 },
    { geo: box(1.3, 2.1, 1.3), x: 0, y: 1.15, z: -0.15, color: 0x8e8982, limb: 0 },
    { geo: cone(0.95, 0.8, 4), x: 0, y: 2.45, z: -0.15, ry: Math.PI / 4, color: roof, limb: 0 },
    { geo: cyl(0.38, 0.42, 1.8, 7), x: -1.45, y: 0.95, z: -1.05, color: stone, limb: 0 },
    { geo: cyl(0.38, 0.42, 1.8, 7), x: 1.45, y: 0.95, z: -1.05, color: stone, limb: 0 },
    { geo: cyl(0.38, 0.42, 1.8, 7), x: -1.45, y: 0.95, z: 1.05, color: stone, limb: 0 },
    { geo: cyl(0.38, 0.42, 1.8, 7), x: 1.45, y: 0.95, z: 1.05, color: stone, limb: 0 },
    { geo: cone(0.5, 0.55, 7), x: -1.45, y: 2.05, z: -1.05, color: roof, limb: 0 },
    { geo: cone(0.5, 0.55, 7), x: 1.45, y: 2.05, z: -1.05, color: roof, limb: 0 },
    { geo: cone(0.5, 0.55, 7), x: -1.45, y: 2.05, z: 1.05, color: roof, limb: 0 },
    { geo: cone(0.5, 0.55, 7), x: 1.45, y: 2.05, z: 1.05, color: roof, limb: 0 },
    { geo: box(0.7, 0.9, 0.1), x: 0, y: 0.5, z: 1.35, color: 0x3e2a22, limb: 0 },
    { geo: box(0.28, 0.28, 0.06), x: 0, y: 1.7, z: 0.52, color: 0xd5e9f6, limb: 0 },
    { geo: cyl(0.03, 0.03, 0.7, 4), x: 0, y: 2.9, z: -0.15, color: 0x6b4226, limb: 0 },
  ]);
}

function wall(): THREE.BufferGeometry {
  return bake([
    { geo: box(2.1, 1.05, 0.42), x: 0, y: 0.55, z: 0, color: 0x8a8680, limb: 0 },
    { geo: box(0.28, 0.28, 0.48), x: -0.7, y: 1.15, z: 0, color: 0x7c7872, limb: 0 },
    { geo: box(0.28, 0.28, 0.48), x: 0, y: 1.15, z: 0, color: 0x7c7872, limb: 0 },
    { geo: box(0.28, 0.28, 0.48), x: 0.7, y: 1.15, z: 0, color: 0x7c7872, limb: 0 },
  ]);
}

function boat(): THREE.BufferGeometry {
  return bake([
    { geo: box(0.7, 0.28, 1.7), x: 0, y: 0.24, z: 0, color: 0x8e3d32, limb: 0, sx: 1, sy: 0.8, sz: 1 },
    { geo: box(0.5, 0.16, 0.4), x: 0, y: 0.4, z: -0.15, color: 0xe7d7c4, limb: 0 },
    { geo: cyl(0.03, 0.03, 0.9, 5), x: 0, y: 0.85, z: -0.15, color: 0x6b4226, limb: 0 },
    { geo: box(0.02, 0.45, 0.32), x: 0.12, y: 0.85, z: -0.15, color: 0xf4efe4, limb: 0 },
  ]);
}

function firepit(): THREE.BufferGeometry {
  const parts: Part[] = [];
  for (let i = 0; i < 6; i++) {
    const a = (i / 6) * Math.PI * 2;
    parts.push({
      geo: sphere(0.12),
      x: Math.cos(a) * 0.32,
      y: 0.08,
      z: Math.sin(a) * 0.32,
      color: 0x6e6760,
      limb: 0,
      sy: 0.7,
    });
  }
  parts.push({ geo: cyl(0.18, 0.22, 0.08, 8), x: 0, y: 0.05, z: 0, color: 0x3a332e, limb: 0 });
  return bake(parts, 1.4, 1.4, 1.4);
}

function flame(): THREE.BufferGeometry {
  return bake([
    { geo: cone(0.12, 0.38, 6), x: 0, y: 0.28, z: 0, color: 0xff7a32, limb: 0 },
    { geo: cone(0.07, 0.24, 6), x: 0.02, y: 0.4, z: 0, color: 0xffe08a, limb: 0 },
  ]);
}

function flag(): THREE.BufferGeometry {
  return bake([
    { geo: box(0.42, 0.28, 0.03), x: 0.2, y: 0, z: 0, color: 0xffffff, limb: 0 },
  ]);
}

function rock(): THREE.BufferGeometry {
  return bake([
    { geo: geo("ico", () => new THREE.IcosahedronGeometry(0.55, 0)), x: 0, y: 0.32, z: 0, color: 0x8a8680, limb: 0, sx: 1.2, sy: 0.75, sz: 1 },
    { geo: sphere(0.28), x: 0.28, y: 0.22, z: 0.08, color: 0x6e6a64, limb: 0 },
  ]);
}

function bush(): THREE.BufferGeometry {
  return bake([
    { geo: sphere(0.32), x: 0, y: 0.28, z: 0, color: 0x2f7a3e, limb: 0 },
    { geo: sphere(0.22), x: 0.18, y: 0.24, z: 0.08, color: 0x3e8c4a, limb: 0 },
    { geo: sphere(0.18), x: -0.16, y: 0.22, z: -0.05, color: 0x246832, limb: 0 },
  ]);
}

function flower(): THREE.BufferGeometry {
  return bake([
    { geo: cyl(0.015, 0.02, 0.28, 4), x: 0, y: 0.14, z: 0, color: 0x2f6a34, limb: 0 },
    { geo: sphere(0.07), x: 0, y: 0.32, z: 0, color: 0xd86b7a, limb: 0 },
    { geo: sphere(0.035), x: 0, y: 0.32, z: 0, color: 0xf2d36b, limb: 0 },
  ]);
}

function grass(): THREE.BufferGeometry {
  return bake([
    { geo: cone(0.05, 0.42, 4), x: 0, y: 0.21, z: 0, color: 0x4e9a46, limb: 0 },
    { geo: cone(0.035, 0.3, 3), x: 0.06, y: 0.15, z: 0.02, rz: 0.3, color: 0x3d7a38, limb: 0 },
  ]);
}

const RACES = {
  human: { skin: 0xe0b48f, cloth: 0x3e6f9a, trim: 0x2a5278, hair: 0x4a3428, pants: 0x3d4a62, boot: 0x4a3428 },
  elf: { skin: 0xf0d2b4, cloth: 0x2f7a52, trim: 0x1e5a3c, hair: 0xe6d29a, pants: 0x24543a, boot: 0x6b5338 },
  orc: { skin: 0x7d9a62, cloth: 0x6a4332, trim: 0x4e3226, hair: 0x2a241c, pants: 0x3e342c, boot: 0x2c241c },
  dwarf: { skin: 0xd7a784, cloth: 0x8d3d3d, trim: 0x6e3030, hair: 0x8a4e28, pants: 0x4a3a32, boot: 0x3a2c24 },
} as const;

export function buildGeometries(): Map<string, THREE.BufferGeometry> {
  const map = new Map<string, THREE.BufferGeometry>();
  const races = Object.keys(RACES) as (keyof typeof RACES)[];
  for (const race of races) {
    const c = RACES[race];
    const base = {
      ...c,
      bulk: race === "orc" ? 1.18 : race === "dwarf" ? 1.22 : race === "elf" ? 0.92 : 1,
      tall: race === "dwarf" ? 0.78 : race === "elf" ? 1.08 : race === "orc" ? 1.04 : 1,
    };
    map.set(race, person({ ...base, hat: race === "elf" ? "hood" : race === "dwarf" ? "cap" : "none", beard: race === "dwarf", tusks: race === "orc", ears: race === "elf" }));
    map.set(`${race}_w`, person({ ...base, hat: "helmet", sword: true, shield: true }));
    map.set(`${race}_k`, person({ ...base, hat: "crown", cape: true, sword: true, beard: race === "dwarf" || race === "human" }));
  }
  const human = RACES.human;
  map.set(
    "baby",
    person({
      ...human,
      bulk: 0.85,
      tall: 1,
      hat: "none",
      baby: true,
      cloth: 0xd7c4a4,
      pants: 0xcbb89a,
    }),
  );
  map.set("chicken", chicken());
  map.set("sheep", sheep());
  map.set("cow", cow());
  map.set("deer", deer());
  map.set("wolf", wolf());
  map.set("bear", bear());
  map.set("tiger", tiger());
  map.set("dragon", dragon());
  map.set("oak", oak());
  map.set("pine", pine());
  map.set("palm", palm());
  map.set("rock", rock());
  map.set("bush", bush());
  map.set("flower", flower());
  map.set("house", house());
  map.set("farm", farm());
  map.set("tower", tower());
  map.set("castle", castle());
  map.set("shrine", shrine());
  map.set("market", market());
  map.set("wall", wall());
  map.set("boat", boat());
  map.set("firepit", firepit());
  map.set("flame", flame());
  map.set("flag", flag());
  map.set("bird", bird());
  map.set("grass", grass());
  return map;
}

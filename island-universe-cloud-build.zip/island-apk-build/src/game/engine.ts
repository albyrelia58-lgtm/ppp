import { Soundscape } from "./audio";
import { WorldSim } from "./sim";
import {
  CATS,
  applyPreset,
  defaultSettings,
  type Category,
  type GraphicsSettings,
  type Inspect,
  type KingdomView,
  type LogItem,
  type Settings,
  type SizeId,
  type SoundId,
  type Tool,
  type Weather,
  type WorldMeta,
  type WorldOptions,
  clamp,
} from "./types";
import { WorldView } from "./view";

declare global {
  interface Window {
    __controlsTest?: {
      getYaw: () => number;
      getSpeed: () => number;
      setSteer?: (v: number) => void;
      setKeys?: (codes: string[]) => void;
    };
  }
}

export interface Snapshot {
  phase: "menu" | "play";
  paused: boolean;
  speed: number;
  fps: number;
  frameMs: number;
  draws: number;
  day: number;
  year: number;
  hour: number;
  season: number;
  weather: Weather;
  pop: number;
  animals: number;
  births: number;
  deaths: number;
  tool: Tool;
  cat: Category;
  brush: number;
  worldName: string;
  size: SizeId;
  toast: string | null;
  inspect: Inspect | null;
  log: LogItem[];
  kingdoms: KingdomView[];
  saves: WorldMeta[];
  settings: Settings;
  webgl: string | null;
  shadows: GraphicsSettings["shadows"];
}

const INDEX_KEY = "singgasana-index-v1";
const SETTINGS_KEY = "singgasana-settings-v1";

function readIndex(): WorldMeta[] {
  try {
    const raw = localStorage.getItem(INDEX_KEY);
    if (!raw) return [];
    const list = JSON.parse(raw) as WorldMeta[];
    return Array.isArray(list) ? list : [];
  } catch {
    return [];
  }
}

function writeIndex(list: WorldMeta[]): void {
  localStorage.setItem(INDEX_KEY, JSON.stringify(list.slice(0, 8)));
}

export class IslandEngine {
  private view: WorldView | null = null;
  private sim: WorldSim | null = null;
  private readonly audio = new Soundscape();
  private readonly keys = new Set<string>();
  private probeKeys: Set<string> | null = null;
  private pointers = new Map<number, { x: number; y: number; button: number }>();
  private drag = 0;
  private painting = false;
  private panning = false;
  private lastX = 0;
  private lastY = 0;
  private pinch = 0;
  private lastPaint = { x: 0, z: 0, ok: false };
  private space = false;
  private phase: "menu" | "play" = "menu";
  private paused = false;
  private speed = 1;
  private tool: Tool = "finger";
  private cat: Category = "bangsa";
  private brush = 1;
  private settings: Settings = defaultSettings();
  private forwardSpeed = 0;
  private fps = 0;
  private frameMs = 16;
  private marks: number[] = [];
  private acc = 0;
  private clock = 0;
  private emitAt = 0;
  private miniAt = 0;
  private voiceAt = 1.6;
  private stepAt = 0.4;
  private splashAt = 2;
  private toastKey: string | null = null;
  private toastAt = 0;
  private dead = false;
  private webgl: string | null = null;
  private minimap: HTMLCanvasElement | null = null;
  private loop = (now: number) => this.frame(now);

  constructor(
    private canvas: HTMLCanvasElement,
    private onSnap: (snap: Snapshot) => void,
  ) {
    this.settings = this.loadSettings();
  }

  start(): void {
    try {
      this.view = new WorldView(this.canvas);
      this.view.setGraphics(this.settings.graphics);
    } catch (err) {
      this.webgl = err instanceof Error ? err.message : "webgl";
      this.emit();
      return;
    }
    this.reroll({ name: "Pulau Fajar", size: "medium", seed: (Math.random() * 1e9) >>> 0 }, false);
    window.addEventListener("keydown", this.onKeyDown);
    window.addEventListener("keyup", this.onKeyUp);
    window.addEventListener("blur", this.onBlur);
    document.addEventListener("visibilitychange", this.onVis);
    this.canvas.addEventListener("pointerdown", this.onPointerDown);
    this.canvas.addEventListener("pointermove", this.onPointerMove);
    this.canvas.addEventListener("pointerup", this.onPointerUp);
    this.canvas.addEventListener("pointercancel", this.onPointerUp);
    this.canvas.addEventListener("wheel", this.onWheel, { passive: false });
    this.canvas.addEventListener("contextmenu", (e) => e.preventDefault());
    window.addEventListener("resize", this.onResize);
    this.onResize();
    this.mountProbe();
    this.view.renderer.setAnimationLoop(this.loop);
    this.emit();
  }

  dispose(): void {
    this.dead = true;
    this.view?.dispose();
    window.removeEventListener("keydown", this.onKeyDown);
    window.removeEventListener("keyup", this.onKeyUp);
    window.removeEventListener("blur", this.onBlur);
    document.removeEventListener("visibilitychange", this.onVis);
    this.canvas.removeEventListener("pointerdown", this.onPointerDown);
    this.canvas.removeEventListener("pointermove", this.onPointerMove);
    this.canvas.removeEventListener("pointerup", this.onPointerUp);
    this.canvas.removeEventListener("pointercancel", this.onPointerUp);
    this.canvas.removeEventListener("wheel", this.onWheel);
    window.removeEventListener("resize", this.onResize);
  }

  attachMinimap(canvas: HTMLCanvasElement | null): void {
    this.minimap = canvas;
  }

  enter(): void {
    if (!this.sim) return;
    this.audio.unlock();
    this.phase = "play";
    this.paused = false;
    this.speed = 1;
    this.audio.play("ui_open");
    this.emit();
  }

  reroll(opts: WorldOptions, enter: boolean): void {
    this.audio.unlock();
    this.sim = new WorldSim(opts);
    this.view?.bind(this.sim);
    this.phase = enter ? "play" : "menu";
    this.paused = false;
    this.audio.play("ui_open");
    this.emit();
  }

  save(): void {
    if (!this.sim) return;
    this.audio.unlock();
    try {
      const raw = this.sim.serialize();
      localStorage.setItem(`singgasana-w-${this.sim.id}`, raw);
      const meta: WorldMeta = {
        id: this.sim.id,
        name: this.sim.name,
        savedAt: Date.now(),
        size: this.sim.sizeId,
        day: this.sim.day,
        pop: this.sim.popCount(),
      };
      const list = readIndex().filter((w) => w.id !== meta.id);
      list.unshift(meta);
      writeIndex(list);
      this.toastKey = "savedOk";
      this.toastAt = 2.4;
      this.audio.play("ui_save");
    } catch {
      this.toastKey = "full";
      this.toastAt = 2.2;
      this.audio.play("ui_error");
    }
    this.emit();
  }

  load(id: string): void {
    this.audio.unlock();
    const raw = localStorage.getItem(`singgasana-w-${id}`);
    if (!raw) return;
    const sim = WorldSim.fromSave(raw);
    if (!sim || !this.view) {
      this.audio.play("ui_error");
      return;
    }
    this.sim = sim;
    this.view.bind(sim);
    this.phase = "play";
    this.paused = false;
    this.audio.play("ui_open");
    this.emit();
  }

  remove(id: string): void {
    localStorage.removeItem(`singgasana-w-${id}`);
    writeIndex(readIndex().filter((w) => w.id !== id));
    this.audio.unlock();
    this.audio.play("ui_close");
    this.emit();
  }

  rename(name: string): void {
    if (this.sim) this.sim.name = name.slice(0, 32);
    this.emit();
  }

  setSpeed(speed: number): void {
    this.speed = speed;
    this.paused = speed <= 0;
    this.audio.unlock();
    this.audio.play("ui_tap");
    this.emit();
  }

  togglePause(): void {
    if (this.phase !== "play") return;
    this.paused = !this.paused;
    if (this.paused) this.speed = 0;
    else if (this.speed <= 0) this.speed = 1;
    this.audio.unlock();
    this.audio.play(this.paused ? "ui_close" : "ui_open");
    this.emit();
  }

  goMenu(): void {
    this.phase = "menu";
    this.paused = false;
    this.audio.unlock();
    this.audio.play("ui_close");
    this.emit();
  }

  setTool(tool: Tool): void {
    this.tool = tool;
    const found = CATS.find((c) => c.tools.includes(tool));
    if (found) this.cat = found.id;
    this.audio.unlock();
    this.audio.play("ui_tap");
    this.emit();
  }

  setCat(cat: Category): void {
    this.cat = cat;
    const group = CATS.find((c) => c.id === cat);
    const first = group?.tools[0];
    if (first) this.tool = first;
    this.audio.unlock();
    this.audio.play("ui_tap");
    this.emit();
  }

  setBrush(n: number): void {
    this.brush = n > 1 ? 5 : 1;
    this.audio.unlock();
    this.audio.play("ui_tap");
    this.emit();
  }

  focusKingdom(id: number): void {
    const k = this.sim?.kingdoms.find((item) => item.id === id);
    const view = this.view;
    if (!k || !view) return;
    view.focus.set(k.hx, 0, k.hz);
    this.audio.unlock();
    this.audio.play("select", 0);
    this.emit();
  }

  focusNorm(nx: number, nz: number): void {
    if (!this.sim || !this.view) return;
    this.view.focus.set(clamp(nx, 0.02, 0.98) * this.sim.span, 0, clamp(nz, 0.02, 0.98) * this.sim.span);
  }

  clearInspect(): void {
    if (this.sim) this.sim.selected = null;
    this.emit();
  }

  setLang(lang: Settings["lang"]): void {
    this.settings.lang = lang;
    this.persistSettings();
    this.audio.unlock();
    this.audio.play("ui_tap");
    this.emit();
  }

  setGraphics(partial: Partial<GraphicsSettings>, replacePreset = false): void {
    if (replacePreset && partial.preset) {
      this.settings.graphics = {
        ...applyPreset(partial.preset),
        showFps: this.settings.graphics.showFps,
        showPerf: this.settings.graphics.showPerf,
      };
    } else {
      this.settings.graphics = { ...this.settings.graphics, ...partial };
    }
    this.view?.setGraphics(this.settings.graphics);
    this.persistSettings();
    this.emit();
  }

  setAudio(partial: Partial<Settings["audio"]>): void {
    this.settings.audio = { ...this.settings.audio, ...partial };
    this.audio.setVolumes(this.settings.audio.master, this.settings.audio.music, this.settings.audio.sfx, this.settings.audio.mute);
    this.persistSettings();
    this.emit();
  }

  nudgeZoom(dir: number): void {
    if (!this.view) return;
    this.audio.unlock();
    this.view.dist = clamp(this.view.dist * (dir > 0 ? 0.86 : 1.16), 14, 78);
  }

  private loadSettings(): Settings {
    try {
      const raw = localStorage.getItem(SETTINGS_KEY);
      if (!raw) return defaultSettings();
      const parsed = JSON.parse(raw) as Settings;
      if (parsed.version !== 1) return defaultSettings();
      return { ...defaultSettings(), ...parsed, graphics: { ...defaultSettings().graphics, ...parsed.graphics }, audio: { ...defaultSettings().audio, ...parsed.audio } };
    } catch {
      return defaultSettings();
    }
  }

  private persistSettings(): void {
    localStorage.setItem(SETTINGS_KEY, JSON.stringify(this.settings));
  }

  private mountProbe(): void {
    if (!import.meta.env.DEV && !new URLSearchParams(location.search).has("qa")) return;
    const view = this.view;
    if (!view) return;
    window.__controlsTest = {
      getYaw: () => view.yaw,
      getSpeed: () => this.forwardSpeed,
      setKeys: (codes: string[]) => {
        this.probeKeys = new Set(codes);
      },
    };
  }

  private onResize = (): void => {
    this.view?.resize();
  };

  private onVis = (): void => {
    if (document.hidden) this.audio.suspend();
    else this.audio.resume();
  };

  private onBlur = (): void => {
    this.keys.clear();
    this.space = false;
  };

  private onKeyDown = (e: KeyboardEvent): void => {
    const target = e.target;
    if (target instanceof HTMLElement) {
      const tag = target.tagName;
      if (tag === "INPUT" || tag === "TEXTAREA" || target.isContentEditable) return;
    }
    this.keys.add(e.code);
    if (e.code === "Space") this.space = true;
    if (["Space", "ArrowUp", "ArrowDown", "ArrowLeft", "ArrowRight"].includes(e.code)) e.preventDefault();
    if (e.code === "Escape" && this.phase === "play") this.togglePause();
    this.audio.unlock();
  };

  private onKeyUp = (e: KeyboardEvent): void => {
    this.keys.delete(e.code);
    if (e.code === "Space") this.space = false;
  };

  private onWheel = (e: WheelEvent): void => {
    if (!this.view) return;
    e.preventDefault();
    this.view.dist = clamp(this.view.dist * (e.deltaY > 0 ? 1.08 : 0.92), 14, 78);
  };

  private onPointerDown = (e: PointerEvent): void => {
    this.audio.unlock();
    this.pointers.set(e.pointerId, { x: e.clientX, y: e.clientY, button: e.button });
    this.drag = 0;
    this.lastX = e.clientX;
    this.lastY = e.clientY;
    this.painting = false;
    this.panning = e.button === 1 || e.button === 2 || this.space || this.tool === "finger" || this.phase !== "play";
    if (this.pointers.size === 2) {
      const pts = [...this.pointers.values()];
      this.pinch = Math.hypot((pts[0]?.x ?? 0) - (pts[1]?.x ?? 0), (pts[0]?.y ?? 0) - (pts[1]?.y ?? 0));
      this.panning = true;
      this.painting = false;
    }
    this.canvas.setPointerCapture(e.pointerId);
  };

  private onPointerMove = (e: PointerEvent): void => {
    const prev = this.pointers.get(e.pointerId);
    if (!prev || !this.view || !this.sim) return;
    const dx = e.clientX - prev.x;
    const dy = e.clientY - prev.y;
    prev.x = e.clientX;
    prev.y = e.clientY;
    this.drag += Math.abs(dx) + Math.abs(dy);
    if (this.pointers.size >= 2) {
      const pts = [...this.pointers.values()];
      const dist = Math.hypot((pts[0]?.x ?? 0) - (pts[1]?.x ?? 0), (pts[0]?.y ?? 0) - (pts[1]?.y ?? 0));
      if (this.pinch > 0) this.view.dist = clamp(this.view.dist / (dist / this.pinch), 14, 78);
      this.pinch = dist;
      this.pan(dx, dy);
      return;
    }
    if (this.drag > 7 && (this.panning || this.space || this.tool === "finger" || this.phase !== "play")) {
      this.panning = true;
      this.pan(dx, dy);
      return;
    }
    if (this.phase === "play" && this.drag > 7 && this.tool !== "finger") {
      this.painting = true;
      this.stroke(e.clientX, e.clientY);
    }
  };

  private onPointerUp = (e: PointerEvent): void => {
    const was = this.pointers.get(e.pointerId);
    this.pointers.delete(e.pointerId);
    if (this.pointers.size < 2) this.pinch = 0;
    if (!was || !this.view || !this.sim) return;
    if (this.drag < 8 && e.button === 0 && this.phase === "play") {
      const hit = this.view.screenToGround(e.clientX, e.clientY);
      if (hit) {
        if (this.tool === "finger") this.sim.selectAt(hit.x, hit.z);
        else this.sim.apply(this.tool, hit.x, hit.z, this.brush);
        this.afterSimAction();
      }
    }
    this.painting = false;
    this.lastPaint.ok = false;
  };

  private pan(dx: number, dy: number): void {
    const view = this.view;
    if (!view) return;
    view.camera.updateMatrixWorld();
    const e = view.camera.matrixWorld.elements;
    const scale = view.dist * 0.00235;
    const rx = e[0] ?? 1;
    const rz = e[2] ?? 0;
    const ux = e[4] ?? 0;
    const uz = e[6] ?? 1;
    view.focus.x -= (rx * dx + ux * dy) * scale;
    view.focus.z -= (rz * dx + uz * dy) * scale;
    this.clampFocus();
  }

  private stroke(clientX: number, clientY: number): void {
    const view = this.view;
    const sim = this.sim;
    if (!view || !sim) return;
    const hit = view.screenToGround(clientX, clientY);
    if (!hit) return;
    if (this.lastPaint.ok && Math.hypot(hit.x - this.lastPaint.x, hit.z - this.lastPaint.z) < 1.15) return;
    this.lastPaint = { x: hit.x, z: hit.z, ok: true };
    sim.apply(this.tool, hit.x, hit.z, 1);
    this.afterSimAction();
  }

  private afterSimAction(): void {
    const sim = this.sim;
    const view = this.view;
    if (!sim || !view) return;
    const fx = sim.fxQ.splice(0, sim.fxQ.length);
    view.spawn(fx);
    if (fx.some((f) => f.kind === "meteor" || f.kind === "boom")) view.shake = Math.max(view.shake, 0.4);
    this.playQueue();
    if (sim.toast) {
      this.toastKey = sim.toast === "full" ? "full" : sim.toast === "needTwo" ? "needTwo" : "needLand";
      this.toastAt = 1.8;
      sim.toast = null;
    }
    this.emit();
  }

  private playQueue(): void {
    const sim = this.sim;
    const view = this.view;
    if (!sim || !view) return;
    const queued = sim.sfxQ.splice(0, sim.sfxQ.length);
    for (const ev of queued) this.audio.play(ev.id, view.panOf(ev.x, ev.z));
  }

  private clampFocus(): void {
    const sim = this.sim;
    const view = this.view;
    if (!sim || !view) return;
    view.focus.x = clamp(view.focus.x, 2, sim.span - 2);
    view.focus.z = clamp(view.focus.z, 2, sim.span - 2);
  }

  private frame(now: number): void {
    if (this.dead || !this.view || !this.sim) return;
    const raw = this.clock ? Math.min(0.05, (now - this.clock) / 1000) : 0.016;
    this.clock = now;
    this.marks.push(now);
    while (this.marks.length && now - (this.marks[0] ?? now) > 1000) this.marks.shift();
    this.fps = this.marks.length;
    this.frameMs = this.frameMs * 0.9 + raw * 1000 * 0.1;
    this.moveCamera(raw);
    const speed = this.phase === "play" ? (this.paused ? 0 : this.speed) : 0.4;
    if (speed > 0) {
      this.acc += raw * speed;
      let guard = 0;
      while (this.acc >= 1 / 30 && guard < 4) {
        this.sim.tick(1 / 30);
        this.acc -= 1 / 30;
        guard++;
      }
    }
    const fx = this.sim.fxQ.splice(0, this.sim.fxQ.length);
    if (fx.length) this.view.spawn(fx);
    this.playQueue();
    if (this.sim.toast) {
      this.toastKey = this.sim.toast;
      this.toastAt = this.sim.toast.startsWith("event_") ? 3.4 : 1.6;
      this.sim.toast = null;
    }
    this.toastAt = Math.max(0, this.toastAt - raw);
    if (this.toastAt <= 0) this.toastKey = null;
    this.ambience(raw);
    const night = this.sim.time < 5.6 || this.sim.time > 19.2 ? 1 : 0;
    this.audio.setScene(this.sim.weather, night);
    this.audio.update(raw);
    this.view.sync(raw);
    this.miniAt -= raw;
    if (this.miniAt <= 0 && this.minimap) {
      this.miniAt = 0.45;
      const ctx = this.minimap.getContext("2d");
      if (ctx) this.view.drawMinimap(ctx, this.minimap.width, this.minimap.height);
    }
    this.emitAt -= raw;
    if (this.emitAt <= 0) {
      this.emitAt = 0.25;
      this.emit();
    }
  }

  private moveCamera(dt: number): void {
    const view = this.view;
    const sim = this.sim;
    if (!view || !sim) return;
    const down = this.probeKeys ?? this.keys;
    let steer = 0;
    if (down.has("KeyA") || down.has("ArrowLeft")) steer += 1;
    if (down.has("KeyD") || down.has("ArrowRight")) steer -= 1;
    view.yaw += steer * 1.7 * dt;
    let throttle = 0;
    if (down.has("KeyW") || down.has("ArrowUp")) throttle += 1;
    if (down.has("KeyS") || down.has("ArrowDown")) throttle -= 1;
    const fx = -Math.sin(view.yaw);
    const fz = -Math.cos(view.yaw);
    const speed = throttle * 22;
    this.forwardSpeed = speed;
    view.focus.x += fx * speed * dt;
    view.focus.z += fz * speed * dt;
    if (this.phase === "menu" && steer === 0 && throttle === 0 && !this.panning && this.pointers.size === 0) {
      view.yaw += dt * 0.06;
    }
    this.clampFocus();
  }

  private ambience(dt: number): void {
    const sim = this.sim;
    const view = this.view;
    if (!sim || !view || this.phase === "menu") return;
    this.voiceAt -= dt;
    if (this.voiceAt <= 0) {
      this.voiceAt = 2.4 + Math.random() * 2.2;
      const animals = sim.units.filter((u) => u.alive && u.kind === "animal");
      const pick = animals[Math.floor(Math.random() * animals.length)];
      if (pick) {
        const id: SoundId =
          pick.race === "chicken"
            ? "chicken"
            : pick.race === "sheep"
              ? "sheep"
              : pick.race === "cow"
                ? "cow"
                : pick.race === "deer"
                  ? "deer"
                  : pick.race === "wolf"
                    ? "wolf"
                    : pick.race === "tiger"
                      ? "roar"
                      : pick.race === "bear"
                        ? "bear"
                        : "dragon";
        this.audio.play(id, view.panOf(pick.x, pick.z));
      }
    }
    this.stepAt -= dt;
    if (this.stepAt <= 0) {
      this.stepAt = 0.36;
      let best: { x: number; z: number; id: SoundId } | null = null;
      let d0 = 18;
      for (const u of sim.units) {
        if (!u.alive || !u.moving) continue;
        const d = Math.hypot(u.x - view.focus.x, u.z - view.focus.z);
        if (d > d0) continue;
        d0 = d;
        const id: SoundId = u.race === "orc" || u.race === "bear" || u.race === "cow" ? "foot_heavy" : u.race === "deer" || u.race === "sheep" ? "foot_hoof" : u.kind === "animal" ? "foot_paw" : "foot";
        best = { x: u.x, z: u.z, id };
      }
      if (best) this.audio.play(best.id, view.panOf(best.x, best.z));
    }
    this.splashAt -= dt;
    if (this.splashAt <= 0) {
      this.splashAt = 3.5 + Math.random() * 3;
      const x = view.focus.x + (Math.random() - 0.5) * 16;
      const z = view.focus.z + (Math.random() - 0.5) * 16;
      if (sim.heightAt(x, z) < sim.waterLevel) {
        this.audio.play("splash", view.panOf(x, z));
        view.spawn([{ kind: "splash", x, y: sim.waterLevel, z, life: 0.5, max: 0.5 }]);
      } else if (sim.biomeAt(x, z) === 8) this.audio.play("lava", view.panOf(x, z));
    }
  }

  private emit(): void {
    if (this.dead) return;
    this.onSnap(this.snapshot());
  }

  private snapshot(): Snapshot {
    const sim = this.sim;
    const kingdoms: KingdomView[] = [];
    if (sim) {
      for (const k of sim.kingdoms) {
        if (k.fallen) continue;
        const wars = k.wars
          .map((id) => sim.kingdoms.find((other) => other.id === id)?.name)
          .filter((name): name is string => !!name);
        kingdoms.push({
          id: k.id,
          race: k.race,
          name: k.name,
          color: k.color,
          pop: sim.units.filter((u) => u.alive && u.kingdom === k.id).length,
          food: Math.floor(k.food),
          wood: Math.floor(k.wood),
          stone: Math.floor(k.stone),
          wars,
          boost: k.boost > 0,
        });
      }
    }
    return {
      phase: this.phase,
      paused: this.paused,
      speed: this.speed,
      fps: this.fps,
      frameMs: this.frameMs,
      draws: this.view?.drawCalls ?? 0,
      day: sim?.day ?? 1,
      year: sim?.year ?? 1,
      hour: sim?.time ?? 8,
      season: Math.floor((sim?.day ?? 1) / 2) % 4,
      weather: sim?.weather ?? "clear",
      pop: sim?.popCount() ?? 0,
      animals: sim?.units.filter((u) => u.alive && u.kind === "animal").length ?? 0,
      births: sim?.births ?? 0,
      deaths: sim?.deaths ?? 0,
      tool: this.tool,
      cat: this.cat,
      brush: this.brush,
      worldName: sim?.name ?? "",
      size: sim?.sizeId ?? "medium",
      toast: this.toastKey,
      inspect: sim?.inspectSelected() ?? null,
      log: sim?.log ?? [],
      kingdoms,
      saves: readIndex(),
      settings: this.settings,
      webgl: this.webgl,
      shadows: this.settings.graphics.shadows,
    };
  }
}

import type { SoundId, Weather } from "./types";

type Osc = OscillatorType | "noise";

interface Voice {
  osc: Osc;
  f: number;
  dur: number;
  gain: number;
  slide: number;
  filter: number;
  filterType: BiquadFilterType;
  delay: number;
}

const GAPS: Partial<Record<SoundId, number>> = {
  ui_tap: 0.03,
  sword: 0.06,
  bite: 0.08,
  hurt: 0.05,
  chop: 0.07,
  mine: 0.07,
  hammer: 0.09,
  foot: 0.09,
  foot_heavy: 0.11,
  foot_hoof: 0.1,
  foot_paw: 0.09,
  chicken: 0.25,
  splash: 0.12,
  lava: 0.4,
  tower: 0.08,
  eat: 0.12,
};

function v(
  osc: Osc,
  f: number,
  dur: number,
  gain: number,
  slide = 1,
  filter = 1800,
  filterType: BiquadFilterType = "lowpass",
  delay = 0,
): Voice {
  return { osc, f, dur, gain, slide, filter, filterType, delay };
}

const RECIPES: Record<SoundId, Voice[]> = {
  ui_tap: [v("sine", 720, 0.05, 0.04, 1.35, 2400)],
  ui_open: [v("triangle", 390, 0.09, 0.045, 1.5, 1600), v("sine", 620, 0.11, 0.03, 1.2, 1800, "lowpass", 0.04)],
  ui_close: [v("triangle", 520, 0.08, 0.04, 0.7, 1400)],
  ui_error: [v("square", 180, 0.14, 0.04, 0.75, 700), v("square", 140, 0.16, 0.03, 0.8, 500, "lowpass", 0.06)],
  ui_save: [v("sine", 660, 0.08, 0.04, 1.25), v("sine", 990, 0.12, 0.035, 1, 2000, "lowpass", 0.07)],
  select: [v("sine", 540, 0.06, 0.035, 1.15, 2000)],
  place_human: [v("triangle", 420, 0.1, 0.05, 1.4), v("sine", 640, 0.12, 0.03, 1.1, 1800, "lowpass", 0.05)],
  place_elf: [v("sine", 760, 0.14, 0.04, 1.3), v("triangle", 1140, 0.16, 0.025, 1.05, 2400, "lowpass", 0.06)],
  place_orc: [v("sawtooth", 160, 0.16, 0.05, 0.7, 500), v("square", 90, 0.12, 0.03, 0.8, 240)],
  place_dwarf: [v("square", 210, 0.08, 0.04, 1.1, 700), v("triangle", 140, 0.14, 0.04, 0.85, 400, "lowpass", 0.04)],
  place_warrior: [v("square", 300, 0.09, 0.04, 0.8, 900), v("sawtooth", 180, 0.12, 0.03, 0.7, 500)],
  place_king: [v("triangle", 330, 0.16, 0.045, 1.25), v("sine", 495, 0.2, 0.03, 1, 1600, "lowpass", 0.05), v("sine", 660, 0.22, 0.02, 1, 1800, "lowpass", 0.1)],
  place_baby: [v("sine", 880, 0.1, 0.035, 1.4, 2400), v("sine", 1320, 0.12, 0.02, 1.1, 2600, "lowpass", 0.06)],
  place_house: [v("triangle", 240, 0.1, 0.05, 1.15, 800), v("noise", 200, 0.08, 0.03, 1, 900)],
  place_farm: [v("triangle", 360, 0.1, 0.04, 1.2, 1000), v("sine", 540, 0.12, 0.025, 1, 1400, "lowpass", 0.05)],
  place_tower: [v("square", 260, 0.12, 0.04, 0.85, 700), v("triangle", 390, 0.14, 0.03, 1.2, 1200, "lowpass", 0.04)],
  place_castle: [v("sawtooth", 150, 0.2, 0.04, 0.7, 420), v("triangle", 300, 0.22, 0.035, 1.3, 900, "lowpass", 0.06)],
  place_wall: [v("noise", 120, 0.09, 0.05, 1, 600), v("square", 110, 0.08, 0.03, 0.8, 300)],
  place_boat: [v("triangle", 280, 0.12, 0.04, 1.1, 800), v("noise", 300, 0.16, 0.03, 1, 500, "lowpass", 0.02)],
  place_fire: [v("noise", 400, 0.18, 0.05, 1, 900, "bandpass"), v("triangle", 180, 0.12, 0.03, 1.4, 600)],
  place_tree: [v("triangle", 220, 0.1, 0.04, 0.8, 700), v("noise", 180, 0.1, 0.025, 1, 500)],
  place_rock: [v("noise", 90, 0.12, 0.06, 1, 350), v("sine", 80, 0.1, 0.04, 0.7, 200)],
  place_bush: [v("sine", 480, 0.07, 0.03, 1.3, 1600), v("noise", 300, 0.06, 0.02, 1, 1200)],
  place_flower: [v("sine", 980, 0.08, 0.03, 1.25, 2400), v("triangle", 1460, 0.1, 0.02, 1, 2600, "lowpass", 0.04)],
  chop: [v("noise", 180, 0.07, 0.06, 1, 700), v("square", 140, 0.05, 0.03, 0.6, 400)],
  mine: [v("noise", 90, 0.08, 0.07, 1, 400), v("sine", 70, 0.1, 0.04, 0.7, 180)],
  hammer: [v("square", 190, 0.06, 0.045, 0.65, 600), v("noise", 150, 0.05, 0.03, 1, 500)],
  build_done: [v("triangle", 440, 0.1, 0.04, 1.2), v("sine", 660, 0.14, 0.03, 1, 1800, "lowpass", 0.06)],
  eat: [v("sine", 310, 0.08, 0.04, 1.4, 900), v("triangle", 200, 0.1, 0.03, 0.8, 500, "lowpass", 0.03)],
  sword: [v("sawtooth", 680, 0.07, 0.035, 0.45, 2200), v("noise", 900, 0.05, 0.04, 1, 2500, "highpass")],
  bite: [v("sawtooth", 150, 0.1, 0.05, 0.5, 500), v("noise", 200, 0.08, 0.04, 1, 800)],
  bow: [v("triangle", 520, 0.09, 0.03, 0.55, 1600), v("sine", 880, 0.06, 0.02, 0.7, 2000)],
  hurt: [v("square", 240, 0.08, 0.04, 0.6, 800)],
  death: [v("triangle", 360, 0.22, 0.05, 0.35, 900), v("sine", 220, 0.28, 0.03, 0.4, 500, "lowpass", 0.04)],
  death_beast: [v("sawtooth", 200, 0.24, 0.05, 0.4, 600), v("noise", 140, 0.2, 0.04, 1, 400)],
  birth: [v("sine", 660, 0.12, 0.04, 1.2), v("sine", 880, 0.16, 0.03, 1.15, 2000, "lowpass", 0.05), v("triangle", 1320, 0.18, 0.02, 1, 2400, "lowpass", 0.1)],
  chicken: [v("square", 980, 0.06, 0.03, 1.6, 2400), v("square", 1400, 0.05, 0.02, 1.2, 2800, "lowpass", 0.07)],
  sheep: [v("sawtooth", 320, 0.16, 0.03, 1.15, 700), v("triangle", 480, 0.12, 0.02, 0.9, 900, "lowpass", 0.06)],
  cow: [v("sawtooth", 130, 0.32, 0.05, 0.72, 380), v("triangle", 98, 0.36, 0.03, 0.8, 240, "lowpass", 0.05)],
  deer: [v("sine", 640, 0.1, 0.03, 1.35, 1800), v("triangle", 420, 0.12, 0.02, 1.1, 1200)],
  wolf: [v("sawtooth", 340, 0.42, 0.045, 1.55, 900), v("triangle", 220, 0.4, 0.03, 1.3, 500, "lowpass", 0.05)],
  bear: [v("sawtooth", 110, 0.28, 0.055, 0.65, 320), v("noise", 80, 0.2, 0.04, 1, 250)],
  dragon: [v("sawtooth", 90, 0.5, 0.05, 1.8, 400), v("square", 70, 0.45, 0.03, 0.6, 220, "lowpass", 0.08)],
  dragon_fire: [v("noise", 500, 0.35, 0.06, 1, 1400, "bandpass"), v("sawtooth", 180, 0.3, 0.04, 0.5, 600)],
  lightning: [v("noise", 2000, 0.22, 0.09, 1, 3200, "highpass"), v("square", 90, 0.18, 0.05, 0.4, 200), v("sine", 1400, 0.05, 0.03, 0.3, 3000, "highpass", 0.01)],
  meteor: [v("noise", 80, 0.45, 0.08, 1, 280), v("sine", 60, 0.5, 0.06, 0.35, 160), v("sawtooth", 140, 0.2, 0.03, 0.4, 400, "lowpass", 0.05)],
  fire: [v("noise", 600, 0.25, 0.05, 1, 1100, "bandpass"), v("triangle", 160, 0.16, 0.03, 1.5, 500)],
  rain: [v("noise", 1000, 0.3, 0.04, 1, 1800, "highpass")],
  blood: [v("sawtooth", 90, 0.28, 0.05, 0.6, 280), v("noise", 200, 0.22, 0.04, 1, 500)],
  quake: [v("sine", 42, 0.6, 0.08, 0.7, 120), v("noise", 70, 0.55, 0.06, 1, 180)],
  tornado: [v("noise", 400, 0.45, 0.05, 1, 700, "bandpass"), v("sawtooth", 160, 0.4, 0.03, 1.4, 500)],
  tsunami: [v("noise", 180, 0.55, 0.07, 1, 400), v("sine", 70, 0.5, 0.04, 0.6, 160, "lowpass", 0.04)],
  plague: [v("triangle", 300, 0.25, 0.035, 0.7, 800), v("sine", 450, 0.3, 0.02, 1.3, 1200, "lowpass", 0.08)],
  freeze: [v("sine", 1400, 0.16, 0.035, 1.4, 3000), v("triangle", 1800, 0.2, 0.02, 1.1, 3200, "lowpass", 0.04)],
  heal: [v("sine", 620, 0.12, 0.04, 1.3), v("sine", 930, 0.16, 0.03, 1.15, 2200, "lowpass", 0.05)],
  bless: [v("triangle", 520, 0.18, 0.04, 1.25), v("sine", 780, 0.22, 0.03, 1.1, 2000, "lowpass", 0.06), v("sine", 1040, 0.24, 0.02, 1, 2400, "lowpass", 0.12)],
  erase: [v("noise", 250, 0.1, 0.05, 1, 700), v("sine", 180, 0.12, 0.03, 0.5, 400)],
  war: [v("sawtooth", 220, 0.22, 0.045, 1.15, 700), v("square", 165, 0.26, 0.035, 1, 400, "lowpass", 0.06), v("triangle", 330, 0.2, 0.025, 1.2, 900, "lowpass", 0.08)],
  peace: [v("sine", 480, 0.16, 0.035, 1.15), v("triangle", 720, 0.2, 0.025, 1, 1600, "lowpass", 0.07)],
  splash: [v("noise", 500, 0.14, 0.045, 1, 900, "bandpass"), v("sine", 240, 0.12, 0.03, 1.6, 700)],
  dawn: [v("sine", 520, 0.2, 0.03, 1.2), v("triangle", 780, 0.24, 0.02, 1.1, 1800, "lowpass", 0.08)],
  night: [v("sine", 280, 0.24, 0.03, 0.75, 700), v("triangle", 180, 0.28, 0.02, 0.8, 400, "lowpass", 0.06)],
  tower: [v("triangle", 740, 0.06, 0.03, 0.5, 2000), v("noise", 1200, 0.04, 0.02, 1, 2500, "highpass")],
  lava: [v("noise", 180, 0.22, 0.04, 1, 350), v("sine", 90, 0.18, 0.03, 1.3, 200)],
  foot: [v("noise", 160, 0.04, 0.03, 1, 400), v("sine", 120, 0.04, 0.02, 0.8, 250)],
  foot_heavy: [v("noise", 90, 0.06, 0.045, 1, 250), v("sine", 60, 0.07, 0.03, 0.7, 140)],
  foot_hoof: [v("square", 180, 0.04, 0.03, 0.7, 500), v("noise", 200, 0.03, 0.02, 1, 600)],
  foot_paw: [v("noise", 220, 0.035, 0.025, 1, 700)],
  roar: [v("sawtooth", 80, 0.55, 0.06, 1.7, 360), v("noise", 100, 0.4, 0.04, 1, 280, "lowpass", 0.02)],
};

export class Soundscape {
  private ctx: AudioContext | null = null;
  private master: GainNode | null = null;
  private musicGain: GainNode | null = null;
  private sfxGain: GainNode | null = null;
  private windGain: GainNode | null = null;
  private rainGain: GainNode | null = null;
  private nightGain: GainNode | null = null;
  private padGain: GainNode | null = null;
  private noiseBuf: AudioBuffer | null = null;
  private last = new Map<SoundId, number>();
  private volumes = { master: 0.8, music: 0.55, sfx: 0.85, mute: false };
  private noteTimer = 1.2;
  private weather: Weather = "clear";
  private night = 0;

  unlock(): void {
    if (this.ctx) {
      if (this.ctx.state === "suspended") void this.ctx.resume();
      return;
    }
    const Ctx = window.AudioContext || (window as unknown as { webkitAudioContext?: typeof AudioContext }).webkitAudioContext;
    if (!Ctx) return;
    const ctx = new Ctx({ latencyHint: "interactive" });
    const master = ctx.createGain();
    const music = ctx.createGain();
    const sfx = ctx.createGain();
    const wind = ctx.createGain();
    const rain = ctx.createGain();
    const night = ctx.createGain();
    const pad = ctx.createGain();
    music.connect(master);
    sfx.connect(master);
    wind.connect(music);
    rain.connect(music);
    night.connect(music);
    pad.connect(music);
    master.connect(ctx.destination);
    this.ctx = ctx;
    this.master = master;
    this.musicGain = music;
    this.sfxGain = sfx;
    this.windGain = wind;
    this.rainGain = rain;
    this.nightGain = night;
    this.padGain = pad;

    const seconds = 2;
    const buffer = ctx.createBuffer(1, ctx.sampleRate * seconds, ctx.sampleRate);
    const data = buffer.getChannelData(0);
    let brown = 0;
    for (let i = 0; i < data.length; i++) {
      const white = Math.random() * 2 - 1;
      brown = (brown + 0.02 * white) / 1.02;
      data[i] = brown * 2.4 + white * 0.15;
    }
    this.noiseBuf = buffer;

    const windSrc = ctx.createBufferSource();
    windSrc.buffer = buffer;
    windSrc.loop = true;
    const windFilter = ctx.createBiquadFilter();
    windFilter.type = "lowpass";
    windFilter.frequency.value = 420;
    windSrc.connect(windFilter);
    windFilter.connect(wind);
    windSrc.start();

    const rainSrc = ctx.createBufferSource();
    rainSrc.buffer = buffer;
    rainSrc.loop = true;
    const rainFilter = ctx.createBiquadFilter();
    rainFilter.type = "highpass";
    rainFilter.frequency.value = 900;
    rainSrc.connect(rainFilter);
    rainFilter.connect(rain);
    rainSrc.start();

    const nightSrc = ctx.createBufferSource();
    nightSrc.buffer = buffer;
    nightSrc.loop = true;
    const nightFilter = ctx.createBiquadFilter();
    nightFilter.type = "bandpass";
    nightFilter.frequency.value = 2800;
    nightFilter.Q.value = 0.7;
    nightSrc.connect(nightFilter);
    nightFilter.connect(night);
    nightSrc.start();

    const padOsc = ctx.createOscillator();
    const pad2 = ctx.createOscillator();
    const padFilter = ctx.createBiquadFilter();
    padOsc.type = "triangle";
    pad2.type = "sine";
    padOsc.frequency.value = 110;
    pad2.frequency.value = 164.8;
    padFilter.type = "lowpass";
    padFilter.frequency.value = 480;
    padOsc.connect(padFilter);
    pad2.connect(padFilter);
    padFilter.connect(this.padGain);
    padOsc.start();
    pad2.start();
    this.padGain.gain.value = 0.03;

    this.applyGains();
    this.applyAmbience();
    void ctx.resume();
  }

  setVolumes(master: number, music: number, sfx: number, mute: boolean): void {
    this.volumes = { master: master / 100, music: music / 100, sfx: sfx / 100, mute };
    this.applyGains();
  }

  setScene(weather: Weather, night: number): void {
    this.weather = weather;
    this.night = night;
    this.applyAmbience();
  }

  suspend(): void {
    if (this.ctx && this.ctx.state === "running") void this.ctx.suspend();
  }

  resume(): void {
    if (this.ctx && this.ctx.state === "suspended") void this.ctx.resume();
  }

  update(dt: number): void {
    if (!this.ctx || !this.musicGain || this.volumes.mute || this.volumes.music <= 0.01) return;
    this.noteTimer -= dt;
    if (this.noteTimer > 0) return;
    this.noteTimer = this.night > 0.6 ? 2.6 : 1.8;
    const scale = this.night > 0.55 ? [0, 3, 5, 7, 10] : [0, 2, 4, 7, 9];
    const step = scale[Math.floor(Math.random() * scale.length)] ?? 0;
    const midi = (this.night > 0.55 ? 57 : 62) + step;
    const freq = 440 * Math.pow(2, (midi - 69) / 12);
    this.tone(freq, 1.3, 0.035);
  }

  play(id: SoundId, pan = 0): void {
    if (!this.ctx || !this.sfxGain || !this.noiseBuf || this.volumes.mute || this.volumes.sfx <= 0.01) return;
    const now = this.ctx.currentTime;
    const gap = GAPS[id] ?? 0.04;
    const prev = this.last.get(id) ?? -10;
    if (now - prev < gap) return;
    this.last.set(id, now);
    const wobble = id.startsWith("ui_") ? 1 : 0.94 + Math.random() * 0.12;
    for (const voice of RECIPES[id]) this.voice(voice, now, Math.max(-1, Math.min(1, pan)), wobble);
  }

  private tone(freq: number, dur: number, gainValue: number): void {
    if (!this.ctx || !this.musicGain) return;
    const ctx = this.ctx;
    const now = ctx.currentTime;
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    const filter = ctx.createBiquadFilter();
    osc.type = "triangle";
    osc.frequency.value = freq;
    filter.type = "lowpass";
    filter.frequency.value = 1400;
    osc.connect(filter);
    filter.connect(gain);
    gain.connect(this.musicGain);
    gain.gain.setValueAtTime(0.0001, now);
    gain.gain.exponentialRampToValueAtTime(gainValue, now + 0.05);
    gain.gain.exponentialRampToValueAtTime(0.0001, now + dur);
    osc.start(now);
    osc.stop(now + dur + 0.02);
  }

  private voice(voice: Voice, now: number, pan: number, wobble: number): void {
    if (!this.ctx || !this.sfxGain || !this.noiseBuf) return;
    const ctx = this.ctx;
    const start = now + voice.delay;
    const gain = ctx.createGain();
    const filter = ctx.createBiquadFilter();
    const panner = ctx.createStereoPanner();
    filter.type = voice.filterType;
    filter.frequency.value = voice.filter;
    panner.pan.value = pan;
    filter.connect(gain);
    gain.connect(panner);
    panner.connect(this.sfxGain);
    gain.gain.setValueAtTime(0.0001, start);
    gain.gain.exponentialRampToValueAtTime(Math.max(0.0002, voice.gain), start + 0.012);
    gain.gain.exponentialRampToValueAtTime(0.0001, start + voice.dur);
    if (voice.osc === "noise") {
      const src = ctx.createBufferSource();
      src.buffer = this.noiseBuf;
      src.playbackRate.value = 0.6 + (voice.f / 2000) * wobble;
      src.connect(filter);
      src.start(start);
      src.stop(start + voice.dur + 0.02);
      src.onended = () => {
        src.disconnect();
        filter.disconnect();
        gain.disconnect();
        panner.disconnect();
      };
      return;
    }
    const osc = ctx.createOscillator();
    osc.type = voice.osc;
    const f0 = Math.max(30, voice.f * wobble);
    const f1 = Math.max(30, f0 * voice.slide);
    osc.frequency.setValueAtTime(f0, start);
    osc.frequency.exponentialRampToValueAtTime(f1, start + voice.dur);
    osc.connect(filter);
    osc.start(start);
    osc.stop(start + voice.dur + 0.02);
    osc.onended = () => {
      osc.disconnect();
      filter.disconnect();
      gain.disconnect();
      panner.disconnect();
    };
  }

  private applyGains(): void {
    if (!this.master || !this.musicGain || !this.sfxGain || !this.ctx) return;
    const m = this.volumes.mute ? 0 : this.volumes.master * this.volumes.master;
    const now = this.ctx.currentTime;
    this.master.gain.setTargetAtTime(m, now, 0.04);
    this.musicGain.gain.setTargetAtTime(this.volumes.music * this.volumes.music, now, 0.05);
    this.sfxGain.gain.setTargetAtTime(this.volumes.sfx * this.volumes.sfx, now, 0.04);
  }

  private applyAmbience(): void {
    if (!this.windGain || !this.rainGain || !this.nightGain || !this.ctx) return;
    const now = this.ctx.currentTime;
    const rain = this.weather === "rain" || this.weather === "storm" || this.weather === "blood" ? 0.22 : 0.001;
    const wind = this.weather === "storm" ? 0.2 : this.weather === "cloudy" ? 0.1 : 0.06;
    this.windGain.gain.setTargetAtTime(wind, now, 0.4);
    this.rainGain.gain.setTargetAtTime(rain, now, 0.4);
    this.nightGain.gain.setTargetAtTime(0.001 + this.night * 0.045, now, 0.5);
  }
}

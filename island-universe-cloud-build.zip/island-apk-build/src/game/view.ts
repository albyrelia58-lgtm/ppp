import * as THREE from "three";
import { buildGeometries } from "./meshes";
import type { WorldSim } from "./sim";
import type { Fx, GraphicsSettings, Weather } from "./types";
import { clamp } from "./types";

const MAX: Record<string, number> = {
  human: 48,
  elf: 40,
  orc: 40,
  dwarf: 36,
  human_w: 24,
  elf_w: 20,
  orc_w: 20,
  dwarf_w: 20,
  human_k: 6,
  elf_k: 6,
  orc_k: 6,
  dwarf_k: 6,
  baby: 36,
  chicken: 36,
  sheep: 24,
  cow: 20,
  deer: 24,
  wolf: 16,
  bear: 10,
  tiger: 12,
  dragon: 4,
  oak: 240,
  pine: 140,
  palm: 90,
  rock: 140,
  bush: 140,
  flower: 120,
  house: 80,
  farm: 40,
  tower: 30,
  castle: 12,
  shrine: 16,
  market: 20,
  wall: 90,
  boat: 16,
  firepit: 28,
  flame: 48,
  flag: 12,
  bird: 10,
  grass: 1100,
};

const BIOME_COLOR: Record<number, [number, number, number]> = {
  0: [0.36, 0.56, 0.28],
  1: [0.79, 0.71, 0.48],
  2: [0.22, 0.4, 0.2],
  3: [0.86, 0.9, 0.93],
  4: [0.28, 0.38, 0.25],
  5: [0.45, 0.44, 0.41],
  6: [0.32, 0.24, 0.18],
  7: [0.42, 0.38, 0.32],
  8: [0.72, 0.24, 0.08],
};

function ensureShaderPrecision(): void {
  const patch = (proto: WebGLRenderingContext) => {
    const orig = proto.getShaderPrecisionFormat;
    proto.getShaderPrecisionFormat = function (shaderType: number, precisionType: number) {
      const found = orig.call(this, shaderType, precisionType);
      if (found) return found;
      const high = precisionType === this.HIGH_FLOAT || precisionType === this.HIGH_INT;
      return { rangeMin: high ? 127 : 31, rangeMax: high ? 127 : 30, precision: high ? 23 : 0 };
    };
  };
  patch(WebGLRenderingContext.prototype);
  patch(WebGL2RenderingContext.prototype);
}

export class WorldView {
  readonly scene = new THREE.Scene();
  readonly camera = new THREE.OrthographicCamera(-36, 36, 36, -36, 0.1, 700);
  readonly renderer: THREE.WebGLRenderer;
  focus = new THREE.Vector3();
  yaw = 0.45;
  dist = 36;
  shake = 0;
  drawCalls = 0;
  private sim: WorldSim | null = null;
  private gfx: GraphicsSettings | null = null;
  private geos: Map<string, THREE.BufferGeometry>;
  private meshes = new Map<string, THREE.InstancedMesh>();
  private readonly lit: THREE.MeshStandardMaterial;
  private readonly soft: THREE.MeshStandardMaterial;
  private readonly flameMat: THREE.MeshStandardMaterial;
  private readonly flagMat: THREE.MeshStandardMaterial;
  private readonly terrainMat: THREE.MeshStandardMaterial;
  private terrain: THREE.Mesh | null = null;
  private water: THREE.Mesh;
  private waterMat: THREE.ShaderMaterial;
  private sky: THREE.Mesh;
  private skyMat: THREE.ShaderMaterial;
  private readonly sun: THREE.DirectionalLight;
  private readonly moon: THREE.DirectionalLight;
  private readonly hemi: THREE.HemisphereLight;
  private readonly ambient: THREE.AmbientLight;
  private readonly lamps: THREE.PointLight[] = [];
  private readonly clouds: THREE.Mesh[] = [];
  private rain: THREE.Points;
  private rainPos: Float32Array;
  private stars: THREE.Points;
  private ring: THREE.Mesh;
  private meteor: THREE.Mesh;
  private bolt: THREE.Line;
  private boom: THREE.Mesh;
  private fx: Fx[] = [];
  private grass: { x: number; z: number; s: number; p: number }[] = [];
  private readonly dummy = new THREE.Object3D();
  private readonly tint = new THREE.Color();
  private readonly tmp = new THREE.Vector3();
  private readonly tmp2 = new THREE.Vector3();
  private readonly raycaster = new THREE.Raycaster();
  private readonly sunDir = new THREE.Vector3();
  private time = 0;
  private builtSpan = -1;

  constructor(private canvas: HTMLCanvasElement) {
    ensureShaderPrecision();
    this.renderer = new THREE.WebGLRenderer({
      canvas,
      antialias: true,
      alpha: false,
      powerPreference: "high-performance",
    });
    this.renderer.outputColorSpace = THREE.SRGBColorSpace;
    this.renderer.toneMapping = THREE.ACESFilmicToneMapping;
    this.renderer.toneMappingExposure = 1.12;
    this.renderer.shadowMap.enabled = true;
    this.renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    this.renderer.setClearColor(0x9eb8c8, 1);

    this.lit = new THREE.MeshStandardMaterial({ vertexColors: true, roughness: 0.68, metalness: 0.03 });
    this.soft = new THREE.MeshStandardMaterial({ vertexColors: true, roughness: 0.86, metalness: 0.0 });
    this.flameMat = new THREE.MeshStandardMaterial({
      vertexColors: true,
      emissive: new THREE.Color(0xff6a2a),
      emissiveIntensity: 1.5,
      roughness: 0.42,
    });
    this.flagMat = new THREE.MeshStandardMaterial({
      vertexColors: true,
      roughness: 0.5,
      metalness: 0.04,
      side: THREE.DoubleSide,
    });
    this.terrainMat = new THREE.MeshStandardMaterial({ vertexColors: true, roughness: 0.94, metalness: 0 });

    this.sun = new THREE.DirectionalLight(0xfff1d4, 2.5);
    this.sun.castShadow = true;
    this.sun.shadow.mapSize.set(2048, 2048);
    this.sun.shadow.bias = -0.0003;
    this.sun.shadow.normalBias = 0.045;
    this.sun.shadow.camera.near = 2;
    this.sun.shadow.camera.far = 180;
    this.scene.add(this.sun, this.sun.target);
    this.moon = new THREE.DirectionalLight(0x9bb6dd, 0.15);
    this.scene.add(this.moon, this.moon.target);
    this.hemi = new THREE.HemisphereLight(0xc5ddf5, 0x6d8a52, 0.55);
    this.ambient = new THREE.AmbientLight(0xb7c4cf, 0.28);
    this.scene.add(this.hemi, this.ambient);
    for (let i = 0; i < 4; i++) {
      const lamp = new THREE.PointLight(0xffb36a, 0, 16, 2);
      this.lamps.push(lamp);
      this.scene.add(lamp);
    }

    this.skyMat = new THREE.ShaderMaterial({
      side: THREE.BackSide,
      depthWrite: false,
      fog: false,
      uniforms: {
        uTop: { value: new THREE.Color("#7eb6e8") },
        uHor: { value: new THREE.Color("#f3e2c4") },
        uBot: { value: new THREE.Color("#d7c3a4") },
        uSun: { value: new THREE.Vector3(0, 1, 0) },
        uStars: { value: 0 },
      },
      vertexShader: `
        varying vec3 vPos;
        void main() {
          vPos = position;
          gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0);
        }
      `,
      fragmentShader: `
        varying vec3 vPos;
        uniform vec3 uTop;
        uniform vec3 uHor;
        uniform vec3 uBot;
        uniform vec3 uSun;
        uniform float uStars;
        void main() {
          vec3 dir = normalize(vPos);
          float h = clamp(dir.y * 0.55 + 0.35, 0.0, 1.0);
          vec3 col = mix(uBot, uHor, smoothstep(0.0, 0.42, h));
          col = mix(col, uTop, smoothstep(0.28, 0.95, h));
          vec3 sun = normalize(uSun);
          float disc = pow(max(dot(dir, sun), 0.0), 90.0);
          float glow = pow(max(dot(dir, sun), 0.0), 8.0);
          col += vec3(1.0, 0.86, 0.62) * disc + vec3(1.0, 0.72, 0.4) * glow * 0.28;
          float star = fract(sin(dot(floor(dir.xy * 180.0), vec2(12.9898, 78.233))) * 43758.5453);
          col += step(0.993, star) * uStars;
          gl_FragColor = vec4(col, 1.0);
        }
      `,
    });
    this.sky = new THREE.Mesh(new THREE.SphereGeometry(360, 24, 16), this.skyMat);
    this.sky.frustumCulled = false;
    this.scene.add(this.sky);

    this.waterMat = new THREE.ShaderMaterial({
      transparent: true,
      depthWrite: false,
      fog: false,
      uniforms: {
        uTime: { value: 0 },
        uDeep: { value: new THREE.Color("#1d5c78") },
        uShallow: { value: new THREE.Color("#6eb8b0") },
        uSun: { value: new THREE.Vector3(0, 1, 0) },
        uBlood: { value: 0 },
      },
      vertexShader: `
        uniform float uTime;
        varying vec3 vW;
        varying vec3 vN;
        varying float vCrest;
        void main() {
          vec3 p = position;
          float w1 = sin(p.x * 0.31 + uTime * 1.35) * 0.09;
          float w2 = sin(p.z * 0.22 - uTime * 0.95 + p.x * 0.07) * 0.07;
          float w3 = sin((p.x + p.z) * 0.55 + uTime * 2.1) * 0.025;
          p.y += w1 + w2 + w3;
          vec4 wp = modelMatrix * vec4(p, 1.0);
          vW = wp.xyz;
          vCrest = w3 * 18.0 + 0.5;
          vN = normalize(vec3(
            -cos(p.x * 0.31 + uTime * 1.35) * 0.09,
            1.0,
            -cos(p.z * 0.22 - uTime * 0.95) * 0.07
          ));
          gl_Position = projectionMatrix * viewMatrix * wp;
        }
      `,
      fragmentShader: `
        uniform vec3 uDeep;
        uniform vec3 uShallow;
        uniform vec3 uSun;
        uniform float uBlood;
        varying vec3 vW;
        varying vec3 vN;
        varying float vCrest;
        void main() {
          vec3 viewDir = normalize(cameraPosition - vW);
          vec3 n = normalize(vN);
          float fres = pow(1.0 - max(dot(viewDir, n), 0.0), 2.2);
          vec3 col = mix(uDeep, uShallow, fres);
          float foam = smoothstep(0.62, 0.95, vCrest);
          col = mix(col, vec3(0.9, 0.96, 0.95), foam * 0.45);
          col = mix(col, vec3(0.45, 0.05, 0.07), uBlood);
          vec3 ref = reflect(-normalize(uSun), n);
          float spec = pow(max(dot(ref, viewDir), 0.0), 64.0);
          float glitter = pow(max(dot(ref, viewDir), 0.0), 12.0);
          col += vec3(1.0, 0.95, 0.82) * spec * 0.7;
          col += vec3(0.75, 0.9, 0.95) * glitter * 0.12;
          gl_FragColor = vec4(col, 0.82);
        }
      `,
    });
    const waterGeo = new THREE.PlaneGeometry(1, 1, 48, 48);
    waterGeo.rotateX(-Math.PI / 2);
    this.water = new THREE.Mesh(waterGeo, this.waterMat);
    this.water.renderOrder = 2;
    this.scene.add(this.water);

    const cloudGeo = new THREE.SphereGeometry(1, 8, 6);
    const cloudMat = new THREE.MeshStandardMaterial({ color: 0xf7f4ee, roughness: 1, transparent: true, opacity: 0.82 });
    for (let i = 0; i < 8; i++) {
      const c = new THREE.Mesh(cloudGeo, cloudMat);
      c.position.set((i - 4) * 18, 16 + (i % 3), (i % 4) * 14 - 20);
      c.scale.set(6 + (i % 3), 1.4, 3.5);
      c.castShadow = false;
      this.clouds.push(c);
      this.scene.add(c);
    }

    const starGeo = new THREE.BufferGeometry();
    const starPos = new Float32Array(180 * 3);
    for (let i = 0; i < 180; i++) {
      const y = 40 + Math.random() * 80;
      const a = Math.random() * Math.PI * 2;
      const r = 40 + Math.random() * 80;
      starPos[i * 3] = Math.cos(a) * r;
      starPos[i * 3 + 1] = y;
      starPos[i * 3 + 2] = Math.sin(a) * r;
    }
    starGeo.setAttribute("position", new THREE.BufferAttribute(starPos, 3));
    this.stars = new THREE.Points(starGeo, new THREE.PointsMaterial({ color: 0xf4f7ff, size: 0.45, transparent: true, opacity: 0 }));
    this.scene.add(this.stars);

    this.rainPos = new Float32Array(700 * 3);
    for (let i = 0; i < 700; i++) {
      this.rainPos[i * 3] = Math.random();
      this.rainPos[i * 3 + 1] = Math.random() * 24;
      this.rainPos[i * 3 + 2] = Math.random();
    }
    const rainGeo = new THREE.BufferGeometry();
    rainGeo.setAttribute("position", new THREE.BufferAttribute(this.rainPos, 3));
    this.rain = new THREE.Points(rainGeo, new THREE.PointsMaterial({ color: 0xd5e4ef, size: 0.08, transparent: true, opacity: 0.7 }));
    this.rain.visible = false;
    this.rain.frustumCulled = false;
    this.scene.add(this.rain);

    this.ring = new THREE.Mesh(
      new THREE.RingGeometry(0.45, 0.62, 20),
      new THREE.MeshBasicMaterial({ color: 0xf4f1e8, side: THREE.DoubleSide, transparent: true, opacity: 0.9 }),
    );
    this.ring.rotation.x = -Math.PI / 2;
    this.ring.visible = false;
    this.scene.add(this.ring);

    this.meteor = new THREE.Mesh(
      new THREE.IcosahedronGeometry(0.55, 0),
      new THREE.MeshStandardMaterial({ color: 0x8a4a32, roughness: 0.6, emissive: 0xff5a1f, emissiveIntensity: 0.6 }),
    );
    this.meteor.visible = false;
    this.meteor.castShadow = true;
    this.scene.add(this.meteor);

    const boltGeo = new THREE.BufferGeometry();
    boltGeo.setAttribute("position", new THREE.BufferAttribute(new Float32Array(8 * 3), 3));
    this.bolt = new THREE.Line(boltGeo, new THREE.LineBasicMaterial({ color: 0xf4f7ff }));
    this.bolt.visible = false;
    this.bolt.frustumCulled = false;
    this.scene.add(this.bolt);

    this.boom = new THREE.Mesh(
      new THREE.RingGeometry(0.4, 0.7, 20),
      new THREE.MeshBasicMaterial({ color: 0xffb15a, side: THREE.DoubleSide, transparent: true, opacity: 0.8 }),
    );
    this.boom.rotation.x = -Math.PI / 2;
    this.boom.visible = false;
    this.scene.add(this.boom);

    this.scene.fog = new THREE.Fog(0xc9d8e4, 40, 150);
    this.geos = buildGeometries();
    this.focus.set(36, 0, 36);
  }

  bind(sim: WorldSim): void {
    this.sim = sim;
    this.focus.set(sim.span * 0.46, 0, sim.span * 0.5);
    if (this.builtSpan !== sim.span) this.makeTerrain(sim);
    this.refreshTerrain();
    this.refreshGrass();
    const span = sim.span + 30;
    this.water.scale.set(span, 1, span);
    this.water.position.set(sim.span / 2, sim.waterLevel, sim.span / 2);
  }

  setGraphics(g: GraphicsSettings): void {
    this.gfx = g;
    const on = g.shadows !== "off";
    this.renderer.shadowMap.enabled = on;
    this.sun.castShadow = on;
    const size = g.shadows === "high" ? 2048 : g.shadows === "medium" ? 1024 : 512;
    if (this.sun.shadow.mapSize.x !== size) {
      this.sun.shadow.mapSize.set(size, size);
      this.sun.shadow.map?.dispose();
      this.sun.shadow.map = null;
    }
    this.resize();
    if (this.sim) this.refreshGrass();
  }

  resize(): void {
    const w = Math.max(1, this.canvas.clientWidth);
    const h = Math.max(1, this.canvas.clientHeight);
    const pr = Math.min(1.75, window.devicePixelRatio || 1) * ((this.gfx?.resolution ?? 100) / 100);
    this.renderer.setPixelRatio(pr);
    this.renderer.setSize(w, h, false);
    // WorldBox-style overhead framing: orthographic projection avoids perspective
    // distortion and keeps the simulation readable on small mobile screens.
    const viewHeight = 72;
    this.camera.zoom = 36 / this.dist;
    const aspect = w / h;
    this.camera.left = (-viewHeight * aspect) / 2;
    this.camera.right = (viewHeight * aspect) / 2;
    this.camera.top = viewHeight / 2;
    this.camera.bottom = -viewHeight / 2;
    this.camera.far = Math.max(700, (this.gfx?.viewDistance ?? 140) * 5);
    this.camera.updateProjectionMatrix();
  }

  spawn(fx: Fx[]): void {
    for (const item of fx) {
      if (this.fx.length > 16) this.fx.shift();
      this.fx.push({ ...item });
      if (item.kind === "meteor" || item.kind === "boom") this.shake = Math.max(this.shake, 0.35);
      if (item.kind === "lightning") this.shake = Math.max(this.shake, 0.12);
    }
  }

  sync(dt: number): void {
    const sim = this.sim;
    if (!sim) return;
    this.time += dt;
    if (sim.terrainDirty) {
      this.refreshTerrain();
      this.refreshGrass();
      sim.terrainDirty = false;
      sim.scatterDirty = false;
    } else if (sim.scatterDirty) {
      this.refreshGrass();
      sim.scatterDirty = false;
    }
    this.updateWorld(dt);
    this.updateCamera(dt);
    this.renderer.render(this.scene, this.camera);
    this.drawCalls = this.renderer.info.render.calls;
  }

  screenToGround(clientX: number, clientY: number): { x: number; z: number } | null {
    const sim = this.sim;
    if (!sim) return null;
    const rect = this.canvas.getBoundingClientRect();
    const ndcX = ((clientX - rect.left) / rect.width) * 2 - 1;
    const ndcY = -(((clientY - rect.top) / rect.height) * 2 - 1);
    this.raycaster.setFromCamera(new THREE.Vector2(ndcX, ndcY), this.camera);
    const origin = this.raycaster.ray.origin;
    const dir = this.raycaster.ray.direction;
    let t = 0;
    for (let i = 0; i < 42; i++) {
      t += i < 8 ? 1.2 : 2.4;
      this.tmp.copy(origin).addScaledVector(dir, t);
      if (this.tmp.y < sim.heightAt(this.tmp.x, this.tmp.z)) {
        let lo = t - (i < 8 ? 1.2 : 2.4);
        let hi = t;
        for (let k = 0; k < 6; k++) {
          const mid = (lo + hi) * 0.5;
          this.tmp2.copy(origin).addScaledVector(dir, mid);
          if (this.tmp2.y < sim.heightAt(this.tmp2.x, this.tmp2.z)) hi = mid;
          else lo = mid;
        }
        this.tmp.copy(origin).addScaledVector(dir, hi);
        return { x: this.tmp.x, z: this.tmp.z };
      }
    }
    if (Math.abs(dir.y) > 0.02) {
      const tPlane = (sim.waterLevel - origin.y) / dir.y;
      if (tPlane > 0) {
        this.tmp.copy(origin).addScaledVector(dir, tPlane);
        return { x: this.tmp.x, z: this.tmp.z };
      }
    }
    return null;
  }

  panOf(x: number, z: number): number {
    const sim = this.sim;
    if (!sim) return 0;
    this.tmp.set(x, sim.heightAt(x, z) + 1, z).project(this.camera);
    return clamp(this.tmp.x, -1, 1);
  }

  drawMinimap(ctx: CanvasRenderingContext2D, w: number, h: number): void {
    const sim = this.sim;
    if (!sim) return;
    ctx.clearRect(0, 0, w, h);
    const step = Math.max(1, Math.floor(sim.span / 48));
    const n = sim.res;
    for (let z = 0; z < sim.span; z += step) {
      for (let x = 0; x < sim.span; x += step) {
        const b = sim.biome[z * n + x] ?? 0;
        const col = BIOME_COLOR[b] ?? BIOME_COLOR[0] ?? [0.3, 0.4, 0.3];
        const hh = sim.height[z * n + x] ?? 0;
        const wet = hh < sim.waterLevel ? 0.55 : 1;
        ctx.fillStyle = `rgb(${Math.floor(col[0] * 255 * wet)},${Math.floor(col[1] * 255 * wet)},${Math.floor(col[2] * 255 * wet)})`;
        ctx.fillRect((x / sim.span) * w, (z / sim.span) * h, (step / sim.span) * w + 1, (step / sim.span) * h + 1);
      }
    }
    for (const k of sim.kingdoms) {
      if (k.fallen) continue;
      ctx.fillStyle = k.color;
      ctx.beginPath();
      ctx.arc((k.hx / sim.span) * w, (k.hz / sim.span) * h, 3.5, 0, Math.PI * 2);
      ctx.fill();
    }
    ctx.fillStyle = "#f4f1e8";
    ctx.fillRect((this.focus.x / sim.span) * w - 1.5, (this.focus.z / sim.span) * h - 1.5, 3, 3);
  }

  dispose(): void {
    this.renderer.setAnimationLoop(null);
    this.renderer.dispose();
    this.renderer.forceContextLoss();
    this.terrain?.geometry.dispose();
    this.geos.forEach((g) => g.dispose());
  }

  private makeTerrain(sim: WorldSim): void {
    if (this.terrain) {
      this.scene.remove(this.terrain);
      this.terrain.geometry.dispose();
    }
    const n = sim.res;
    const geo = new THREE.BufferGeometry();
    const positions = new Float32Array(n * n * 3);
    const colors = new Float32Array(n * n * 3);
    const indices: number[] = [];
    for (let z = 0; z < sim.span; z++) {
      for (let x = 0; x < sim.span; x++) {
        const a = z * n + x;
        const b = a + 1;
        const c = a + n;
        const d = c + 1;
        indices.push(a, c, b, b, c, d);
      }
    }
    geo.setAttribute("position", new THREE.BufferAttribute(positions, 3));
    geo.setAttribute("color", new THREE.BufferAttribute(colors, 3));
    geo.setIndex(indices);
    this.terrain = new THREE.Mesh(geo, this.terrainMat);
    this.terrain.receiveShadow = true;
    this.terrain.castShadow = false;
    this.scene.add(this.terrain);
    this.builtSpan = sim.span;
  }

  private refreshTerrain(): void {
    const sim = this.sim;
    const mesh = this.terrain;
    if (!sim || !mesh) return;
    const pos = mesh.geometry.getAttribute("position") as THREE.BufferAttribute;
    const col = mesh.geometry.getAttribute("color") as THREE.BufferAttribute;
    const n = sim.res;
    const season = Math.floor(sim.day / 2) % 4;
    for (let z = 0; z < n; z++) {
      for (let x = 0; x < n; x++) {
        const i = z * n + x;
        const h = sim.height[i] ?? 0;
        pos.setXYZ(i, x, h, z);
        const biome = sim.biome[i] ?? 0;
        const base = BIOME_COLOR[biome] ?? BIOME_COLOR[0] ?? [0.3, 0.4, 0.3];
        let r = base[0];
        let g = base[1];
        let b = base[2];
        const nse = ((x * 13 + z * 7) % 11) / 11;
        r += (nse - 0.5) * 0.05;
        g += (nse - 0.5) * 0.06;
        if (biome === 0 || biome === 2) {
          if (season === 1) {
            r += 0.06;
            g -= 0.02;
          } else if (season === 3) {
            r -= 0.03;
            b += 0.05;
          }
        }
        const left = sim.height[i - 1] ?? h;
        const right = sim.height[i + 1] ?? h;
        const up = sim.height[i - n] ?? h;
        const down = sim.height[i + n] ?? h;
        const avg = (left + right + up + down) * 0.25;
        const ao = clamp(0.7 + (h - avg) * 0.65, 0.42, 1.18);
        const slope = Math.hypot(right - left, down - up);
        if (slope > 0.85 && biome !== 1 && biome !== 3 && biome !== 8) {
          const rock = clamp((slope - 0.85) / 1.2, 0, 0.7);
          r = r * (1 - rock) + 0.45 * rock;
          g = g * (1 - rock) + 0.44 * rock;
          b = b * (1 - rock) + 0.41 * rock;
        }
        if (h < sim.waterLevel + 0.15) {
          r = r * 0.65 + 0.1;
          g = g * 0.7 + 0.18;
          b = b * 0.55 + 0.28;
        }
        col.setXYZ(i, r * ao, g * ao, b * ao);
      }
    }
    pos.needsUpdate = true;
    col.needsUpdate = true;
    mesh.geometry.computeVertexNormals();
  }

  private refreshGrass(): void {
    const sim = this.sim;
    if (!sim) return;
    const frac = (this.gfx?.vegetation ?? 100) / 100;
    const target = Math.floor(780 * frac);
    this.grass = [];
    const span = sim.span;
    for (let i = 0; i < target * 3 && this.grass.length < target; i++) {
      const x = 1 + ((i * 47) % (span - 2)) + ((i * 13) % 10) * 0.08;
      const z = 1 + ((i * 29) % (span - 2)) + ((i * 17) % 10) * 0.08;
      const b = sim.biomeAt(x, z);
      const h = sim.heightAt(x, z);
      if (h < sim.waterLevel + 0.2) continue;
      if (b !== 0 && b !== 2 && b !== 4) continue;
      this.grass.push({ x, z, s: 0.7 + ((i * 17) % 10) / 18, p: (i % 12) * 0.4 });
    }
  }

  private mesh(key: string, cast: boolean, material?: THREE.Material): THREE.InstancedMesh | null {
    let mesh = this.meshes.get(key);
    if (mesh) return mesh;
    const g = this.geos.get(key);
    if (!g) return null;
    const max = MAX[key] ?? 32;
    mesh = new THREE.InstancedMesh(g, material ?? this.lit, max);
    mesh.count = 0;
    mesh.castShadow = cast;
    mesh.receiveShadow = true;
    mesh.frustumCulled = false;
    mesh.instanceMatrix.setUsage(THREE.DynamicDrawUsage);
    this.scene.add(mesh);
    this.meshes.set(key, mesh);
    return mesh;
  }

  private begin(): Map<string, number> {
    const counts = new Map<string, number>();
    for (const [key, mesh] of this.meshes) {
      counts.set(key, 0);
      mesh.count = 0;
    }
    return counts;
  }

  private push(key: string, x: number, y: number, z: number, yaw: number, scale: number, sway: number, color: THREE.Color | null, cast = true, material?: THREE.Material): void {
    const mesh = this.mesh(key, cast, material);
    if (!mesh) return;
    const i = mesh.count;
    if (i >= mesh.instanceMatrix.count) return;
    const bob = sway === 0 ? 0 : Math.abs(Math.sin(this.time * 7 + sway)) * 0.045;
    this.dummy.position.set(x, y + bob, z);
    this.dummy.rotation.set(0, yaw + Math.PI, Math.sin(this.time * 1.4 + sway) * (sway === 0 ? 0 : 0.05));
    this.dummy.scale.setScalar(Math.max(0.001, scale));
    this.dummy.updateMatrix();
    mesh.setMatrixAt(i, this.dummy.matrix);
    if (color) mesh.setColorAt(i, color);
    mesh.count = i + 1;
  }

  private finish(): void {
    for (const mesh of this.meshes.values()) {
      mesh.instanceMatrix.needsUpdate = true;
      if (mesh.instanceColor) mesh.instanceColor.needsUpdate = true;
      mesh.visible = mesh.count > 0;
    }
  }

  private updateWorld(dt: number): void {
    const sim = this.sim;
    if (!sim) return;
    this.begin();
    const veg = (this.gfx?.vegetation ?? 100) / 100;
    for (const u of sim.units) {
      if (!u.alive && u.fade <= 0) continue;
      const key = u.kind === "animal" ? u.race : u.role === "baby" ? "baby" : u.role === "warrior" ? `${u.race}_w` : u.role === "king" ? `${u.race}_k` : u.race;
      const h = sim.heightAt(u.x, u.z);
      const fly = u.race === "dragon" ? 2.5 + Math.sin(this.time * 2 + u.phase) * 0.35 : 0;
      let tint: THREE.Color | null = null;
      if (u.hit > 0) this.tint.setRGB(1, 0.45, 0.4);
      else if (u.burn > 0.2) this.tint.setRGB(1, 0.5, 0.28);
      else if (u.frozen > 0) this.tint.setRGB(0.72, 0.86, 1);
      else if (u.plague > 0) this.tint.setRGB(0.62, 0.9, 0.5);
      else this.tint.setRGB(1, 1, 1);
      tint = this.tint;
      const scale = (u.alive ? 1 : u.fade) * (u.role === "baby" ? 0.82 : 1);
      this.push(key, u.x, h + fly, u.z, u.yaw, scale, u.moving ? u.phase : 0, tint);
    }
    for (const b of sim.buildings) {
      if (!b.alive) continue;
      const h = b.type === "boat" ? sim.waterLevel - 0.05 : sim.heightAt(b.x, b.z);
      this.push(b.type, b.x, h, b.z, b.yaw, 1, 0, null);
    }
    for (const t of sim.trees) {
      if (!t.alive) continue;
      if (veg < 0.99 && t.id % 100 > veg * 100) continue;
      const h = sim.heightAt(t.x, t.z);
      this.push(t.kind, t.x, h, t.z, t.yaw, t.scale * (t.burn > 0 ? 0.92 : 1), t.phase + 2, null);
    }
    for (const r of sim.rocks) {
      if (!r.alive) continue;
      this.push("rock", r.x, sim.heightAt(r.x, r.z), r.z, r.phase, r.scale, 0, null);
    }
    for (const p of sim.props) {
      if (!p.alive) continue;
      this.push(p.kind, p.x, sim.heightAt(p.x, p.z), p.z, p.yaw, p.scale, p.phase, null, false);
    }
    for (const g of this.grass) {
      this.push("grass", g.x, sim.heightAt(g.x, g.z), g.z, g.p, g.s, g.p, null, false, this.soft);
    }
    let fi = 0;
    for (const b of sim.buildings) {
      if (!b.alive || b.type !== "firepit") continue;
      const pulse = 0.85 + Math.sin(this.time * 10 + fi) * 0.18;
      this.push("flame", b.x, sim.heightAt(b.x, b.z) + 0.05, b.z, this.time * 2, pulse, 0, null, false, this.flameMat);
      fi++;
    }
    for (const b of sim.buildings) {
      if (!b.alive || b.type !== "shrine") continue;
      const pulse = 0.45 + Math.sin(this.time * 3 + b.id) * 0.08;
      this.push("flame", b.x, sim.heightAt(b.x, b.z) + 1.85, b.z, 0, pulse, 0, null, false, this.flameMat);
    }
    for (const k of sim.kingdoms) {
      if (k.fallen) continue;
      this.tint.set(k.color);
      this.push("flag", k.hx, sim.heightAt(k.hx, k.hz) + 3.15, k.hz, Math.sin(this.time * 2 + k.id) * 0.4, 1, 0, this.tint, false, this.flagMat);
    }
    for (let i = 0; i < 7; i++) {
      const a = this.time * 0.42 + i * 0.9;
      const rad = 8 + (i % 4) * 3.2;
      const x = this.focus.x + Math.cos(a) * rad;
      const z = this.focus.z + Math.sin(a * 0.85) * rad * 0.62;
      const y = sim.heightAt(x, z) + 7.5 + (i % 3) * 1.4 + Math.sin(this.time * 3 + i) * 0.35;
      this.push("bird", x, y, z, -a, 1, i + 1, null, false);
    }
    this.finish();

    if (sim.selected) {
      let sx = 0;
      let sz = 0;
      let ok = false;
      if (sim.selected.kind === "unit") {
        const u = sim.units.find((n) => n.id === sim.selected?.id && n.alive);
        if (u) {
          sx = u.x;
          sz = u.z;
          ok = true;
        }
      } else {
        const b = sim.buildings.find((n) => n.id === sim.selected?.id && n.alive);
        if (b) {
          sx = b.x;
          sz = b.z;
          ok = true;
        }
      }
      this.ring.visible = ok;
      if (ok) this.ring.position.set(sx, sim.heightAt(sx, sz) + 0.08, sz);
    } else this.ring.visible = false;

    this.updateFx(dt, sim);
    this.updateWeather(dt, sim);
  }

  private updateFx(dt: number, sim: WorldSim): void {
    let boltOn = false;
    let meteorOn = false;
    let boomOn = false;
    for (const f of this.fx) f.life -= dt;
    this.fx = this.fx.filter((f) => f.life > 0);
    for (const f of this.fx) {
      if (f.kind === "lightning" || f.kind === "bolt") {
        const attr = this.bolt.geometry.getAttribute("position") as THREE.BufferAttribute;
        const x1 = f.x2 ?? f.x + 1.5;
        const y1 = f.y2 ?? f.y + 1;
        const z1 = f.z2 ?? f.z;
        const top = f.kind === "lightning" ? f.y + 18 : f.y;
        attr.setXYZ(0, f.kind === "lightning" ? f.x : f.x, top, f.kind === "lightning" ? f.z : f.z);
        attr.setXYZ(1, f.x + 0.6, (top + y1) * 0.7, f.z - 0.4);
        attr.setXYZ(2, x1, y1, z1);
        attr.needsUpdate = true;
        (this.bolt.material as THREE.LineBasicMaterial).color.set(f.kind === "lightning" ? 0xf7fbff : 0xffe2a8);
        boltOn = true;
      } else if (f.kind === "meteor") {
        const t = 1 - f.life / f.max;
        this.meteor.visible = true;
        this.meteor.position.set(f.x + (1 - t) * 6, f.y + (1 - t) * 26, f.z - (1 - t) * 4);
        meteorOn = true;
      } else if (f.kind === "boom" || f.kind === "heal" || f.kind === "splash") {
        const t = 1 - f.life / f.max;
        this.boom.visible = true;
        this.boom.position.set(f.x, sim.heightAt(f.x, f.z) + 0.15, f.z);
        const s = 0.6 + t * (f.kind === "heal" ? 4 : 7);
        this.boom.scale.setScalar(s);
        (this.boom.material as THREE.MeshBasicMaterial).opacity = 0.75 * (1 - t);
        (this.boom.material as THREE.MeshBasicMaterial).color.set(f.kind === "heal" ? 0xb7e0c2 : f.kind === "splash" ? 0xc5e4ef : 0xffb15a);
        boomOn = true;
      }
    }
    this.bolt.visible = boltOn;
    if (!meteorOn) this.meteor.visible = false;
    if (!boomOn) this.boom.visible = false;
    if (sim.tornado) {
      this.boom.visible = true;
      const t = sim.tornado;
      this.boom.position.set(t.x, sim.heightAt(t.x, t.z) + 0.2, t.z);
      this.boom.scale.setScalar(3.2 + Math.sin(this.time * 8) * 0.3);
      (this.boom.material as THREE.MeshBasicMaterial).opacity = 0.55;
      (this.boom.material as THREE.MeshBasicMaterial).color.set(0xd5ddd4);
    }
  }

  private updateWeather(dt: number, sim: WorldSim): void {
    const hour = sim.time;
    const elev = Math.sin(((hour - 6) / 12) * Math.PI);
    const day = clamp(elev, 0, 1);
    const dusk = Math.exp(-((hour - 6.3) ** 2) / 2.2) + Math.exp(-((hour - 18.2) ** 2) / 2.4);
    const night = 1 - day;
    const storm = sim.weather === "storm" ? 0.35 : sim.weather === "cloudy" ? 0.18 : 0;
    const top = new THREE.Color("#16324d").lerp(new THREE.Color("#79b4e4"), day);
    top.lerp(new THREE.Color("#c47a58"), dusk * 0.45);
    const hor = new THREE.Color("#1a2740").lerp(new THREE.Color("#f2d7b0"), day);
    hor.lerp(new THREE.Color("#e38a55"), dusk * 0.7);
    if (storm > 0) {
      top.lerp(new THREE.Color("#6d7c88"), storm);
      hor.lerp(new THREE.Color("#8a939a"), storm);
    }
    (this.skyMat.uniforms.uTop?.value as THREE.Color).copy(top);
    (this.skyMat.uniforms.uHor?.value as THREE.Color).copy(hor);
    (this.skyMat.uniforms.uBot?.value as THREE.Color).copy(hor);
    const az = ((hour - 6) / 24) * Math.PI * 2;
    this.sunDir.set(Math.cos(az), Math.max(0.05, elev), Math.sin(az));
    (this.skyMat.uniforms.uSun?.value as THREE.Vector3).copy(this.sunDir);
    (this.skyMat.uniforms.uStars as { value: number }).value = night * 0.85;
    (this.stars.material as THREE.PointsMaterial).opacity = night * 0.9;
    this.stars.position.copy(this.camera.position).setY(0);

    this.sun.color.set(dusk > 0.2 ? "#ffb27a" : "#fff2d2");
    this.sun.intensity = 0.18 + day * 2.55 * (1 - storm * 0.45);
    this.moon.intensity = night * 0.38;
    this.hemi.intensity = 0.22 + day * 0.42;
    this.hemi.color.set(night > 0.5 ? "#8ea4c4" : "#d5e6f6");
    this.hemi.groundColor.set(night > 0.5 ? "#1d2a22" : "#6e8a58");
    this.ambient.intensity = 0.16 + night * 0.12 + day * 0.08;
    this.renderer.toneMappingExposure = 0.82 + day * 0.32;
    const fog = this.scene.fog as THREE.Fog;
    fog.color.copy(hor);
    const view = this.gfx?.viewDistance ?? 140;
    fog.near = 18 + day * 10;
    fog.far = view * (0.75 + day * 0.25);

    this.sun.position.set(this.focus.x + this.sunDir.x * 70, 12 + this.sunDir.y * 60, this.focus.z + this.sunDir.z * 48);
    this.sun.target.position.set(this.focus.x, 0, this.focus.z);
    this.moon.position.set(this.focus.x - this.sunDir.x * 50, 30, this.focus.z - this.sunDir.z * 40);
    this.moon.target.position.copy(this.sun.target.position);
    const span = Math.max(22, this.dist * 0.85);
    const cam = this.sun.shadow.camera;
    cam.left = -span;
    cam.right = span;
    cam.top = span;
    cam.bottom = -span;
    cam.updateProjectionMatrix();

    this.water.position.y = sim.waterLevel;
    (this.waterMat.uniforms.uTime as { value: number }).value = this.time;
    (this.waterMat.uniforms.uSun?.value as THREE.Vector3).copy(this.sunDir);
    (this.waterMat.uniforms.uBlood as { value: number }).value = sim.weather === "blood" ? 0.55 : 0;
    if (sim.weather === "blood") {
      (this.waterMat.uniforms.uDeep?.value as THREE.Color).set("#6a2430");
      (this.waterMat.uniforms.uShallow?.value as THREE.Color).set("#c46a72");
    } else {
      (this.waterMat.uniforms.uDeep?.value as THREE.Color).set(night > 0.6 ? "#0e2436" : "#1c5d78");
      (this.waterMat.uniforms.uShallow?.value as THREE.Color).set(night > 0.6 ? "#24506a" : "#79c0b4");
    }

    const wet = sim.weather === "rain" || sim.weather === "storm" || sim.weather === "blood";
    this.rain.visible = wet;
    if (wet) {
      const attr = this.rain.geometry.getAttribute("position") as THREE.BufferAttribute;
      const spanR = Math.max(18, this.dist);
      for (let i = 0; i < 700; i++) {
        let y = (this.rainPos[i * 3 + 1] ?? 0) - dt * (sim.weather === "storm" ? 38 : 26);
        if (y < 0) y = 22;
        this.rainPos[i * 3 + 1] = y;
        const rx = this.focus.x + ((this.rainPos[i * 3] ?? 0) - 0.5) * spanR * 1.6;
        const rz = this.focus.z + ((this.rainPos[i * 3 + 2] ?? 0) - 0.5) * spanR * 1.6;
        attr.setXYZ(i, rx, y + sim.heightAt(rx, rz), rz);
      }
      attr.needsUpdate = true;
      (this.rain.material as THREE.PointsMaterial).color.set(sim.weather === "blood" ? 0x8a2430 : 0xd5e7f2);
    }

    for (let i = 0; i < this.clouds.length; i++) {
      const c = this.clouds[i];
      if (!c) continue;
      c.position.x += dt * (1.2 + i * 0.15);
      if (c.position.x > sim.span + 30) c.position.x = -20;
      c.position.y = 14 + day * 4 + (sim.weather === "storm" ? -4 : 0);
      (c.material as THREE.MeshStandardMaterial).opacity = sim.weather === "clear" ? 0.72 : 0.9;
    }

    const lights: { x: number; z: number; hot: number }[] = [];
    for (const b of sim.buildings) {
      if (!b.alive) continue;
      if (b.type === "firepit") lights.push({ x: b.x, z: b.z, hot: 2.2 });
      else if (b.type === "shrine") lights.push({ x: b.x, z: b.z, hot: 1.35 });
      else if (night > 0.35 && (b.type === "house" || b.type === "castle" || b.type === "tower" || b.type === "market")) lights.push({ x: b.x, z: b.z, hot: 0.8 });
    }
    lights.sort((a, b) => Math.hypot(a.x - this.focus.x, a.z - this.focus.z) - Math.hypot(b.x - this.focus.x, b.z - this.focus.z));
    for (let i = 0; i < this.lamps.length; i++) {
      const lamp = this.lamps[i];
      const src = lights[i];
      if (!lamp) continue;
      if (!src) {
        lamp.intensity = 0;
        continue;
      }
      lamp.position.set(src.x, sim.heightAt(src.x, src.z) + 1.5, src.z);
      lamp.intensity = src.hot * (src.hot > 1.5 ? 1 : 0.35 + night);
      lamp.color.set(src.hot > 1.5 ? 0xff9a4a : 0xffd7a4);
    }
    if (sim.quake > 0) this.shake = Math.max(this.shake, 0.18);
  }

  private updateCamera(dt: number): void {
    const sim = this.sim;
    if (!sim) return;
    this.shake = Math.max(0, this.shake - dt * 1.4);
    const gy = sim.heightAt(this.focus.x, this.focus.z);
    const fx = -Math.sin(this.yaw);
    const fz = -Math.cos(this.yaw);
    const lift = Math.max(26, this.dist * 0.95);
    const back = lift * 0.82;
    this.camera.zoom = 36 / this.dist;
    this.camera.updateProjectionMatrix();
    this.camera.up.set(0, 1, 0);
    this.camera.position.set(
      this.focus.x - fx * back + Math.sin(this.time * 42) * this.shake,
      gy + lift * 0.7 + Math.cos(this.time * 37) * this.shake * 0.35,
      this.focus.z - fz * back,
    );
    this.camera.lookAt(this.focus.x, gy + 0.35, this.focus.z);
    this.sky.position.copy(this.camera.position);
  }
}

import {
  SIZE_SPAN,
  type AnimalKind,
  type BuildType,
  type Fx,
  type Inspect,
  type Intent,
  type LogItem,
  type Race,
  type Role,
  type SfxEvent,
  type SizeId,
  type SoundId,
  type Tool,
  type TreeKind,
  type Weather,
  type WorldOptions,
  clamp,
} from "./types";

export interface Unit {
  id: number;
  kind: "person" | "animal";
  race: Race | AnimalKind;
  role: Role;
  name: string;
  kingdom: number;
  x: number;
  z: number;
  yaw: number;
  hp: number;
  maxHp: number;
  hunger: number;
  age: number;
  alive: boolean;
  fade: number;
  intent: Intent;
  target: number;
  tx: number;
  tz: number;
  timer: number;
  cool: number;
  work: number;
  frozen: number;
  burn: number;
  plague: number;
  hit: number;
  phase: number;
  moving: boolean;
  build: BuildType | null;
}

export interface Building {
  id: number;
  type: BuildType;
  x: number;
  z: number;
  yaw: number;
  hp: number;
  maxHp: number;
  kingdom: number;
  alive: boolean;
  cool: number;
}

export interface Tree {
  id: number;
  kind: TreeKind;
  x: number;
  z: number;
  hp: number;
  maxHp: number;
  alive: boolean;
  burn: number;
  regrow: number;
  scale: number;
  yaw: number;
  phase: number;
}

export interface Rock {
  id: number;
  x: number;
  z: number;
  hp: number;
  alive: boolean;
  scale: number;
  phase: number;
}

export interface Prop {
  id: number;
  kind: "bush" | "flower";
  x: number;
  z: number;
  alive: boolean;
  scale: number;
  yaw: number;
  phase: number;
}

export interface Kingdom {
  id: number;
  race: Race;
  name: string;
  color: string;
  hx: number;
  hz: number;
  food: number;
  wood: number;
  stone: number;
  wars: number[];
  boost: number;
  breed: number;
  fallen: boolean;
}

export interface Tornado {
  x: number;
  z: number;
  life: number;
  vx: number;
  vz: number;
}

interface SaveBlob {
  version: 1;
  id: string;
  name: string;
  savedAt: number;
  size: SizeId;
  seed: number;
  span: number;
  time: number;
  day: number;
  year: number;
  weather: Weather;
  weatherT: number;
  waterLevel: number;
  nextId: number;
  height: string;
  biome: string;
  units: Unit[];
  buildings: Building[];
  trees: Tree[];
  rocks: Rock[];
  props: Prop[];
  kingdoms: Kingdom[];
  births: number;
  deaths: number;
}

const PEOPLE = ["Sari", "Bima", "Laras", "Dimas", "Wulan", "Guntur", "Maya", "Raka", "Intan", "Bayu", "Nadine", "Farid", "Cahya", "Putri", "Arka", "Dewi", "Yoga", "Sinta", "Hari", "Lestari", "Jaka", "Ayu", "Rama", "Diah", "Eka", "Nisa", "Tegar", "Mega", "Ilham", "Kirana"];
const KNAMES: Record<Race, string[]> = {
  human: ["Arun Pesisir", "Desa Fajar", "Negeri Sawah", "Kota Terang", "Kampung Daun"],
  elf: ["Rimba Sunyi", "Hutan Embun", "Dahan Putih", "Cahaya Lumut", "Sudut Hijau"],
  orc: ["Gua Merah", "Suku Batu", "Lembah Arang", "Taring Hitam", "Bukit Debu"],
  dwarf: ["Balai Palu", "Tambang Dalam", "Puncak Logam", "Terowongan Raja", "Dinding Besi"],
};
const RCOLORS: Record<Race, string[]> = {
  human: ["#3e6f9a", "#2f5d86", "#4e7eaa"],
  elf: ["#2f7a52", "#246846", "#3c8d62"],
  orc: ["#8d4d32", "#6f3c28", "#a05a3a"],
  dwarf: ["#8d3d3d", "#6e3030", "#a35248"],
};
const BIOME = { grass: 0, sand: 1, forest: 2, snow: 3, swamp: 4, rock: 5, scorch: 6, road: 7, lava: 8 };

function mulberry32(seed: number): () => number {
  let a = seed >>> 0;
  return () => {
    a |= 0;
    a = (a + 0x6d2b79f5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

function hash(ix: number, iz: number, seed: number): number {
  let n = Math.imul(ix, 374761393) + Math.imul(iz, 668265263) + Math.imul(seed, 1442695041);
  n = Math.imul(n ^ (n >>> 13), 1274126177);
  return ((n ^ (n >>> 16)) >>> 0) / 4294967296;
}

function noise(x: number, z: number, seed: number): number {
  const x0 = Math.floor(x);
  const z0 = Math.floor(z);
  const fx = x - x0;
  const fz = z - z0;
  const sx = fx * fx * (3 - 2 * fx);
  const sz = fz * fz * (3 - 2 * fz);
  const a = hash(x0, z0, seed);
  const b = hash(x0 + 1, z0, seed);
  const c = hash(x0, z0 + 1, seed);
  const d = hash(x0 + 1, z0 + 1, seed);
  return a + (b - a) * sx + (c - a) * sz + (a - b - c + d) * sx * sz;
}

function fbm(x: number, z: number, seed: number): number {
  let v = 0;
  let a = 0.5;
  let f = 1;
  for (let i = 0; i < 5; i++) {
    v += a * noise(x * f, z * f, seed + i * 19);
    a *= 0.5;
    f *= 2;
  }
  return v;
}

function b64(bytes: Uint8Array): string {
  let s = "";
  const chunk = 4096;
  for (let i = 0; i < bytes.length; i += chunk) {
    const slice = bytes.subarray(i, i + chunk);
    let part = "";
    for (let j = 0; j < slice.length; j++) part += String.fromCharCode(slice[j] ?? 0);
    s += part;
  }
  return btoa(s);
}

function unb64(s: string): Uint8Array {
  const bin = atob(s);
  const out = new Uint8Array(bin.length);
  for (let i = 0; i < bin.length; i++) out[i] = bin.charCodeAt(i);
  return out;
}

const LIMITS = { unit: 160, tree: 340, rock: 120, prop: 220, building: 140 };

export class WorldSim {
  readonly id: string;
  name: string;
  readonly sizeId: SizeId;
  readonly seed: number;
  readonly span: number;
  readonly res: number;
  readonly height: Float32Array;
  readonly biome: Uint8Array;
  waterBase = 1.72;
  waterLevel = 1.72;
  time = 8.2;
  day = 1;
  year = 1;
  weather: Weather = "clear";
  weatherT = 48;
  tsunami = 0;
  quake = 0;
  tornado: Tornado | null = null;
  units: Unit[] = [];
  buildings: Building[] = [];
  trees: Tree[] = [];
  rocks: Rock[] = [];
  props: Prop[] = [];
  kingdoms: Kingdom[] = [];
  selected: { kind: "unit" | "building"; id: number } | null = null;
  terrainDirty = true;
  scatterDirty = true;
  births = 0;
  deaths = 0;
  raceBrush: Race = "human";
  sfxQ: SfxEvent[] = [];
  fxQ: Fx[] = [];
  log: LogItem[] = [];
  toast: string | null = null;
  private nextId = 1;
  private rand: () => number;
  private warT = 2;
  private compact = false;
  private dawnSent = false;
  private eventT = 20;

  constructor(opts: WorldOptions & { id?: string }) {
    this.id = opts.id ?? `w-${opts.seed.toString(36)}-${Math.floor(Math.random() * 1e6).toString(36)}`;
    this.name = opts.name;
    this.sizeId = opts.size;
    this.seed = opts.seed >>> 0;
    this.span = SIZE_SPAN[opts.size];
    this.res = this.span + 1;
    this.height = new Float32Array(this.res * this.res);
    this.biome = new Uint8Array(this.res * this.res);
    this.rand = mulberry32(this.seed ^ 0x9e3779b9);
    this.generate();
    this.scatter();
    this.seedVillages();
  }

  static fromSave(raw: string): WorldSim | null {
    try {
      const data = JSON.parse(raw) as SaveBlob;
      if (data.version !== 1 || !data.height) return null;
      const sim = new WorldSim({ name: data.name, size: data.size, seed: data.seed, id: data.id });
      const hBytes = unb64(data.height);
      const bBytes = unb64(data.biome);
      if (hBytes.byteLength !== sim.height.byteLength || bBytes.length !== sim.biome.length) return null;
      sim.height.set(new Float32Array(hBytes.buffer, hBytes.byteOffset, sim.height.length));
      sim.biome.set(bBytes);
      sim.time = data.time;
      sim.day = data.day;
      sim.year = data.year;
      sim.weather = data.weather;
      sim.weatherT = data.weatherT;
      sim.waterLevel = data.waterLevel;
      sim.nextId = data.nextId;
      sim.units = data.units;
      sim.buildings = data.buildings;
      sim.trees = data.trees;
      sim.rocks = data.rocks;
      sim.props = data.props;
      sim.kingdoms = data.kingdoms;
      sim.births = data.births;
      sim.deaths = data.deaths;
      sim.terrainDirty = true;
      sim.scatterDirty = true;
      return sim;
    } catch {
      return null;
    }
  }

  serialize(): string {
    const blob: SaveBlob = {
      version: 1,
      id: this.id,
      name: this.name,
      savedAt: Date.now(),
      size: this.sizeId,
      seed: this.seed,
      span: this.span,
      time: this.time,
      day: this.day,
      year: this.year,
      weather: this.weather,
      weatherT: this.weatherT,
      waterLevel: this.waterLevel,
      nextId: this.nextId,
      height: b64(new Uint8Array(this.height.buffer, this.height.byteOffset, this.height.byteLength)),
      biome: b64(this.biome),
      units: this.units.filter((u) => u.alive),
      buildings: this.buildings.filter((b) => b.alive),
      trees: this.trees,
      rocks: this.rocks.filter((r) => r.alive),
      props: this.props.filter((p) => p.alive),
      kingdoms: this.kingdoms,
      births: this.births,
      deaths: this.deaths,
    };
    return JSON.stringify(blob);
  }

  heightAt(x: number, z: number): number {
    const max = this.span;
    const xc = clamp(x, 0, max);
    const zc = clamp(z, 0, max);
    const x0 = Math.floor(xc);
    const z0 = Math.floor(zc);
    const x1 = Math.min(max, x0 + 1);
    const z1 = Math.min(max, z0 + 1);
    const tx = xc - x0;
    const tz = zc - z0;
    const n = this.res;
    const h00 = this.height[z0 * n + x0] ?? 0;
    const h10 = this.height[z0 * n + x1] ?? 0;
    const h01 = this.height[z1 * n + x0] ?? 0;
    const h11 = this.height[z1 * n + x1] ?? 0;
    return h00 + (h10 - h00) * tx + (h01 + (h11 - h01) * tx - (h00 + (h10 - h00) * tx)) * tz;
  }

  biomeAt(x: number, z: number): number {
    const xi = clamp(Math.round(x), 0, this.span);
    const zi = clamp(Math.round(z), 0, this.span);
    return this.biome[zi * this.res + xi] ?? 0;
  }

  popCount(): number {
    let n = 0;
    for (const u of this.units) if (u.alive && u.kind === "person") n++;
    return n;
  }

  tick(dt: number): void {
    dt = Math.min(dt, 0.45);
    const prev = this.time;
    this.time = (this.time + dt * (24 / 96)) % 24;
    if (prev > 20 && this.time < 6) {
      this.day += 1;
      if (this.day % 8 === 0) this.year += 1;
    }
    const dawn = this.time >= 5.4 && this.time < 6.3;
    if (dawn && !this.dawnSent) {
      this.dawnSent = true;
      this.sfx("dawn", this.span / 2, this.span / 2);
      this.pushLog({ t: "dawn" });
    }
    if (!dawn) this.dawnSent = false;
    if (prev < 19.6 && this.time >= 19.6) this.sfx("night", this.span / 2, this.span / 2);

    this.weatherT -= dt;
    if (this.weatherT <= 0 && this.weather !== "blood") {
      const r = this.rand();
      const next: Weather = r < 0.55 ? "clear" : r < 0.75 ? "cloudy" : r < 0.92 ? "rain" : "storm";
      if (next !== this.weather) this.pushLog({ t: "storm" });
      this.weather = next;
      this.weatherT = 36 + this.rand() * 40;
      if (next === "rain" || next === "storm") this.sfx("rain", this.span / 2, this.span / 2);
    }
    if (this.weather === "rain" || this.weather === "storm") {
      for (const t of this.trees) t.burn = Math.max(0, t.burn - dt * 2);
      for (const u of this.units) u.burn = Math.max(0, u.burn - dt * 2);
    }
    if (this.tsunami > 0) {
      this.tsunami -= dt;
      this.waterLevel = this.waterBase + Math.sin((1 - this.tsunami / 8) * Math.PI) * 2.15;
    } else this.waterLevel += (this.waterBase - this.waterLevel) * Math.min(1, dt * 1.5);
    if (this.quake > 0) this.quake -= dt;
    if (this.tornado) {
      const tor = this.tornado;
      tor.life -= dt;
      tor.x += tor.vx * dt;
      tor.z += tor.vz * dt;
      tor.vx += (this.rand() - 0.5) * dt * 8;
      tor.vz += (this.rand() - 0.5) * dt * 8;
      if (tor.life <= 0 || tor.x < 2 || tor.z < 2 || tor.x > this.span - 2 || tor.z > this.span - 2) this.tornado = null;
    }

    this.growKingdoms(dt);
    this.tickBuildings(dt);
    for (const tree of this.trees) {
      if (!tree.alive) {
        tree.regrow -= dt;
        if (tree.regrow <= 0 && this.biomeAt(tree.x, tree.z) !== BIOME.road && this.biomeAt(tree.x, tree.z) !== BIOME.lava) {
          tree.alive = true;
          tree.hp = tree.maxHp;
          tree.burn = 0;
        }
      } else if (tree.burn > 0) {
        tree.burn -= dt;
        tree.hp -= dt * 0.8;
        if (tree.hp <= 0) {
          tree.alive = false;
          tree.regrow = 36;
        }
      }
    }
    for (const u of this.units) this.tickUnit(u, dt);
    if (this.compact) {
      this.units = this.units.filter((u) => u.alive || u.fade > 0);
      this.buildings = this.buildings.filter((b) => b.alive);
      this.compact = false;
    }
    this.warT -= dt;
    if (this.warT <= 0) {
      this.warT = 2.4;
      this.considerWars();
    }
    this.eventT -= dt;
    if (this.eventT <= 0) {
      this.eventT = 24 + this.rand() * 30;
      this.rollEvent();
    }
  }

  apply(tool: Tool, x: number, z: number, brush: number): boolean {
    if (!this.inMap(x, z)) {
      this.toast = "needLand";
      this.sfx("ui_error", x, z);
      return false;
    }
    const many = brush > 1;
    const spots = many ? this.ring(x, z, 5) : [{ x, z }];
    if (tool === "human" || tool === "elf" || tool === "orc" || tool === "dwarf") this.raceBrush = tool;
    const powers = new Set<Tool>(["lightning", "meteor", "fire", "rain", "blood", "quake", "tornado", "tsunami", "plague", "freeze", "heal", "bless", "peace", "warhorn", "finger"]);
    if (powers.has(tool)) return this.power(tool, x, z, many ? 1.45 : 1);
    let ok = false;
    for (const s of spots) {
      if (this.placeOne(tool, s.x, s.z)) ok = true;
    }
    if (!ok && this.toast == null) {
      this.toast = "needLand";
      this.sfx("ui_error", x, z);
    }
    return ok;
  }

  selectAt(x: number, z: number): Inspect | null {
    let best: Unit | null = null;
    let bestD = 2.6;
    for (const u of this.units) {
      if (!u.alive) continue;
      const d = Math.hypot(u.x - x, u.z - z);
      const reach = u.race === "dragon" ? 3.4 : u.kind === "animal" ? 2.2 : 1.8;
      if (d < bestD && d < reach) {
        best = u;
        bestD = d;
      }
    }
    if (best) {
      this.selected = { kind: "unit", id: best.id };
      this.sfx("select", best.x, best.z);
      return this.inspectUnit(best);
    }
    let house: Building | null = null;
    bestD = 2.4;
    for (const b of this.buildings) {
      if (!b.alive) continue;
      const d = Math.hypot(b.x - x, b.z - z);
      if (d < bestD) {
        house = b;
        bestD = d;
      }
    }
    if (house) {
      this.selected = { kind: "building", id: house.id };
      this.sfx("select", house.x, house.z);
      const king = this.kingdoms.find((k) => k.id === house?.kingdom);
      return {
        id: house.id,
        kind: "building",
        title: house.type,
        subtitle: house.type,
        hp: house.hp,
        maxHp: house.maxHp,
        hunger: null,
        state: "wander",
        kingdom: king?.name ?? null,
        color: king?.color ?? null,
      };
    }
    this.selected = null;
    return null;
  }

  private rollEvent(): void {
    const r = this.rand();
    const land = this.findLand(this.span * 0.5, this.span * 0.45);
    if (r < 0.2) {
      const k = this.kingdoms.find((kk) => !kk.fallen);
      if (!k) return;
      k.food = Math.min(100, k.food + 12);
      k.wood = Math.min(80, k.wood + 6);
      k.boost = Math.max(k.boost, 16);
      this.toast = "event_festival";
      this.sfx("bless", k.hx, k.hz);
    } else if (r < 0.38) {
      this.weather = "cloudy";
      this.weatherT = 18;
      this.toast = "event_eclipse";
      this.sfx("night", this.span / 2, this.span / 2);
    } else if (r < 0.56 && land) {
      for (let i = 0; i < 3; i++) this.addAnimal("deer", land.x + i * 1.1, land.z + (i % 2));
      this.toast = "event_bounty";
      this.sfx("deer", land.x, land.z);
    } else if (r < 0.72) {
      const k = this.kingdoms.find((kk) => !kk.fallen);
      if (!k) return;
      this.spawnPerson(k.race, "villager", k.hx + 1.4, k.hz + 0.5, k.id);
      this.toast = "event_pilgrim";
      this.sfx("place_human", k.hx, k.hz);
    } else if (r < 0.86) {
      for (const k of this.kingdoms) if (!k.fallen) k.food = Math.max(0, k.food - 7);
      this.toast = "event_drought";
      this.sfx("ui_error", this.span / 2, this.span / 2);
    } else {
      for (const u of this.units) {
        if (!u.alive) continue;
        u.hp = Math.min(u.maxHp, u.hp + 10);
        u.plague = 0;
      }
      this.toast = "event_aurora";
      this.sfx("heal", this.span / 2, this.span / 2);
      this.fxQ.push({ kind: "heal", x: this.span / 2, y: 4, z: this.span / 2, life: 0.9, max: 0.9 });
    }
  }

  private power(tool: Tool, x: number, z: number, scale: number): boolean {
    const r = (n: number) => n * scale;
    if (tool === "finger") return true;
    if (tool === "lightning") {
      this.hurtArea(x, z, r(2.4), 46, true);
      this.scorch(x, z, r(1.6));
      this.fxQ.push({ kind: "lightning", x, y: this.heightAt(x, z), z, life: 0.22, max: 0.22 });
      this.sfx("lightning", x, z);
      return true;
    }
    if (tool === "meteor") {
      this.crater(x, z, r(5.5));
      this.hurtArea(x, z, r(6.2), 90, true);
      this.fxQ.push({ kind: "meteor", x, y: this.heightAt(x, z), z, life: 0.7, max: 0.7 });
      this.sfx("meteor", x, z);
      this.pushLog({ t: "meteor" });
      return true;
    }
    if (tool === "fire") {
      this.ignite(x, z, r(3.4));
      this.sfx("fire", x, z);
      return true;
    }
    if (tool === "rain") {
      this.weather = "rain";
      this.weatherT = 28;
      this.sfx("rain", x, z);
      this.pushLog({ t: "storm" });
      return true;
    }
    if (tool === "blood") {
      this.weather = "blood";
      this.weatherT = 14;
      this.sfx("blood", x, z);
      return true;
    }
    if (tool === "quake") {
      this.quake = 4.5;
      this.shakeTerrain(x, z, r(10));
      this.hurtArea(x, z, r(9), 18, false);
      this.sfx("quake", x, z);
      return true;
    }
    if (tool === "tornado") {
      this.tornado = { x, z, life: 12, vx: (this.rand() - 0.5) * 6, vz: (this.rand() - 0.5) * 6 };
      this.sfx("tornado", x, z);
      return true;
    }
    if (tool === "tsunami") {
      this.tsunami = 8;
      this.sfx("tsunami", x, z);
      return true;
    }
    if (tool === "plague") {
      for (const u of this.units) if (u.alive && Math.hypot(u.x - x, u.z - z) < r(5)) u.plague = Math.max(u.plague, 10);
      this.sfx("plague", x, z);
      return true;
    }
    if (tool === "freeze") {
      for (const u of this.units) if (u.alive && Math.hypot(u.x - x, u.z - z) < r(5)) u.frozen = Math.max(u.frozen, 7);
      this.sfx("freeze", x, z);
      this.fxQ.push({ kind: "heal", x, y: this.heightAt(x, z), z, life: 0.6, max: 0.6 });
      return true;
    }
    if (tool === "heal") {
      for (const u of this.units) {
        if (!u.alive || Math.hypot(u.x - x, u.z - z) > r(4.5)) continue;
        u.hp = u.maxHp;
        u.plague = 0;
        u.burn = 0;
        u.frozen = 0;
        u.hunger = Math.min(u.hunger, 0.2);
      }
      this.sfx("heal", x, z);
      this.fxQ.push({ kind: "heal", x, y: this.heightAt(x, z), z, life: 0.7, max: 0.7 });
      return true;
    }
    if (tool === "bless") {
      const k = this.nearestKingdom(x, z);
      if (!k) {
        this.toast = "needLand";
        this.sfx("ui_error", x, z);
        return false;
      }
      k.food = Math.min(100, k.food + 14);
      k.wood = Math.min(80, k.wood + 10);
      k.boost = 26;
      this.sfx("bless", k.hx, k.hz);
      return true;
    }
    if (tool === "peace" || tool === "warhorn") {
      const pair = this.nearestPair(x, z);
      if (!pair) {
        this.toast = "needTwo";
        this.sfx("ui_error", x, z);
        return false;
      }
      if (tool === "peace") {
        pair[0].wars = pair[0].wars.filter((id) => id !== pair[1].id);
        pair[1].wars = pair[1].wars.filter((id) => id !== pair[0].id);
        this.sfx("peace", x, z);
        this.pushLog({ t: "peace", a: pair[0].name, b: pair[1].name });
      } else {
        this.declare(pair[0], pair[1]);
      }
      return true;
    }
    return false;
  }

  private placeOne(tool: Tool, x: number, z: number): boolean {
    const h = this.heightAt(x, z);
    const wet = h < this.waterLevel + 0.18;
    const land = !wet && h < 7.2;
    if (tool === "erase") {
      this.erase(x, z, 2.4);
      this.sfx("erase", x, z);
      return true;
    }
    if (tool === "boat") {
      if (!wet) return false;
      return this.addBuilding("boat", x, z, -1);
    }
    if (tool === "grass" || tool === "sand" || tool === "forest" || tool === "snow" || tool === "swamp" || tool === "road" || tool === "lava") {
      const map: Record<string, number> = {
        grass: BIOME.grass,
        sand: BIOME.sand,
        forest: BIOME.forest,
        snow: BIOME.snow,
        swamp: BIOME.swamp,
        road: BIOME.road,
        lava: BIOME.lava,
      };
      this.paint(x, z, tool === "road" ? 1.6 : 3.2, map[tool] ?? 0);
      this.sfx(tool === "lava" ? "lava" : "place_bush", x, z);
      return true;
    }
    if (tool === "tree" || tool === "pine" || tool === "palm") {
      if (!land) return false;
      const kind: TreeKind = tool === "pine" ? "pine" : tool === "palm" ? "palm" : "oak";
      return this.addTree(kind, x, z);
    }
    if (tool === "rock") return land && this.addRock(x, z);
    if (tool === "bush" || tool === "flower") return land && this.addProp(tool, x, z);
    if (tool === "house" || tool === "farm" || tool === "tower" || tool === "castle" || tool === "shrine" || tool === "market" || tool === "wall" || tool === "firepit") {
      if (!land) return false;
      const king = this.nearestKingdom(x, z);
      return this.addBuilding(tool, x, z, king?.id ?? -1);
    }
    if (tool === "chicken" || tool === "sheep" || tool === "cow" || tool === "deer" || tool === "wolf" || tool === "bear" || tool === "tiger" || tool === "dragon") {
      if (tool !== "dragon" && !land) return false;
      return this.addAnimal(tool, x, z);
    }
    if (tool === "human" || tool === "elf" || tool === "orc" || tool === "dwarf" || tool === "warrior" || tool === "king") {
      if (!land) return false;
      const race = tool === "warrior" || tool === "king" ? this.raceBrush : tool;
      const role = tool === "warrior" ? "warrior" : tool === "king" ? "king" : "villager";
      return this.addPerson(race, role, x, z);
    }
    return false;
  }

  private tickUnit(u: Unit, dt: number): void {
    if (!u.alive) {
      u.fade -= dt * 1.8;
      if (u.fade <= 0) this.compact = true;
      return;
    }
    u.age += dt;
    u.hit = Math.max(0, u.hit - dt);
    if (u.frozen > 0) u.frozen -= dt;
    if (u.burn > 0) {
      u.burn -= dt;
      u.hp -= dt * 7;
    }
    if (u.plague > 0) {
      u.plague -= dt;
      u.hp -= dt * 3.2;
      if (this.rand() < dt * 0.35) {
        const other = this.nearestUnit(u.x, u.z, 2.2, (o) => o.id !== u.id && o.alive && o.plague <= 0);
        if (other) other.plague = 8;
      }
    }
    if (this.biomeAt(u.x, u.z) === BIOME.lava && u.race !== "dragon") {
      u.burn = Math.max(u.burn, 1.5);
      u.hp -= dt * 10;
    }
    if (this.waterLevel > this.waterBase + 0.8 && this.heightAt(u.x, u.z) < this.waterLevel - 0.2 && u.race !== "dragon") {
      u.hp -= dt * 6;
    }
    if (this.tornado && u.race !== "dragon") {
      const d = Math.hypot(u.x - this.tornado.x, u.z - this.tornado.z);
      if (d < 6 && d > 0.15) {
        u.x += ((this.tornado.x - u.x) / d) * 7 * dt;
        u.z += ((this.tornado.z - u.z) / d) * 7 * dt;
        u.hp -= dt * 6;
      }
    }
    if (this.weather === "blood" && u.kind === "person") u.hp -= dt * 2.4;
    if (u.kind === "person") {
      const night = this.isNight();
      u.hunger = Math.min(1.4, u.hunger + dt * (night && u.intent === "sleep" ? 0.004 : 0.011));
      if (u.hunger > 1) u.hp -= dt * 4;
    }
    if (u.hp <= 0) {
      this.kill(u);
      return;
    }
    if (u.frozen > 0) {
      u.moving = false;
      return;
    }
    if (u.role === "baby" && u.age > 22) {
      u.role = "villager";
      u.maxHp = 36;
      u.hp = 36;
    }
    u.timer -= dt;
    if (u.timer <= 0) {
      u.timer = 0.75 + this.rand() * 0.55;
      this.decide(u);
    }
    this.act(u, dt);
    this.steer(u, dt);
  }

  private decide(u: Unit): void {
    if (u.kind === "animal") {
      this.decideAnimal(u);
      return;
    }
    const king = this.kingdoms.find((k) => k.id === u.kingdom && !k.fallen);
    const threat = this.nearestHostile(u, u.role === "warrior" ? 16 : 8);
    if (threat && (u.role === "villager" || u.role === "baby") && (u.hp < u.maxHp * 0.85 || u.role === "baby")) {
      u.intent = "flee";
      u.target = threat.id;
      return;
    }
    if (threat && u.role !== "baby" && (u.role === "warrior" || u.role === "king" || Math.hypot(threat.x - u.x, threat.z - u.z) < 2.3)) {
      u.intent = "fight";
      u.target = threat.id;
      return;
    }
    if (this.isNight() && u.role !== "warrior") {
      const home = this.nearestBuilding(u, "house");
      if (home) {
        u.intent = "sleep";
        u.target = home.id;
        return;
      }
    }
    if (king && u.hunger > 0.72 && king.food > 0) {
      u.intent = "eat";
      u.tx = king.hx;
      u.tz = king.hz;
      u.target = -1;
      return;
    }
    if (!king || u.role === "baby") {
      this.wander(u, king);
      return;
    }
    if (u.role === "villager" || u.role === "king") {
      const boost = king.boost > 0;
      if (king.wood < (boost ? 24 : 16)) {
        const tree = this.nearestTree(u.x, u.z, 20);
        if (tree) {
          u.intent = "chop";
          u.target = tree.id;
          return;
        }
      }
      if (king.food < 14) {
        const farm = this.nearestBuilding(u, "farm");
        if (farm) {
          u.intent = "farm";
          u.target = farm.id;
          return;
        }
      }
      if (king.stone < 8) {
        const rock = this.nearestRock(u.x, u.z, 18);
        if (rock) {
          u.intent = "mine";
          u.target = rock.id;
          return;
        }
      }
      const houses = this.buildings.filter((b) => b.alive && b.type === "house" && b.kingdom === king.id).length;
      const pop = this.units.filter((p) => p.alive && p.kingdom === king.id).length;
      if (king.wood >= 6 && houses < Math.max(1, Math.ceil(pop / 3))) {
        const spot = this.siteNear(king.hx, king.hz, 3.2);
        if (spot) {
          u.intent = "build";
          u.build = "house";
          u.tx = spot.x;
          u.tz = spot.z;
          u.work = 0;
          return;
        }
      }
      const farms = this.buildings.filter((b) => b.alive && b.type === "farm" && b.kingdom === king.id).length;
      if (king.wood >= 3 && farms < 2 && king.food < 24) {
        const spot = this.siteNear(king.hx, king.hz, 3);
        if (spot) {
          u.intent = "build";
          u.build = "farm";
          u.tx = spot.x;
          u.tz = spot.z;
          u.work = 0;
          return;
        }
      }
      if (king.wars.length > 0 && king.stone >= 4) {
        const towers = this.buildings.filter((b) => b.alive && b.type === "tower" && b.kingdom === king.id).length;
        if (towers < 2) {
          const spot = this.siteNear(king.hx, king.hz, 2.6);
          if (spot) {
            u.intent = "build";
            u.build = "tower";
            u.tx = spot.x;
            u.tz = spot.z;
            u.work = 0;
            return;
          }
        }
      }
    }
    this.wander(u, king);
  }

  private decideAnimal(u: Unit): void {
    if (u.race === "dragon") {
      const k = this.kingdoms.find((kk) => !kk.fallen);
      if (k && this.rand() < 0.6) {
        u.tx = k.hx + (this.rand() - 0.5) * 8;
        u.tz = k.hz + (this.rand() - 0.5) * 8;
      } else this.wander(u, null);
      u.intent = "wander";
      if (u.cool <= 0 && k && Math.hypot(u.x - k.hx, u.z - k.hz) < 12) {
        u.cool = 5.5;
        this.ignite(u.x, u.z, 2.8);
        this.sfx("dragon_fire", u.x, u.z);
        this.pushLog({ t: "dragon" });
      }
      return;
    }
    if (u.race === "wolf" || u.race === "bear" || u.race === "tiger") {
      const prey = this.nearestUnit(u.x, u.z, u.race === "bear" ? 9 : 14, (o) => {
        if (!o.alive || o.id === u.id) return false;
        if (u.race === "tiger") return o.kind === "person" || o.race === "deer" || o.race === "cow" || o.race === "sheep";
        if (u.race === "wolf") return o.race === "deer" || o.race === "chicken" || o.race === "sheep" || o.kind === "person";
        return o.kind === "person" || o.race === "cow" || o.race === "deer";
      });
      if (prey) {
        u.intent = "fight";
        u.target = prey.id;
        return;
      }
    }
    if (u.race === "deer" || u.race === "sheep" || u.race === "chicken" || u.race === "cow") {
      const hunter = this.nearestUnit(u.x, u.z, 8, (o) => o.alive && (o.race === "wolf" || o.race === "bear" || o.race === "tiger" || o.race === "dragon" || o.role === "warrior"));
      if (hunter) {
        u.intent = "flee";
        u.target = hunter.id;
        return;
      }
    }
    this.wander(u, null);
  }

  private act(u: Unit, dt: number): void {
    const king = this.kingdoms.find((k) => k.id === u.kingdom);
    const rate = king?.boost ? 1.65 : 1;
    if (u.intent === "fight") {
      const foe = this.byId(u.target);
      if (!foe || !foe.alive) {
        u.intent = "wander";
        return;
      }
      const d = Math.hypot(foe.x - u.x, foe.z - u.z);
      if (d < (u.race === "dragon" ? 3.2 : 1.45)) {
        u.tx = u.x;
        u.tz = u.z;
        u.cool -= dt;
        if (u.cool <= 0) {
          u.cool = u.race === "dragon" ? 1.3 : 0.78;
          const dmg = u.role === "warrior" ? 11 : u.role === "king" ? 8 : u.race === "tiger" ? 13 : u.race === "wolf" ? 9 : u.race === "bear" ? 14 : u.race === "dragon" ? 18 : u.kind === "animal" ? 4 : 5;
          foe.hp -= dmg;
          foe.hit = 0.18;
          this.sfx(u.kind === "animal" ? (u.race === "dragon" ? "roar" : "bite") : "sword", u.x, u.z);
          if (foe.hp <= 0) this.kill(foe, king?.id ?? -1);
        }
      } else {
        u.tx = foe.x;
        u.tz = foe.z;
      }
      return;
    }
    if (u.intent === "chop") {
      const tree = this.trees.find((t) => t.id === u.target && t.alive);
      if (!tree) {
        u.intent = "wander";
        return;
      }
      if (Math.hypot(tree.x - u.x, tree.z - u.z) < 1.35) {
        u.work += dt * rate;
        if (u.work > 0.85) {
          u.work = 0;
          tree.hp -= 1;
          if (king) king.wood = Math.min(80, king.wood + 1);
          this.sfx("chop", tree.x, tree.z);
          if (tree.hp <= 0) {
            tree.alive = false;
            tree.regrow = 34;
            if (king) king.wood = Math.min(80, king.wood + 2);
            u.intent = "wander";
          }
        }
      } else {
        u.tx = tree.x;
        u.tz = tree.z;
      }
      return;
    }
    if (u.intent === "mine") {
      const rock = this.rocks.find((t) => t.id === u.target && t.alive);
      if (!rock) {
        u.intent = "wander";
        return;
      }
      if (Math.hypot(rock.x - u.x, rock.z - u.z) < 1.45) {
        u.work += dt * rate;
        if (u.work > 1) {
          u.work = 0;
          rock.hp -= 1;
          if (king) king.stone = Math.min(60, king.stone + 1);
          this.sfx("mine", rock.x, rock.z);
          if (rock.hp <= 0) {
            rock.alive = false;
            u.intent = "wander";
          }
        }
      } else {
        u.tx = rock.x;
        u.tz = rock.z;
      }
      return;
    }
    if (u.intent === "farm") {
      const farm = this.buildings.find((b) => b.id === u.target && b.alive);
      if (!farm) {
        u.intent = "wander";
        return;
      }
      u.tx = farm.x;
      u.tz = farm.z;
      if (Math.hypot(farm.x - u.x, farm.z - u.z) < 1.6 && king) {
        king.food = Math.min(100, king.food + dt * 0.55 * rate);
      }
      return;
    }
    if (u.intent === "build" && u.build) {
      if (Math.hypot(u.tx - u.x, u.tz - u.z) < 1.3) {
        u.work += dt * rate;
        if (Math.floor(u.work * 2) !== Math.floor((u.work - dt) * 2)) this.sfx("hammer", u.x, u.z);
        const cost = u.build === "house" ? { wood: 6, stone: 0 } : u.build === "farm" ? { wood: 3, stone: 0 } : { wood: 1, stone: 4 };
        if (u.work > 3.1) {
          if (king && king.wood >= cost.wood && king.stone >= cost.stone && this.siteFree(u.tx, u.tz, 2.2)) {
            king.wood -= cost.wood;
            king.stone -= cost.stone;
            this.addBuilding(u.build, u.tx, u.tz, king.id, true);
          }
          u.intent = "wander";
          u.work = 0;
        }
      }
      return;
    }
    if (u.intent === "eat" && king) {
      u.tx = king.hx;
      u.tz = king.hz;
      if (Math.hypot(u.x - king.hx, u.z - king.hz) < 2.2 && king.food > 0) {
        king.food -= 1;
        u.hunger = 0.12;
        this.sfx("eat", u.x, u.z);
        u.intent = "wander";
      }
      return;
    }
    if (u.intent === "sleep") {
      const home = this.buildings.find((b) => b.id === u.target && b.alive);
      if (!home) {
        u.intent = "wander";
        return;
      }
      u.tx = home.x;
      u.tz = home.z + 0.4;
      if (Math.hypot(u.x - home.x, u.z - home.z) < 1.5) {
        u.moving = false;
        u.hp = Math.min(u.maxHp, u.hp + dt * 1.5);
      }
      return;
    }
    if (u.intent === "flee") {
      const foe = this.byId(u.target);
      if (!foe || !foe.alive) {
        u.intent = "wander";
        return;
      }
      const dx = u.x - foe.x;
      const dz = u.z - foe.z;
      const d = Math.hypot(dx, dz) || 1;
      u.tx = clamp(u.x + (dx / d) * 4, 2, this.span - 2);
      u.tz = clamp(u.z + (dz / d) * 4, 2, this.span - 2);
    }
  }

  private steer(u: Unit, dt: number): void {
    let speed = u.role === "warrior" ? 2.55 : u.role === "king" ? 1.85 : u.role === "baby" ? 1.25 : u.kind === "person" ? 2.15 : 1.8;
    if (u.race === "wolf") speed = 3.25;
    if (u.race === "tiger") speed = 3.45;
    if (u.race === "deer") speed = 3.35;
    if (u.race === "dragon") speed = 4.6;
    if (u.race === "bear") speed = 2.15;
    if (u.race === "cow") speed = 1.25;
    if (u.race === "chicken") speed = 1.5;
    if (this.heightAt(u.x, u.z) < this.waterLevel + 0.05) speed *= 0.55;
    const dx = u.tx - u.x;
    const dz = u.tz - u.z;
    const dist = Math.hypot(dx, dz);
    if (dist > 0.18) {
      u.x += (dx / dist) * speed * dt;
      u.z += (dz / dist) * speed * dt;
      u.yaw = Math.atan2(-dx, -dz);
      u.moving = true;
      u.x = clamp(u.x, 1.5, this.span - 1.5);
      u.z = clamp(u.z, 1.5, this.span - 1.5);
    } else u.moving = false;
  }

  private growKingdoms(dt: number): void {
    for (const k of this.kingdoms) {
      if (k.fallen) continue;
      k.boost = Math.max(0, k.boost - dt);
      k.breed -= dt;
      const members = this.units.filter((u) => u.alive && u.kingdom === k.id);
      if (members.length === 0) {
        k.fallen = true;
        this.pushLog({ t: "wipe", a: k.name });
        this.sfx("death", k.hx, k.hz);
        continue;
      }
      const kingUnit = members.find((u) => u.role === "king");
      if (kingUnit) {
        k.hx += (kingUnit.x - k.hx) * 0.02;
        k.hz += (kingUnit.z - k.hz) * 0.02;
      }
      for (const farm of this.buildings) {
        if (farm.alive && farm.kingdom === k.id && farm.type === "farm") k.food = Math.min(100, k.food + dt * 0.22 * (k.boost > 0 ? 2 : 1));
      }
      const houses = this.buildings.filter((b) => b.alive && b.type === "house" && b.kingdom === k.id).length;
      const shrines = this.buildings.filter((b) => b.alive && b.type === "shrine" && b.kingdom === k.id).length;
      const markets = this.buildings.filter((b) => b.alive && b.type === "market" && b.kingdom === k.id).length;
      if (shrines > 0) k.breed -= dt * 0.45;
      if (markets > 0) k.food = Math.min(100, k.food + dt * 0.16 * markets);
      const adults = members.filter((u) => u.role !== "baby" && u.age > 10);
      if (k.breed <= 0 && adults.length >= 2 && k.food >= 6 && members.length < houses * 4 + 3 && this.units.length < LIMITS.unit) {
        k.breed = 16;
        k.food -= 2;
        const parent = adults[Math.floor(this.rand() * adults.length)] ?? adults[0];
        if (parent) {
          this.spawnPerson(k.race, "baby", parent.x + 0.4, parent.z + 0.3, k.id);
          this.births += 1;
          this.sfx("birth", parent.x, parent.z);
          this.pushLog({ t: "born", a: k.name });
        }
      }
    }
  }

  private tickBuildings(dt: number): void {
    for (const b of this.buildings) {
      if (!b.alive || b.type !== "tower") continue;
      b.cool -= dt;
      if (b.cool > 0) continue;
      const foe = this.nearestUnit(b.x, b.z, 9, (u) => {
        if (!u.alive) return false;
        if (u.race === "wolf" || u.race === "bear" || u.race === "tiger" || u.race === "dragon") return true;
        if (u.kind !== "person" || u.kingdom < 0) return false;
        const home = this.kingdoms.find((k) => k.id === b.kingdom);
        return !!home && home.wars.includes(u.kingdom);
      });
      if (!foe) continue;
      b.cool = 1.25;
      foe.hp -= 7;
      foe.hit = 0.12;
      this.sfx("tower", b.x, b.z);
      this.fxQ.push({
        kind: "bolt",
        x: b.x,
        y: this.heightAt(b.x, b.z) + 2.2,
        z: b.z,
        x2: foe.x,
        y2: this.heightAt(foe.x, foe.z) + 1,
        z2: foe.z,
        life: 0.18,
        max: 0.18,
      });
      if (foe.hp <= 0) this.kill(foe, b.kingdom);
    }
  }

  private considerWars(): void {
    for (let i = 0; i < this.kingdoms.length; i++) {
      for (let j = i + 1; j < this.kingdoms.length; j++) {
        const a = this.kingdoms[i];
        const b = this.kingdoms[j];
        if (!a || !b || a.fallen || b.fallen || a.race === b.race) continue;
        if (a.wars.includes(b.id)) continue;
        if (Math.hypot(a.hx - b.hx, a.hz - b.hz) < 18) this.declare(a, b);
      }
    }
  }

  private declare(a: Kingdom, b: Kingdom): void {
    if (!a.wars.includes(b.id)) a.wars.push(b.id);
    if (!b.wars.includes(a.id)) b.wars.push(a.id);
    this.sfx("war", (a.hx + b.hx) / 2, (a.hz + b.hz) / 2);
    this.pushLog({ t: "war", a: a.name, b: b.name });
  }

  private kill(u: Unit, killerKingdom = -1): void {
    if (!u.alive) return;
    u.alive = false;
    u.fade = 1;
    u.moving = false;
    this.deaths += 1;
    this.compact = true;
    this.sfx(u.kind === "person" ? "death" : "death_beast", u.x, u.z);
    if (killerKingdom >= 0) {
      const k = this.kingdoms.find((kk) => kk.id === killerKingdom);
      if (k) k.food = Math.min(100, k.food + 1);
    }
  }

  private addPerson(race: Race, role: Role, x: number, z: number): boolean {
    let king = this.kingdoms.find((k) => !k.fallen && k.race === race && Math.hypot(k.hx - x, k.hz - z) < 18);
    if (role === "king" && king) {
      const existing = this.units.find((u) => u.alive && u.kingdom === king?.id && u.role === "king");
      if (existing) role = "warrior";
    }
    if (!king) {
      const created = this.foundKingdom(race, x, z);
      if (!created) return false;
      king = created;
    }
    if (!king) return false;
    const born = this.spawnPerson(race, role, x, z, king.id);
    if (!born) return false;
    if (role === "king") {
      king.hx = x;
      king.hz = z;
      if (!this.buildings.some((b) => b.alive && b.kingdom === king?.id && b.type === "castle")) this.addBuilding("castle", x, z - 1.6, king.id, true);
    }
    const sound: SoundId = role === "king" ? "place_king" : role === "warrior" ? "place_warrior" : role === "baby" ? "place_baby" : race === "elf" ? "place_elf" : race === "orc" ? "place_orc" : race === "dwarf" ? "place_dwarf" : "place_human";
    this.sfx(sound, x, z);
    return true;
  }

  private spawnPerson(race: Race, role: Role, x: number, z: number, kingdom: number): Unit | null {
    if (this.units.length >= LIMITS.unit) {
      this.toast = "full";
      return null;
    }
    const hp = role === "warrior" ? 78 : role === "king" ? 110 : role === "baby" ? 18 : 36;
    const u: Unit = {
      id: this.nextId++,
      kind: "person",
      race,
      role,
      name: PEOPLE[Math.floor(this.rand() * PEOPLE.length)] ?? "Warga",
      kingdom,
      x,
      z,
      yaw: this.rand() * Math.PI * 2,
      hp,
      maxHp: hp,
      hunger: 0.2,
      age: role === "baby" ? 0 : 18,
      alive: true,
      fade: 1,
      intent: "wander",
      target: -1,
      tx: x,
      tz: z,
      timer: this.rand(),
      cool: 0,
      work: 0,
      frozen: 0,
      burn: 0,
      plague: 0,
      hit: 0,
      phase: this.rand() * Math.PI * 2,
      moving: false,
      build: null,
    };
    this.units.push(u);
    return u;
  }

  private addAnimal(kind: AnimalKind, x: number, z: number): boolean {
    if (kind === "dragon" && this.units.filter((u) => u.alive && u.race === "dragon").length >= 2) {
      this.toast = "full";
      return false;
    }
    if (this.units.length >= LIMITS.unit) {
      this.toast = "full";
      return false;
    }
    const hp = kind === "dragon" ? 260 : kind === "bear" ? 100 : kind === "tiger" ? 78 : kind === "wolf" ? 44 : kind === "cow" ? 40 : kind === "deer" ? 28 : kind === "sheep" ? 22 : 12;
    this.units.push({
      id: this.nextId++,
      kind: "animal",
      race: kind,
      role: "beast",
      name: kind,
      kingdom: -1,
      x,
      z,
      yaw: this.rand() * Math.PI * 2,
      hp,
      maxHp: hp,
      hunger: 0,
      age: 4,
      alive: true,
      fade: 1,
      intent: "wander",
      target: -1,
      tx: x,
      tz: z,
      timer: this.rand(),
      cool: 1,
      work: 0,
      frozen: 0,
      burn: 0,
      plague: 0,
      hit: 0,
      phase: this.rand() * Math.PI * 2,
      moving: false,
      build: null,
    });
    const sound: SoundId =
      kind === "chicken" ? "chicken" : kind === "sheep" ? "sheep" : kind === "cow" ? "cow" : kind === "deer" ? "deer" : kind === "wolf" ? "wolf" : kind === "tiger" ? "roar" : kind === "bear" ? "bear" : "dragon";
    this.sfx(sound, x, z);
    return true;
  }

  private addBuilding(type: BuildType, x: number, z: number, kingdom: number, quiet = false): boolean {
    if (this.buildings.length >= LIMITS.building) {
      this.toast = "full";
      return false;
    }
    const hp = type === "castle" ? 240 : type === "shrine" ? 180 : type === "tower" ? 140 : type === "market" ? 90 : type === "wall" ? 90 : type === "house" ? 80 : 50;
    this.buildings.push({
      id: this.nextId++,
      type,
      x,
      z,
      yaw: this.rand() * Math.PI * 2,
      hp,
      maxHp: hp,
      kingdom,
      alive: true,
      cool: 0.4,
    });
    if (type === "castle") {
      const k = this.kingdoms.find((kk) => kk.id === kingdom);
      if (k) {
        k.hx = x;
        k.hz = z;
      }
    }
    const sound: SoundId =
      type === "house" ? "place_house" : type === "farm" ? "place_farm" : type === "tower" ? "place_tower" : type === "castle" ? "place_castle" : type === "shrine" ? "bless" : type === "market" ? "place_house" : type === "wall" ? "place_wall" : type === "boat" ? "place_boat" : "place_fire";
    if (!quiet) this.sfx(sound, x, z);
    else this.sfx("build_done", x, z);
    if (!quiet || type === "house" || type === "farm" || type === "tower") {
      const k = this.kingdoms.find((kk) => kk.id === kingdom);
      if (k && !quiet) this.pushLog({ t: "build", a: k.name, what: type });
    }
    return true;
  }

  private addTree(kind: TreeKind, x: number, z: number): boolean {
    if (this.trees.filter((t) => t.alive).length >= LIMITS.tree) {
      this.toast = "full";
      return false;
    }
    this.trees.push({
      id: this.nextId++,
      kind,
      x,
      z,
      hp: 3,
      maxHp: 3,
      alive: true,
      burn: 0,
      regrow: 0,
      scale: 0.85 + this.rand() * 0.45,
      yaw: this.rand() * Math.PI,
      phase: this.rand() * 6,
    });
    this.sfx("place_tree", x, z);
    return true;
  }

  private addRock(x: number, z: number): boolean {
    if (this.rocks.length >= LIMITS.rock) return false;
    this.rocks.push({ id: this.nextId++, x, z, hp: 3, alive: true, scale: 0.7 + this.rand() * 0.8, phase: this.rand() * 6 });
    this.sfx("place_rock", x, z);
    return true;
  }

  private addProp(kind: "bush" | "flower", x: number, z: number): boolean {
    if (this.props.length >= LIMITS.prop) return false;
    this.props.push({ id: this.nextId++, kind, x, z, alive: true, scale: 0.8 + this.rand() * 0.5, yaw: this.rand() * 6, phase: this.rand() * 6 });
    this.sfx(kind === "bush" ? "place_bush" : "place_flower", x, z);
    return true;
  }

  private foundKingdom(race: Race, x: number, z: number): Kingdom | null {
    const used = new Set(this.kingdoms.map((k) => k.name));
    const name = KNAMES[race].find((n) => !used.has(n)) ?? `${KNAMES[race][0]} ${this.kingdoms.length + 1}`;
    const color = RCOLORS[race][this.kingdoms.length % RCOLORS[race].length] ?? "#3e6f9a";
    const king: Kingdom = {
      id: this.nextId++,
      race,
      name,
      color,
      hx: x,
      hz: z,
      food: 14,
      wood: 8,
      stone: 4,
      wars: [],
      boost: 0,
      breed: 8,
      fallen: false,
    };
    this.kingdoms.push(king);
    return king;
  }

  private generate(): void {
    const n = this.res;
    const lavaX = this.span * 0.74;
    const lavaZ = this.span * 0.7;
    for (let z = 0; z < n; z++) {
      for (let x = 0; x < n; x++) {
        const dx = (x / this.span - 0.5) * 2;
        const dz = (z / this.span - 0.5) * 2;
        const d = Math.hypot(dx * 1.05, dz * 0.92);
        const mask = Math.pow(Math.max(0, 1 - d * 0.9), 1.2);
        let h = mask * (2.3 + fbm(x * 0.055, z * 0.055, this.seed) * 5.4);
        h += fbm(x * 0.13, z * 0.13, this.seed + 3) * mask * 1.15;
        if (d > 1) h *= 0.25;
        const moisture = fbm(x * 0.07 + 4, z * 0.07, this.seed + 9);
        let biome = BIOME.grass;
        if (h < this.waterBase + 0.28) biome = BIOME.sand;
        else if (h > 6.15) biome = BIOME.snow;
        else if (moisture > 0.62 && h < 2.5) biome = BIOME.swamp;
        else if (moisture > 0.52) biome = BIOME.forest;
        if (Math.hypot(x - lavaX, z - lavaZ) < 3.1) {
          biome = BIOME.lava;
          h = Math.min(h, this.waterBase + 0.35);
        }
        this.height[z * n + x] = h;
        this.biome[z * n + x] = biome;
      }
    }
    for (let z = 1; z < n - 1; z++) {
      for (let x = 1; x < n - 1; x++) {
        const i = z * n + x;
        const h = this.height[i] ?? 0;
        const slope = Math.hypot((this.height[i + 1] ?? h) - (this.height[i - 1] ?? h), (this.height[i + n] ?? h) - (this.height[i - n] ?? h));
        const b = this.biome[i] ?? 0;
        if (slope > 1.15 && b !== BIOME.sand && b !== BIOME.snow && b !== BIOME.lava && h > this.waterBase + 0.4) this.biome[i] = BIOME.rock;
      }
    }
  }

  private scatter(): void {
    const step = 2;
    for (let z = 3; z < this.span - 3; z += step) {
      for (let x = 3; x < this.span - 3; x += step) {
        const jx = x + (hash(x, z, this.seed) - 0.5) * 1.4;
        const jz = z + (hash(z, x, this.seed + 2) - 0.5) * 1.4;
        const b = this.biomeAt(jx, jz);
        const h = this.heightAt(jx, jz);
        if (h < this.waterBase + 0.35) continue;
        const r = hash(x * 3, z * 5, this.seed + 11);
        if ((b === BIOME.forest || b === BIOME.grass || b === BIOME.swamp) && r > 0.42 && this.trees.length < LIMITS.tree) {
          const kind: TreeKind = b === BIOME.swamp ? "palm" : r > 0.78 ? "pine" : "oak";
          this.trees.push({
            id: this.nextId++,
            kind,
            x: jx,
            z: jz,
            hp: 3,
            maxHp: 3,
            alive: true,
            burn: 0,
            regrow: 0,
            scale: 0.8 + hash(x, z, 4) * 0.55,
            yaw: hash(x, z, 5) * Math.PI,
            phase: hash(x, z, 6) * 6,
          });
        } else if (b === BIOME.rock && r > 0.45 && this.rocks.length < LIMITS.rock) {
          this.rocks.push({ id: this.nextId++, x: jx, z: jz, hp: 3, alive: true, scale: 0.6 + r, phase: r * 4 });
        } else if ((b === BIOME.grass || b === BIOME.forest) && r > 0.86 && this.props.length < LIMITS.prop) {
          this.props.push({
            id: this.nextId++,
            kind: r > 0.93 ? "flower" : "bush",
            x: jx,
            z: jz,
            alive: true,
            scale: 0.75 + r * 0.4,
            yaw: r * 6,
            phase: r * 3,
          });
        }
      }
    }
    this.scatterDirty = true;
  }

  private seedVillages(): void {
    const human = this.findLand(this.span * 0.38, this.span * 0.46);
    const orc = this.findLand(this.span * 0.68, this.span * 0.58);
    if (human) {
      const k = this.foundKingdom("human", human.x, human.z);
      if (k) {
        this.spawnPerson("human", "king", human.x, human.z, k.id);
        for (let i = 0; i < 6; i++) this.spawnPerson("human", "villager", human.x + (this.rand() - 0.5) * 5, human.z + (this.rand() - 0.5) * 5, k.id);
        for (let i = 0; i < 2; i++) this.spawnPerson("human", "warrior", human.x + 2 + i, human.z + 1, k.id);
        this.addBuilding("castle", human.x, human.z - 1.8, k.id, true);
        this.addBuilding("house", human.x - 3.2, human.z + 1.4, k.id, true);
        this.addBuilding("house", human.x + 3, human.z + 0.6, k.id, true);
        this.addBuilding("house", human.x - 1.2, human.z + 3.3, k.id, true);
        this.addBuilding("farm", human.x + 1.5, human.z + 4.2, k.id, true);
        this.addBuilding("firepit", human.x + 0.8, human.z + 1.5, k.id, true);
        for (let i = 0; i < 3; i++) this.addAnimal("chicken", human.x + 3 + i * 0.6, human.z + 2);
        this.addAnimal("sheep", human.x - 4, human.z + 2);
      }
    }
    if (orc && (!human || Math.hypot(orc.x - human.x, orc.z - human.z) > 16)) {
      const k = this.foundKingdom("orc", orc.x, orc.z);
      if (k) {
        this.spawnPerson("orc", "king", orc.x, orc.z, k.id);
        for (let i = 0; i < 4; i++) this.spawnPerson("orc", "villager", orc.x + (this.rand() - 0.5) * 4, orc.z + (this.rand() - 0.5) * 4, k.id);
        for (let i = 0; i < 2; i++) this.spawnPerson("orc", "warrior", orc.x - 2, orc.z + i, k.id);
        this.addBuilding("castle", orc.x, orc.z - 1.6, k.id, true);
        this.addBuilding("house", orc.x + 2.8, orc.z + 1, k.id, true);
        this.addBuilding("house", orc.x - 2.6, orc.z + 1.4, k.id, true);
        this.addBuilding("firepit", orc.x + 0.6, orc.z + 1.6, k.id, true);
      }
    }
    const wild = this.findLand(this.span * 0.52, this.span * 0.28);
    if (wild) {
      this.addAnimal("deer", wild.x, wild.z);
      this.addAnimal("deer", wild.x + 1.4, wild.z - 0.6);
      this.addAnimal("deer", wild.x - 1, wild.z + 1);
    }
    const den = this.findLand(this.span * 0.24, this.span * 0.72);
    if (den) {
      this.addAnimal("wolf", den.x, den.z);
      this.addAnimal("wolf", den.x + 1.2, den.z + 0.4);
    }
    const cave = this.findLand(this.span * 0.8, this.span * 0.3);
    if (cave) this.addAnimal("bear", cave.x, cave.z);
  }

  private findLand(px: number, pz: number): { x: number; z: number } | null {
    let best: { x: number; z: number } | null = null;
    let bestD = 1e9;
    for (let i = 0; i < 180; i++) {
      const x = 4 + this.rand() * (this.span - 8);
      const z = 4 + this.rand() * (this.span - 8);
      const h = this.heightAt(x, z);
      const b = this.biomeAt(x, z);
      if (h < this.waterBase + 0.55 || h > 5.4) continue;
      if (b === BIOME.sand || b === BIOME.lava || b === BIOME.snow || b === BIOME.rock) continue;
      const d = Math.hypot(x - px, z - pz);
      if (d < bestD) {
        bestD = d;
        best = { x, z };
      }
    }
    return best;
  }

  private paint(x: number, z: number, radius: number, biome: number): void {
    const r = Math.ceil(radius);
    const x0 = clamp(Math.floor(x - r), 0, this.span);
    const x1 = clamp(Math.ceil(x + r), 0, this.span);
    const z0 = clamp(Math.floor(z - r), 0, this.span);
    const z1 = clamp(Math.ceil(z + r), 0, this.span);
    for (let zz = z0; zz <= z1; zz++) {
      for (let xx = x0; xx <= x1; xx++) {
        if (Math.hypot(xx - x, zz - z) > radius) continue;
        this.biome[zz * this.res + xx] = biome;
        if (biome === BIOME.lava) this.height[zz * this.res + xx] = Math.min(this.height[zz * this.res + xx] ?? 0, this.waterBase + 0.4);
      }
    }
    this.terrainDirty = true;
  }

  private crater(x: number, z: number, radius: number): void {
    const r = Math.ceil(radius);
    for (let zz = Math.max(0, Math.floor(z - r)); zz <= Math.min(this.span, Math.ceil(z + r)); zz++) {
      for (let xx = Math.max(0, Math.floor(x - r)); xx <= Math.min(this.span, Math.ceil(x + r)); xx++) {
        const d = Math.hypot(xx - x, zz - z);
        if (d > radius) continue;
        const i = zz * this.res + xx;
        const inf = 1 - d / radius;
        this.height[i] = Math.max(0.2, (this.height[i] ?? 0) - inf * 1.7);
        this.biome[i] = BIOME.scorch;
      }
    }
    this.terrainDirty = true;
    this.ignite(x, z, radius * 0.7);
  }

  private shakeTerrain(x: number, z: number, radius: number): void {
    for (let i = 0; i < 80; i++) {
      const xx = clamp(Math.round(x + (this.rand() - 0.5) * radius * 2), 1, this.span - 1);
      const zz = clamp(Math.round(z + (this.rand() - 0.5) * radius * 2), 1, this.span - 1);
      const idx = zz * this.res + xx;
      this.height[idx] = Math.max(0.15, (this.height[idx] ?? 0) + (this.rand() - 0.5) * 0.55);
    }
    this.terrainDirty = true;
  }

  private scorch(x: number, z: number, radius: number): void {
    this.paint(x, z, radius, BIOME.scorch);
  }

  private ignite(x: number, z: number, radius: number): void {
    for (const t of this.trees) if (t.alive && Math.hypot(t.x - x, t.z - z) < radius) t.burn = Math.max(t.burn, 4);
    for (const u of this.units) if (u.alive && Math.hypot(u.x - x, u.z - z) < radius) u.burn = Math.max(u.burn, 3.5);
    for (const b of this.buildings) {
      if (b.alive && Math.hypot(b.x - x, b.z - z) < radius) {
        b.hp -= 28;
        if (b.hp <= 0) {
          b.alive = false;
          this.compact = true;
        }
      }
    }
    this.fxQ.push({ kind: "boom", x, y: this.heightAt(x, z), z, life: 0.45, max: 0.45 });
  }

  private hurtArea(x: number, z: number, radius: number, dmg: number, ignite: boolean): void {
    for (const u of this.units) {
      if (!u.alive || Math.hypot(u.x - x, u.z - z) > radius) continue;
      u.hp -= dmg;
      u.hit = 0.2;
      if (ignite) u.burn = Math.max(u.burn, 2.5);
      if (u.hp <= 0) this.kill(u);
    }
    if (ignite) this.ignite(x, z, radius * 0.85);
  }

  private erase(x: number, z: number, radius: number): void {
    for (const u of this.units) {
      if (u.alive && Math.hypot(u.x - x, u.z - z) < radius) this.kill(u);
    }
    for (const b of this.buildings) {
      if (b.alive && Math.hypot(b.x - x, b.z - z) < radius + 0.6) {
        b.alive = false;
        this.compact = true;
      }
    }
    for (const t of this.trees) {
      if (t.alive && Math.hypot(t.x - x, t.z - z) < radius) {
        t.alive = false;
        t.regrow = 50;
      }
    }
    for (const r of this.rocks) if (r.alive && Math.hypot(r.x - x, r.z - z) < radius) r.alive = false;
    for (const p of this.props) if (p.alive && Math.hypot(p.x - x, p.z - z) < radius) p.alive = false;
  }

  private ring(x: number, z: number, count: number): { x: number; z: number }[] {
    const spots = [{ x, z }];
    for (let i = 0; i < count - 1; i++) {
      const a = (i / (count - 1)) * Math.PI * 2;
      spots.push({ x: x + Math.cos(a) * 2.3, z: z + Math.sin(a) * 2.3 });
    }
    return spots;
  }

  private wander(u: Unit, king: Kingdom | null | undefined): void {
    u.intent = "wander";
    const ox = king ? king.hx : u.x;
    const oz = king ? king.hz : u.z;
    const spread = king ? 7 : 6;
    u.tx = clamp(ox + (this.rand() - 0.5) * spread * 2, 2, this.span - 2);
    u.tz = clamp(oz + (this.rand() - 0.5) * spread * 2, 2, this.span - 2);
    u.target = -1;
  }

  private siteNear(x: number, z: number, gap: number): { x: number; z: number } | null {
    for (let i = 0; i < 10; i++) {
      const s = { x: x + (this.rand() - 0.5) * 10, z: z + (this.rand() - 0.5) * 10 };
      if (this.siteFree(s.x, s.z, gap) && this.heightAt(s.x, s.z) > this.waterLevel + 0.4) return s;
    }
    return null;
  }

  private siteFree(x: number, z: number, gap: number): boolean {
    if (!this.inMap(x, z)) return false;
    for (const b of this.buildings) if (b.alive && Math.hypot(b.x - x, b.z - z) < gap) return false;
    for (const t of this.trees) if (t.alive && Math.hypot(t.x - x, t.z - z) < gap * 0.65) return false;
    return true;
  }

  private nearestKingdom(x: number, z: number): Kingdom | null {
    let best: Kingdom | null = null;
    let d0 = 1e9;
    for (const k of this.kingdoms) {
      if (k.fallen) continue;
      const d = Math.hypot(k.hx - x, k.hz - z);
      if (d < d0) {
        d0 = d;
        best = k;
      }
    }
    return best;
  }

  private nearestPair(x: number, z: number): [Kingdom, Kingdom] | null {
    const list = this.kingdoms.filter((k) => !k.fallen).sort((a, b) => Math.hypot(a.hx - x, a.hz - z) - Math.hypot(b.hx - x, b.hz - z));
    if (list.length < 2) return null;
    const a = list[0];
    const b = list[1];
    if (!a || !b) return null;
    return [a, b];
  }

  private nearestHostile(u: Unit, reach: number): Unit | null {
    return this.nearestUnit(u.x, u.z, reach, (o) => {
      if (!o.alive || o.id === u.id) return false;
      if (o.race === "wolf" || o.race === "bear" || o.race === "dragon") return u.kind === "person";
      if (u.kind !== "person" || o.kind !== "person") return false;
      const home = this.kingdoms.find((k) => k.id === u.kingdom);
      return !!home && home.wars.includes(o.kingdom);
    });
  }

  private nearestUnit(x: number, z: number, reach: number, test: (u: Unit) => boolean): Unit | null {
    let best: Unit | null = null;
    let d0 = reach;
    for (const u of this.units) {
      if (!test(u)) continue;
      const d = Math.hypot(u.x - x, u.z - z);
      if (d < d0) {
        d0 = d;
        best = u;
      }
    }
    return best;
  }

  private nearestTree(x: number, z: number, reach: number): Tree | null {
    let best: Tree | null = null;
    let d0 = reach;
    for (const t of this.trees) {
      if (!t.alive) continue;
      const d = Math.hypot(t.x - x, t.z - z);
      if (d < d0) {
        d0 = d;
        best = t;
      }
    }
    return best;
  }

  private nearestRock(x: number, z: number, reach: number): Rock | null {
    let best: Rock | null = null;
    let d0 = reach;
    for (const t of this.rocks) {
      if (!t.alive) continue;
      const d = Math.hypot(t.x - x, t.z - z);
      if (d < d0) {
        d0 = d;
        best = t;
      }
    }
    return best;
  }

  private nearestBuilding(u: Unit, type: BuildType): Building | null {
    let best: Building | null = null;
    let d0 = 1e9;
    for (const b of this.buildings) {
      if (!b.alive || b.type !== type || b.kingdom !== u.kingdom) continue;
      const d = Math.hypot(b.x - u.x, b.z - u.z);
      if (d < d0) {
        d0 = d;
        best = b;
      }
    }
    return best;
  }

  private byId(id: number): Unit | null {
    return this.units.find((u) => u.id === id) ?? null;
  }

  private inMap(x: number, z: number): boolean {
    return x > 1 && z > 1 && x < this.span - 1 && z < this.span - 1;
  }

  private isNight(): boolean {
    return this.time < 5.5 || this.time > 19.4;
  }

  private sfx(id: SoundId, x: number, z: number): void {
    this.sfxQ.push({ id, x, z });
  }

  private pushLog(item: LogItem): void {
    this.log.unshift(item);
    if (this.log.length > 8) this.log.pop();
  }

  private inspectUnit(u: Unit): Inspect {
    const king = this.kingdoms.find((k) => k.id === u.kingdom);
    return {
      id: u.id,
      kind: "unit",
      title: u.kind === "person" ? u.name : u.race,
      subtitle: u.kind === "person" ? `${u.role}:${u.race}` : u.race,
      hp: Math.max(0, u.hp),
      maxHp: u.maxHp,
      hunger: u.kind === "person" ? u.hunger : null,
      state: u.alive ? u.intent : "dead",
      kingdom: king?.name ?? null,
      color: king?.color ?? null,
    };
  }

  inspectSelected(): Inspect | null {
    if (!this.selected) return null;
    if (this.selected.kind === "unit") {
      const u = this.byId(this.selected.id);
      if (!u || !u.alive) {
        this.selected = null;
        return null;
      }
      return this.inspectUnit(u);
    }
    const b = this.buildings.find((x) => x.id === this.selected?.id && x.alive);
    if (!b) {
      this.selected = null;
      return null;
    }
    const king = this.kingdoms.find((k) => k.id === b.kingdom);
    return {
      id: b.id,
      kind: "building",
      title: b.type,
      subtitle: b.type,
      hp: b.hp,
      maxHp: b.maxHp,
      hunger: null,
      state: "wander",
      kingdom: king?.name ?? null,
      color: king?.color ?? null,
    };
  }
}

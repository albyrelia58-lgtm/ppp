import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useState, type ComponentType } from "react";

export const Route = createFileRoute("/")({ component: Home });

function Home() {
  const [App, setApp] = useState<ComponentType | null>(null);
  useEffect(() => {
    void import("@/components/throne-app").then((mod) => setApp(() => mod.ThroneApp));
  }, []);
  if (!App) {
    return (
      <main className="boot">
        <p className="boot-kicker">SINGGASANA</p>
        <p className="boot-tag">Dunia sedang tumbuh</p>
      </main>
    );
  }
  return <App />;
}

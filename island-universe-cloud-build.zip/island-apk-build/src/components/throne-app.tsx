import { useEffect, useRef, useState } from "react";
import { IslandEngine, type Snapshot } from "@/game/engine";
import { catLabel, formatLog, toolHint, toolLabel, tr } from "@/game/i18n";
import { CATS, type GraphicsPreset, type ShadowQ, type SizeId, type Tool } from "@/game/types";
import {
  Axe,
  Bird,
  Bomb,
  Castle,
  Cat,
  CloudLightning,
  CloudRain,
  Crown,
  Droplets,
  Eraser,
  Fence,
  Flame,
  Flower2,
  HeartPulse,
  House,
  Landmark,
  Minus,
  Mountain,
  MousePointer2,
  Pause,
  PawPrint,
  Play,
  Plus,
  Rabbit,
  Save,
  Settings,
  Shield,
  Ship,
  Skull,
  Snowflake,
  Sprout,
  Store,
  SunMedium,
  Swords,
  TreePine,
  Trees,
  Users,
  Volume2,
  Waves,
  Wheat,
  Wind,
} from "lucide-react";

const ICONS: Record<Tool, typeof Users> = {
  finger: MousePointer2,
  erase: Eraser,
  human: Users,
  elf: Sprout,
  orc: Axe,
  dwarf: Axe,
  warrior: Swords,
  king: Crown,
  chicken: Bird,
  sheep: Rabbit,
  cow: PawPrint,
  deer: PawPrint,
  wolf: PawPrint,
  bear: PawPrint,
  tiger: Cat,
  dragon: Flame,
  tree: Trees,
  pine: TreePine,
  palm: TreePine,
  rock: Mountain,
  bush: Trees,
  flower: Flower2,
  house: House,
  farm: Wheat,
  tower: Castle,
  castle: Castle,
  shrine: Landmark,
  market: Store,
  wall: Fence,
  boat: Ship,
  firepit: Flame,
  grass: Sprout,
  sand: SunMedium,
  forest: Trees,
  snow: Snowflake,
  swamp: Droplets,
  road: Fence,
  lava: Flame,
  lightning: CloudLightning,
  meteor: Bomb,
  fire: Flame,
  rain: CloudRain,
  blood: Droplets,
  quake: Mountain,
  tornado: Wind,
  tsunami: Waves,
  plague: Skull,
  freeze: Snowflake,
  heal: HeartPulse,
  bless: SunMedium,
  peace: Shield,
  warhorn: Swords,
};

function clock(hours: number): string {
  const h = Math.floor(hours) % 24;
  const m = Math.floor((hours - Math.floor(hours)) * 60);
  return `${String(h).padStart(2, "0")}:${String(m).padStart(2, "0")}`;
}

const GOALS: { id: string; key: string; test: (snap: Snapshot) => boolean }[] = [
  { id: "pop40", key: "goal_pop", test: (s) => s.pop >= 40 },
  { id: "two", key: "goal_kings", test: (s) => s.kingdoms.length >= 2 },
  { id: "war", key: "goal_war", test: (s) => s.log.some((item) => item.t === "war") },
  { id: "storm", key: "goal_storm", test: (s) => s.weather === "storm" || s.weather === "blood" },
  { id: "year", key: "goal_year", test: (s) => s.year >= 2 },
];

const GOAL_KEY = "singgasana-goals-v1";

function readGoals(): Set<string> {
  try {
    const raw = localStorage.getItem(GOAL_KEY);
    const list = raw ? (JSON.parse(raw) as string[]) : [];
    return new Set(Array.isArray(list) ? list : []);
  } catch {
    return new Set();
  }
}

export function ThroneApp() {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const miniRef = useRef<HTMLCanvasElement>(null);
  const engineRef = useRef<IslandEngine | null>(null);
  const [snap, setSnap] = useState<Snapshot | null>(null);
  const [panel, setPanel] = useState<"none" | "settings" | "saves" | "help" | "pause">("none");
  const [kingsOpen, setKingsOpen] = useState(false);
  const [name, setName] = useState("Pulau Fajar");
  const [size, setSize] = useState<SizeId>("medium");
  const [goals, setGoals] = useState<Set<string>>(() => new Set());
  const [medal, setMedal] = useState<string | null>(null);

  useEffect(() => {
    setGoals(readGoals());
  }, []);

  useEffect(() => {
    if (!snap || snap.phase !== "play") return;
    const have = readGoals();
    let fresh: string | null = null;
    for (const goal of GOALS) {
      if (!have.has(goal.id) && goal.test(snap)) {
        have.add(goal.id);
        fresh = goal.key;
      }
    }
    if (!fresh) return;
    localStorage.setItem(GOAL_KEY, JSON.stringify([...have]));
    setGoals(new Set(have));
    setMedal(fresh);
    const timer = window.setTimeout(() => setMedal(null), 3200);
    return () => window.clearTimeout(timer);
  }, [snap]);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const engine = new IslandEngine(canvas, setSnap);
    engineRef.current = engine;
    engine.attachMinimap(miniRef.current);
    engine.start();
    const scoped = window as Window & { __singgasana?: IslandEngine };
    scoped.__singgasana = engine;
    return () => {
      engine.dispose();
      if (scoped.__singgasana === engine) delete scoped.__singgasana;
    };
  }, []);

  const lang = snap?.settings.lang ?? "id";

  return (
    <div className="app">
      <canvas ref={canvasRef} className="world-canvas" />
      <div className="vignette" />
      <canvas ref={miniRef} className="minimap" width={160} height={160} onClick={(e) => {
        const rect = e.currentTarget.getBoundingClientRect();
        engineRef.current?.focusNorm((e.clientX - rect.left) / rect.width, (e.clientY - rect.top) / rect.height);
      }} />
      <div className="hud">
        <header className="topbar">
          <div className="brand">
            <p className="brand-kicker">{tr(lang, "kicker")}</p>
            <h1>{snap?.worldName || tr(lang, "title")}</h1>
          </div>
          {snap && (
            <div className="top-stats">
              <span>{tr(lang, "day")} {snap.day}</span>
              <span className="num">{clock(snap.hour)}</span>
              <span>{tr(lang, `season${snap.season}`)}</span>
              <span>{tr(lang, `weather_${snap.weather}`)}</span>
              <span>{tr(lang, "pop")} <b className="num">{snap.pop}</b></span>
            </div>
          )}
          <div className="top-actions">
            {snap?.settings.graphics.showFps !== false && (
              <div className={`fps fps-${(snap?.fps ?? 0) >= 50 ? "good" : (snap?.fps ?? 0) >= 30 ? "ok" : "bad"}`} title={snap?.settings.graphics.showPerf ? `${snap.frameMs.toFixed(1)} ms · ${snap.draws} draw` : "FPS"}>
                <span className="num">{snap?.fps ?? 0}</span>
                <small>FPS{snap?.shadows === "high" ? " HD" : ""}</small>
              </div>
            )}
            {snap?.phase === "play" && (
              <>
                <div className="speeds" role="group" aria-label={tr(lang, "speed")}>
                  <button type="button" className={snap.paused ? "on" : ""} onClick={() => engineRef.current?.setSpeed(0)}><Pause size={16} /></button>
                  <button type="button" className={!snap.paused && snap.speed === 1 ? "on" : ""} onClick={() => engineRef.current?.setSpeed(1)}>1×</button>
                  <button type="button" className={snap.speed === 3 ? "on" : ""} onClick={() => engineRef.current?.setSpeed(3)}>3×</button>
                  <button type="button" className={snap.speed === 8 ? "on" : ""} onClick={() => engineRef.current?.setSpeed(8)}>8×</button>
                </div>
                <button type="button" className="icon-btn" onClick={() => setKingsOpen((v) => !v)}>{tr(lang, "kingdoms")}</button>
                <button type="button" className="icon-btn" onClick={() => setPanel("pause")}><Settings size={16} /></button>
              </>
            )}
          </div>
        </header>

        {snap?.phase === "menu" && (
          <div className="menu-wrap">
            <section className="panel menu-card">
              <p className="eyebrow">{tr(lang, "kicker")}</p>
              <h2>{tr(lang, "title")}</h2>
              <p className="lede">{tr(lang, "lede")}</p>
              <label className="field">
                <span>{tr(lang, "name")}</span>
                <input value={name} maxLength={32} onChange={(e) => setName(e.target.value)} />
              </label>
              <div className="choice">
                {(["small", "medium", "large"] as SizeId[]).map((id) => (
                  <button key={id} type="button" className={size === id ? "on" : ""} onClick={() => setSize(id)}>{tr(lang, id)}</button>
                ))}
              </div>
              <div className="menu-actions">
                <button type="button" className="primary" onClick={() => engineRef.current?.enter()}>{tr(lang, "start")}</button>
                <button type="button" onClick={() => engineRef.current?.reroll({ name: name.trim() || "Pulau Fajar", size, seed: (Math.random() * 1e9) >>> 0 }, false)}>{tr(lang, "reroll")}</button>
                <button type="button" onClick={() => setPanel("saves")}>{tr(lang, "saved")}</button>
                <button type="button" onClick={() => setPanel("settings")}>{tr(lang, "settings")}</button>
                <button type="button" onClick={() => setPanel("help")}>{tr(lang, "help")}</button>
                <a className="apk" href="/singgasana.apk" download="Singgasana.apk">{tr(lang, "apk")}</a>
              </div>
              <p className="fine">{tr(lang, "apkNote")}</p>
              <p className="fine">{tr(lang, "keys")}</p>
            </section>
          </div>
        )}

        {snap?.phase === "play" && (
          <>
            <aside className={`kings ${kingsOpen ? "open" : ""}`}>
              <div className="panel kings-card">
                <h3>{tr(lang, "kingdoms")}</h3>
                {snap.kingdoms.length === 0 && <p className="fine">{tr(lang, "noKingdom")}</p>}
                <ul>
                  {snap.kingdoms.map((k) => (
                    <li key={k.id}>
                      <button type="button" className="king" onClick={() => engineRef.current?.focusKingdom(k.id)}>
                        <i style={{ background: k.color }} />
                        <span>
                          <strong>{k.name}</strong>
                          <em>{tr(lang, `race_${k.race}`)} · {k.pop} {tr(lang, "pop")}</em>
                        </span>
                      </button>
                      <p className="res num">{k.food} {tr(lang, "food")} · {k.wood} {tr(lang, "wood")} · {k.stone} {tr(lang, "stone")}</p>
                      <p className="fine">{k.wars.length ? `${tr(lang, "atWar")}: ${k.wars.join(", ")}` : tr(lang, "peaceState")}{k.boost ? ` · ${tr(lang, "boost")}` : ""}</p>
                    </li>
                  ))}
                </ul>
                {snap.log.length > 0 && (
                  <ol className="log">
                    {snap.log.slice(0, 4).map((item, i) => (
                      <li key={`${item.t}-${i}`}>{formatLog(lang, item)}</li>
                    ))}
                  </ol>
                )}
              </div>
            </aside>
            <div className="dock">
              {snap.inspect && (
                <section className="panel inspect">
                  <header>
                    <div>
                      <p className="eyebrow">{tr(lang, "inspect")}</p>
                      <h3>{inspectName(lang, snap.inspect.kind, snap.inspect.title, snap.inspect.subtitle)}</h3>
                    </div>
                    <button type="button" onClick={() => engineRef.current?.clearInspect()}>{tr(lang, "close")}</button>
                  </header>
                  <p className="fine">{inspectSub(lang, snap.inspect.kind, snap.inspect.subtitle)}{snap.inspect.kingdom ? ` · ${snap.inspect.kingdom}` : ""}</p>
                  <div className="bar"><span style={{ width: `${Math.max(0, Math.min(100, (snap.inspect.hp / snap.inspect.maxHp) * 100))}%` }} /></div>
                  <p className="fine">{tr(lang, "hp")} {Math.ceil(snap.inspect.hp)}/{snap.inspect.maxHp} · {tr(lang, `state_${snap.inspect.state}`)}{snap.inspect.hunger != null ? ` · ${tr(lang, "hunger")} ${Math.round(snap.inspect.hunger * 100)}%` : ""}</p>
                </section>
              )}
              <div className="panel tool-dock">
                <div className="cats">
                  {CATS.map((c) => (
                    <button key={c.id} type="button" className={snap.cat === c.id ? "on" : ""} onClick={() => engineRef.current?.setCat(c.id)}>{catLabel(lang, c.id)}</button>
                  ))}
                </div>
                <div className="tools">
                  {CATS.find((c) => c.id === snap.cat)?.tools.map((tool) => {
                    const Icon = ICONS[tool];
                    return (
                      <button key={tool} type="button" className={snap.tool === tool ? "tool on" : "tool"} onClick={() => engineRef.current?.setTool(tool)}>
                        <Icon size={18} />
                        <span>{toolLabel(lang, tool)}</span>
                      </button>
                    );
                  })}
                </div>
                <div className="tool-meta">
                  <p>{toolHint(lang, snap.tool)}</p>
                  <div className="choice slim">
                    <span>{tr(lang, "brush")}</span>
                    <button type="button" className={snap.brush === 1 ? "on" : ""} onClick={() => engineRef.current?.setBrush(1)}>{tr(lang, "brush1")}</button>
                    <button type="button" className={snap.brush === 5 ? "on" : ""} onClick={() => engineRef.current?.setBrush(5)}>{tr(lang, "brush5")}</button>
                    <button type="button" className="icon-btn" onClick={() => engineRef.current?.nudgeZoom(-1)}><Minus size={16} /></button>
                    <button type="button" className="icon-btn" onClick={() => engineRef.current?.nudgeZoom(1)}><Plus size={16} /></button>
                  </div>
                </div>
              </div>
            </div>
          </>
        )}

        {snap?.toast && <p className="toast">{tr(lang, snap.toast)}</p>}
        {medal && <p className="toast medal">{tr(lang, "medal")}: {tr(lang, medal)}</p>}
        {snap?.webgl && <p className="toast">{tr(lang, "webgl")}</p>}

        {panel !== "none" && snap && (
          <div className="modal-back" onClick={() => setPanel("none")}>
            <section className="panel modal" onClick={(e) => e.stopPropagation()}>
              {panel === "pause" && (
                <>
                  <h2>{tr(lang, "pause")}</h2>
                  <div className="menu-actions">
                    <button type="button" className="primary" onClick={() => { engineRef.current?.togglePause(); setPanel("none"); }}>{snap.paused ? <Play size={16} /> : <Pause size={16} />} {snap.paused ? tr(lang, "resume") : tr(lang, "pause")}</button>
                    <button type="button" onClick={() => engineRef.current?.save()}><Save size={16} /> {tr(lang, "save")}</button>
                    <button type="button" onClick={() => setPanel("settings")}><Settings size={16} /> {tr(lang, "settings")}</button>
                    <button type="button" onClick={() => setPanel("help")}>{tr(lang, "help")}</button>
                    <button type="button" onClick={() => { engineRef.current?.goMenu(); setPanel("none"); }}>{tr(lang, "menu")}</button>
                  </div>
                  <p className="fine num">{tr(lang, "year")} {snap.year} · {snap.births} / {snap.deaths}</p>
                  <h3>{tr(lang, "goals")}</h3>
                  <ul className="goals">
                    {GOALS.map((goal) => (
                      <li key={goal.id} className={goals.has(goal.id) ? "done" : ""}>{tr(lang, goal.key)}</li>
                    ))}
                  </ul>
                </>
              )}
              {panel === "settings" && <SettingsPanel snap={snap} />}
              {panel === "help" && (
                <>
                  <h2>{tr(lang, "help")}</h2>
                  <p className="lede">{tr(lang, "helpBody")}</p>
                  <button type="button" className="primary" onClick={() => setPanel("none")}>{tr(lang, "back")}</button>
                </>
              )}
              {panel === "saves" && (
                <>
                  <h2>{tr(lang, "saved")}</h2>
                  {snap.saves.length === 0 && <p className="fine">{tr(lang, "emptySaves")}</p>}
                  <ul className="saves">
                    {snap.saves.map((w) => (
                      <li key={w.id}>
                        <div>
                          <strong>{w.name}</strong>
                          <p className="fine">{tr(lang, "day")} {w.day} · {w.pop} {tr(lang, "pop")}</p>
                        </div>
                        <button type="button" onClick={() => { engineRef.current?.load(w.id); setPanel("none"); }}>{tr(lang, "load")}</button>
                        <button type="button" onClick={() => engineRef.current?.remove(w.id)}>{tr(lang, "delete")}</button>
                      </li>
                    ))}
                  </ul>
                  <button type="button" onClick={() => setPanel("none")}>{tr(lang, "back")}</button>
                </>
              )}
            </section>
          </div>
        )}
      </div>
    </div>
  );
}

function inspectName(lang: Snapshot["settings"]["lang"], kind: string, title: string, subtitle: string): string {
  if (kind === "building") return tr(lang, `tool_${title}`);
  if (!subtitle.includes(":")) return tr(lang, `tool_${title}`);
  return title;
}

function inspectSub(lang: Snapshot["settings"]["lang"], kind: string, subtitle: string): string {
  if (kind === "building") return tr(lang, `tool_${subtitle}`);
  if (!subtitle.includes(":")) return tr(lang, "role_beast");
  const [role, race] = subtitle.split(":");
  return `${tr(lang, `role_${role}`)} · ${tr(lang, `race_${race}`)}`;
}

function SettingsPanel({ snap }: { snap: Snapshot }) {
  const lang = snap.settings.lang;
  const g = snap.settings.graphics;
  const a = snap.settings.audio;
  return (
    <>
      <h2>{tr(lang, "settings")}</h2>
      <div className="choice">
        <button type="button" className={lang === "id" ? "on" : ""} onClick={() => active()?.setLang("id")}>Indonesia</button>
        <button type="button" className={lang === "en" ? "on" : ""} onClick={() => active()?.setLang("en")}>English</button>
      </div>
      <h3>{tr(lang, "graphics")}</h3>
      <div className="choice">
        {(["low", "medium", "high", "ultra"] as GraphicsPreset[]).map((p) => (
          <button key={p} type="button" className={g.preset === p ? "on" : ""} onClick={() => active()?.setGraphics({ preset: p }, true)}>{tr(lang, p === "high" ? "high" : p)}</button>
        ))}
      </div>
      <label className="field">{tr(lang, "shadows")}
        <div className="choice">
          {(["off", "low", "medium", "high"] as ShadowQ[]).map((s) => (
            <button key={s} type="button" className={g.shadows === s ? "on" : ""} onClick={() => active()?.setGraphics({ shadows: s })}>{tr(lang, s === "off" ? "off" : s === "low" ? "low" : s === "medium" ? "medium" : "high")}</button>
          ))}
        </div>
      </label>
      <Slider label={tr(lang, "resolution")} value={g.resolution} min={50} max={100} onChange={(resolution) => active()?.setGraphics({ resolution })} />
      <Slider label={tr(lang, "vegetation")} value={g.vegetation} min={20} max={100} onChange={(vegetation) => active()?.setGraphics({ vegetation })} />
      <Slider label={tr(lang, "view")} value={g.viewDistance} min={70} max={180} onChange={(viewDistance) => active()?.setGraphics({ viewDistance })} />
      <Toggle label={tr(lang, "fps")} checked={g.showFps} onChange={(showFps) => active()?.setGraphics({ showFps })} />
      <Toggle label={tr(lang, "perf")} checked={g.showPerf} onChange={(showPerf) => active()?.setGraphics({ showPerf })} />
      <h3><Volume2 size={16} /> {tr(lang, "audio")}</h3>
      <Slider label={tr(lang, "master")} value={a.master} min={0} max={100} onChange={(master) => active()?.setAudio({ master })} />
      <Slider label={tr(lang, "music")} value={a.music} min={0} max={100} onChange={(music) => active()?.setAudio({ music })} />
      <Slider label={tr(lang, "sfx")} value={a.sfx} min={0} max={100} onChange={(sfx) => active()?.setAudio({ sfx })} />
      <Toggle label={tr(lang, "mute")} checked={a.mute} onChange={(mute) => active()?.setAudio({ mute })} />
    </>
  );
}

function active(): IslandEngine | null {
  return (window as unknown as { __singgasana?: IslandEngine }).__singgasana ?? null;
}

function Slider({ label, value, min, max, onChange }: { label: string; value: number; min: number; max: number; onChange: (v: number) => void }) {
  return (
    <label className="field">
      <span>{label} <b className="num">{Math.round(value)}</b></span>
      <input type="range" min={min} max={max} value={value} onChange={(e) => onChange(Number(e.target.value))} />
    </label>
  );
}

function Toggle({ label, checked, onChange }: { label: string; checked: boolean; onChange: (v: boolean) => void }) {
  return (
    <label className="toggle">
      <span>{label}</span>
      <input type="checkbox" checked={checked} onChange={(e) => onChange(e.target.checked)} />
    </label>
  );
}
